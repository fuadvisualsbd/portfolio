@echo off
setlocal
color 0A

set "USER_APPDATA=%~1"
if not defined USER_APPDATA set "USER_APPDATA=%APPDATA%"
set "USER_LOCALAPPDATA=%~2"
if not defined USER_LOCALAPPDATA set "USER_LOCALAPPDATA=%LOCALAPPDATA%"

for /L %%i in (5,1,16) do reg add "HKCU\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

net session >nul 2>&1
if %errorLevel% equ 0 goto ADMIN_OK
echo Requesting administrator privileges...
set "SELF_PATH=%~f0"
set "ORIG_APPDATA=%USER_APPDATA%"
set "ORIG_LOCALAPPDATA=%USER_LOCALAPPDATA%"
powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c ' + [char]34 + [char]34 + $env:SELF_PATH + [char]34 + ' ' + [char]34 + $env:ORIG_APPDATA + [char]34 + ' ' + [char]34 + $env:ORIG_LOCALAPPDATA + [char]34 + [char]34) -Verb RunAs"
exit /b

:ADMIN_OK
echo ========================================================
echo        Adobe AI Agent v1.1.12 Installer
echo ========================================================
echo.

echo [1/4] Enabling Adobe CEP Extension Support...
for /L %%i in (5,1,16) do reg add "HKCU\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo [2/4] Checking ^& removing any previous versions...
if exist "%~dp0extension\index.html" goto EXT_FOUND
echo [ERROR] "extension" folder not found next to installer!
echo Please EXTRACT the ZIP file completely before running this installer.
pause
exit /b 1

:EXT_FOUND
:CHECK_ADOBE_RUNNING
tasklist /NH /FI "IMAGENAME eq Photoshop.exe" 2>nul | "%SystemRoot%\System32\findstr.exe" /I "Photoshop.exe" >nul
if %errorLevel% equ 0 goto ADOBE_OPEN
tasklist /NH /FI "IMAGENAME eq Illustrator.exe" 2>nul | "%SystemRoot%\System32\findstr.exe" /I "Illustrator.exe" >nul
if %errorLevel% equ 0 goto ADOBE_OPEN
tasklist /NH /FI "IMAGENAME eq AfterFX.exe" 2>nul | "%SystemRoot%\System32\findstr.exe" /I "AfterFX.exe" >nul
if %errorLevel% equ 0 goto ADOBE_OPEN
goto CLEAN_OLD

:ADOBE_OPEN
echo.
echo [WARN] Adobe Photoshop, Illustrator, or After Effects is currently running!
echo Please CLOSE all Adobe apps so plugin files are not locked.
echo After closing Adobe, press any key to continue...
pause >nul
goto CHECK_ADOBE_RUNNING

:CLEAN_OLD
taskkill /F /IM CEPHtmlEngine.exe >nul 2>&1
powershell -NoProfile -Command "$d=(Get-Date).AddSeconds(4); while ((Get-Process -Name 'CEPHtmlEngine' -ErrorAction SilentlyContinue) -and ((Get-Date) -lt $d)) { Start-Sleep -Milliseconds 200 }" >nul 2>&1

set "FOUND_ANY=0"
set "HAD_ERROR=0"
call :REMOVE_ONE "%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%ProgramFiles%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%USER_APPDATA%\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%USER_LOCALAPPDATA%\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%ProgramData%\Adobe\CEP\extensions\com.adobe.aiagent"

if not "%HAD_ERROR%"=="1" goto CLEAN_OK
echo.
echo [ERROR] Could not remove old extension files because another process is locking them.
echo Please close all Adobe apps and try again.
pause
exit /b 1

:CLEAN_OK
powershell -NoProfile -Command "foreach ($b in @($env:TEMP, (Join-Path $env:USER_LOCALAPPDATA 'Temp'))) { if ($b) { $c = Join-Path $b 'cep_cache'; if (Test-Path -LiteralPath $c) { Remove-Item -LiteralPath $c -Recurse -Force -ErrorAction SilentlyContinue } } }" >nul 2>&1

set "DEST=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent"
if not defined ProgramFiles(x86) set "DEST=%ProgramFiles%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent"

echo [3/4] Installing Adobe AI Agent v1.1.12 to Adobe CEP extensions...
set "DEST_TARGET=%DEST%"
powershell -NoProfile -Command "$d=$env:DEST_TARGET; for ($try=1; $try -le 6; $try++) { try { if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force -ErrorAction Stop | Out-Null }; if (Test-Path -LiteralPath $d) { exit 0 } } catch {}; Start-Sleep -Milliseconds 300 }; exit 1"
if %errorLevel% neq 0 goto MKDIR_ERR

robocopy "%~dp0extension" "%DEST%" /E /R:5 /W:1 /NFL /NDL /NJH /NJS /NC /NS /NP >nul
if %errorLevel% geq 8 goto COPY_ERR

echo [4/4] Verifying installation...
if not exist "%DEST%\index.html" goto VERIFY_ERR
if not exist "%DEST%\CSXS\manifest.xml" goto VERIFY_ERR
if not exist "%DEST%\js\config.js" goto VERIFY_ERR

echo.
echo ========================================================
echo   SUCCESS! Adobe AI Agent v1.1.12 is installed!
echo ========================================================
echo   Installed to: "%DEST%"
if "%FOUND_ANY%"=="1" echo   Status      : Old version removed ^& updated cleanly!
echo.
echo Please open Photoshop or Illustrator, then open:
echo   Photoshop   : Window ^> Extensions ^(legacy^) ^> Adobe AI Agent
echo   Illustrator : Window ^> Extensions ^> Adobe AI Agent
echo.
pause
exit /b 0

:MKDIR_ERR
echo [ERROR] Failed to prepare destination folder: "%DEST%"
pause
exit /b 1

:COPY_ERR
echo [ERROR] Failed to copy extension files to "%DEST%"
pause
exit /b 1

:VERIFY_ERR
echo [ERROR] Verification failed: required extension files not found in "%DEST%"
pause
exit /b 1

:REMOVE_ONE
set "TARGET_DIR=%~1"
if not defined TARGET_DIR exit /b 0
if not exist "%TARGET_DIR%" exit /b 0
set "DEL_TARGET=%TARGET_DIR%"
powershell -NoProfile -Command "$p=$env:DEL_TARGET; for ($try=1; $try -le 6; $try++) { if (-not (Test-Path -LiteralPath $p)) { break }; try { $i=Get-Item -LiteralPath $p -Force; if ($i.Attributes -band [IO.FileAttributes]::ReparsePoint) { $i.Delete() } else { Get-ChildItem -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { try { if ($_.Attributes -band [IO.FileAttributes]::ReadOnly) { $_.Attributes = $_.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly) } } catch {} }; Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop } } catch {}; if (Test-Path -LiteralPath $p) { Start-Sleep -Milliseconds 300 } }"
if exist "%TARGET_DIR%" goto REMOVE_FAILED
echo [OK] Removed old version: "%TARGET_DIR%"
set "FOUND_ANY=1"
exit /b 0
:REMOVE_FAILED
echo [WARN] Could not remove: "%TARGET_DIR%" - close Photoshop/Illustrator and retry
set "HAD_ERROR=1"
exit /b 0
