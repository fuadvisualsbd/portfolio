(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  var CepBridge = NS.CepBridge;
  var storage = new NS.StorageManager();
  var auth = new NS.AuthClient();
  var api = new NS.ApiHandler(storage, auth);
  var agent = new NS.AgentEngine(api, storage);
  var iconPreset = NS.IconPresetManager ? new NS.IconPresetManager({ api: api, auth: auth, storage: storage }) : null;

  function loadAutoCanvasPref() {
    try {
      return global.localStorage.getItem('adobe_ai_agent_auto_canvas') !== 'false';
    } catch (e) {
      return true;
    }
  }

  function loadRecheckPref() {
    try {
      return global.localStorage.getItem('adobe_ai_agent_recheck_stock') === 'true';
    } catch (e) {
      return false;
    }
  }

  function loadNotifyPref() {
    try {
      return global.localStorage.getItem('adobe_ai_agent_notify_complete') !== 'false';
    } catch (e) {
      return true;
    }
  }

  var state = {
    hostInfo: CepBridge.detectHost(),
    docContext: null,
    currentSession: null,
    currentUser: auth.user || null,
    uiConfig: null,
    currentLoginUrl: '',
    isLockedUpdate: false,
    pendingImages: [], // { name, dataUrl, diskPath }
    autoCaptureCanvas: loadAutoCanvasPref(),
    recheckStock: loadRecheckPref(),
    notifyOnComplete: loadNotifyPref(),
    isBusy: false,
    noApiNoticeDismissed: false,
    sidebarTab: 'chats', // 'chats' | 'scripts'
    modelTestResults: {},
    keyTestResults: {},
    iconPreset: {
      folderPath: '',
      svgFiles: [],
      refImage: null,
      reviewData: null,
      isRunning: false
    }
  };

  function getApiUpgradeTipText() {
    var grade = state.currentUser ? Number(state.currentUser.grade || 3) : 3;
    var byokLim = (state.currentUser && state.currentUser.byok_daily_limit != null) ? Number(state.currentUser.byok_daily_limit) : 50;
    if (grade === 2) {
      return 'Add your own API key for best quality output & unlimited daily usage!';
    }
    if (grade === 1) {
      return 'Add your own API key for best quality output & higher usage limits!';
    }
    return 'Add your own API key for best quality output & higher daily limits (up to ' + byokLim + '/day)!';
  }

  function eachNode(list, fn) {
    if (!list) return;
    for (var i = 0; i < list.length; i++) {
      fn(list[i], i);
    }
  }

  function setClass(el, cls, cond) {
    if (!el) return;
    if (cond) el.classList.add(cls);
    else el.classList.remove(cls);
  }

  function canViewJsx() {
    return !!(
      state.currentUser &&
      (Number(state.currentUser.grade) === 1 || Number(state.currentUser.grade) === 2 || state.currentUser.can_view_jsx === true)
    );
  }

  function canSelectModels() {
    return !!(
      state.currentUser &&
      (Number(state.currentUser.grade) === 1 || Number(state.currentUser.grade) === 2 || state.currentUser.can_select_model === true)
    );
  }

  function canUseUnlimitedByok() {
    return !!(
      state.currentUser &&
      (Number(state.currentUser.grade) === 1 || Number(state.currentUser.grade) === 2 || state.currentUser.can_use_unlimited_byok === true || state.currentUser.is_unlimited === true)
    );
  }

  function canUseIconPreset() {
    return !!(
      state.currentUser &&
      (Number(state.currentUser.grade) === 1 || Number(state.currentUser.grade) === 2)
    );
  }

  // DOM helpers
  function $(id) { return document.getElementById(id); }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatTime(ts) {
    try {
      return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return '';
    }
  }

  // ───────── Session Management ─────────

  function closeSidebar() {
    var sb = $('historySidebar');
    if (sb) sb.classList.add('collapsed');
  }

  function createNewSession() {
    var id = 'chat_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    state.currentSession = {
      id: id,
      title: 'New Chat',
      hostApp: state.hostInfo.app,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      scripts: []
    };
    renderSidebar();
    renderChatFeed();
    if (state.currentUser && $('chatInput')) {
      $('chatInput').focus();
    }
  }

  function loadSessionById(sessionId) {
    var loaded = storage.loadSession(sessionId);
    if (loaded) {
      state.currentSession = loaded;
      renderSidebar();
      renderChatFeed();
    }
  }

  function initSession() {
    var sessions = storage.listSessions();
    if (sessions.length > 0) {
      var latest = storage.loadSession(sessions[0].id);
      if (latest) {
        state.currentSession = latest;
        return;
      }
    }
    createNewSession();
  }

  // ───────── Host Detection & Doc Context ─────────

  function updateHostBadge() {
    state.hostInfo = CepBridge.detectHost();
    var badge = $('hostBadge');
    badge.className = 'host-badge ' + state.hostInfo.app;
    $('hostBadgeText').textContent = state.hostInfo.label;
  }

  function refreshDocContext() {
    return CepBridge.getDocumentContext().then(function (ctx) {
      state.docContext = ctx;
      var pill = $('docPill');
      if (!state.hostInfo.isAdobe) {
        pill.textContent = 'Preview Mode';
      } else if (state.docContext && state.docContext.hasOpenDoc) {
        if (state.hostInfo.app === 'photoshop') {
          pill.textContent = state.docContext.widthPx + '×' + state.docContext.heightPx + ' px';
        } else if (state.hostInfo.app === 'illustrator') {
          pill.textContent = Math.round(state.docContext.activeArtboardWidthPt || 0) + '×' + Math.round(state.docContext.activeArtboardHeightPt || 0) + ' pt';
        } else {
          pill.textContent = state.docContext.docName || 'Open Doc';
        }
      } else {
        pill.textContent = 'No Doc Open';
      }
      return ctx;
    })['catch'](function () {
      $('docPill').textContent = 'Ready';
    });
  }

  // ───────── Sidebar Rendering (Chats + Saved JSX) ─────────

  function renderSidebar() {
    var listEl = $('sidebarList');
    listEl.innerHTML = '';

    var showJsx = canViewJsx();
    if (!showJsx && state.sidebarTab === 'scripts') {
      state.sidebarTab = 'chats';
    }

    setClass($('tabChatsBtn'), 'active', state.sidebarTab === 'chats');
    setClass($('tabScriptsBtn'), 'active', state.sidebarTab === 'scripts');

    if (state.sidebarTab === 'chats') {
      var sessions = storage.listSessions();
      if (sessions.length === 0) {
        listEl.innerHTML = '<div class="sidebar-empty">No saved chats yet.<br>Tell me what you want to do below!</div>';
        return;
      }

      sessions.forEach(function (s) {
        var row = document.createElement('div');
        row.className = 'session-item' + (state.currentSession && state.currentSession.id === s.id ? ' active' : '');

        var appTag = s.hostApp === 'photoshop' ? 'PS' : (s.hostApp === 'illustrator' ? 'AI' : 'WEB');
        row.innerHTML =
          '<div class="session-meta">' +
            '<div class="session-title">' + escapeHtml(s.title || 'New Chat') + '</div>' +
            '<div class="session-sub">' +
              '<span>' + appTag + '</span>' +
              '<span>• ' + (s.messageCount || 0) + ' msgs</span>' +
              (showJsx ? ('<span>• ' + (s.scriptCount || 0) + ' jsx</span>') : '') +
            '</div>' +
          '</div>' +
          '<button type="button" class="session-del-btn" title="Delete chat">🗑</button>';

        row.addEventListener('click', function (ev) {
          if (ev.target && ev.target.classList.contains('session-del-btn')) return;
          loadSessionById(s.id);
          if (global.innerWidth <= 720) $('historySidebar').classList.add('collapsed');
        });

        row.querySelector('.session-del-btn').addEventListener('click', function (ev) {
          ev.stopPropagation();
          storage.deleteSession(s.id);
          if (state.currentSession && state.currentSession.id === s.id) {
            var remaining = storage.listSessions();
            if (remaining.length > 0) {
              loadSessionById(remaining[0].id);
            } else {
              createNewSession();
            }
          } else {
            renderSidebar();
          }
        });

        listEl.appendChild(row);
      });
    } else {
      // Saved JSX tab
      var scripts = (state.currentSession && state.currentSession.scripts) ? state.currentSession.scripts.slice().reverse() : [];
      if (scripts.length === 0) {
        listEl.innerHTML = '<div class="sidebar-empty">No JSX scripts saved in this chat yet.</div>';
        return;
      }

      scripts.forEach(function (sc) {
        var card = document.createElement('div');
        card.className = 'script-item';
        card.innerHTML =
          '<div class="script-item-name">' + escapeHtml(sc.scriptFile || sc.scriptName || 'command.jsx') + '</div>' +
          '<div style="font-size:0.74rem; font-weight:600; color:var(--text-secondary);">' + escapeHtml(sc.hostLabel || '') + ' • ' + formatTime(sc.timestamp) + '</div>' +
          '<div class="script-item-btns">' +
            '<button type="button" class="btn small btn-rerun">▶ Re-run</button>' +
            '<button type="button" class="btn small btn-copy">Copy</button>' +
            '<button type="button" class="btn small btn-open">Open</button>' +
          '</div>';

        card.querySelector('.btn-rerun').addEventListener('click', function () {
          rerunJsxScript(sc.jsxScript, sc.scriptFile);
        });
        card.querySelector('.btn-copy').addEventListener('click', function (ev) {
          copyToClipboard(sc.jsxScript, ev.target);
        });
        card.querySelector('.btn-open').addEventListener('click', function () {
          if (sc.scriptPath) CepBridge.openFolderInExplorer(sc.scriptPath);
        });

        listEl.appendChild(card);
      });
    }
  }

  // ───────── Chat Feed Rendering ─────────

  function renderWelcomeState() {
    var host = state.hostInfo;
    var specs = [];
    if (host.app === 'photoshop') {
      specs = ['Auto-detected: ' + (host.label || 'Photoshop'), 'CC 2015 – 2026 Supported', 'Min Canvas: 4K (3840×2160)'];
    } else if (host.app === 'illustrator') {
      specs = ['Auto-detected: ' + (host.label || 'Illustrator'), 'CC 2015 – 2026 Supported', 'Artboard: 20 MP'];
    } else {
      specs = ['Preview Mode (PS/AI CC 2015–2026)', 'PS Min 4K (16:9)', 'AI 20MP (4:3)'];
    }

    var wrapper = document.createElement('div');
    wrapper.className = 'welcome-card';
    wrapper.innerHTML =
      '<div class="welcome-title">Adobe AI Agent</div>' +
      '<div class="welcome-sub">Describe what you want to create or attach a reference image below — tasks are automated directly inside Photoshop or Illustrator (CC 2015–2026). Requests normally take 1–2 minutes.</div>' +
      '<div class="spec-pill-row">' +
        specs.map(function (sp) { return '<span class="spec-pill">' + escapeHtml(sp) + '</span>'; }).join('') +
      '</div>';

    return wrapper;
  }

  function isErrorAssistantMessage(msg) {
    if (!msg || msg.role !== 'assistant') return false;
    if (msg.isError) return true;
    if (msg.execution && msg.execution.ok === false) return true;
    var txt = String(msg.content || '');
    return txt.indexOf('Error:') === 0;
  }

  function findPrecedingUserMessage(msgs, idx) {
    if (!Array.isArray(msgs)) return null;
    for (var i = idx - 1; i >= 0; i--) {
      if (msgs[i] && msgs[i].role === 'user') return msgs[i];
    }
    return null;
  }

  function readDiskImageAsDataUrl(diskPath) {
    try {
      if (!diskPath || !storage || !storage.isDiskAvailable || !storage.fs) return '';
      if (!storage.fs.existsSync(diskPath)) return '';
      var buf = storage.fs.readFileSync(diskPath);
      var b64 = buf.toString('base64');
      var lower = String(diskPath).toLowerCase();
      var mime = lower.slice(-4) === '.png'
        ? 'image/png'
        : (lower.slice(-5) === '.webp' ? 'image/webp' : 'image/jpeg');
      return 'data:' + mime + ';base64,' + b64;
    } catch (e) {
      return '';
    }
  }

  function cloneUserImages(rawImages) {
    var out = [];
    if (!Array.isArray(rawImages)) return out;
    for (var i = 0; i < rawImages.length; i++) {
      var im = rawImages[i];
      if (!im || im.isAutoCanvas) continue;
      var dUrl = im.dataUrl || readDiskImageAsDataUrl(im.diskPath);
      if (dUrl || im.diskPath) {
        out.push({
          name: im.name || 'image.png',
          dataUrl: dUrl,
          diskPath: im.diskPath || null
        });
      }
    }
    return out;
  }

  function extractRetryPayload(userMsg) {
    var rawContent = String((userMsg && userMsg.content) || '');
    var imgs = cloneUserImages(userMsg ? userMsg.images : []);
    var promptText = rawContent;
    if (promptText === '(Attached reference image)' && imgs.length > 0) {
      promptText = '';
    }
    return {
      text: promptText.trim(),
      images: imgs
    };
  }

  function loadPromptIntoComposer(userMsg) {
    if (state.isBusy || !userMsg) return;
    var payload = extractRetryPayload(userMsg);
    var ta = $('chatInput');
    ta.value = payload.text;
    autoResizeTextarea();
    state.pendingImages = payload.images;
    renderPendingImages();
    ta.focus();
    try {
      var len = ta.value.length;
      ta.setSelectionRange(len, len);
    } catch (e) {}
  }

  function appendMessageActionButtons(bubble, userMsg, options) {
    if (!userMsg) return;
    var opts = options || {};
    var payload = extractRetryPayload(userMsg);
    if (!payload.text && payload.images.length === 0) return;

    var row = document.createElement('div');
    row.className = 'msg-actions-row' + (opts.userSide ? ' user-side' : '');

    var retryBtn = document.createElement('button');
    retryBtn.type = 'button';
    retryBtn.className = 'btn small msg-retry-btn' + (opts.isError ? ' is-error' : '');
    retryBtn.textContent = '↻ Retry';
    retryBtn.title = 'Retry with the same prompt' + (payload.images.length > 0 ? ' & reference image' : '');
    retryBtn.disabled = !!state.isBusy;
    retryBtn.addEventListener('click', function () {
      if (state.isBusy) return;
      executePromptTurn(payload.text, payload.images, {
        fromComposer: false,
        reuseUserMsg: opts.replaceAssistantMsg ? userMsg : null,
        replaceAssistantMsg: opts.replaceAssistantMsg || null,
        reuseDanglingUserMsg: opts.reuseDanglingUserMsg || null
      });
    });

    var editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn small msg-edit-btn';
    editBtn.textContent = '✎ Edit';
    editBtn.title = 'Load this prompt into input box to edit before sending';
    editBtn.disabled = !!state.isBusy;
    editBtn.addEventListener('click', function () {
      loadPromptIntoComposer(userMsg);
    });

    row.appendChild(retryBtn);
    row.appendChild(editBtn);
    bubble.appendChild(row);
  }

  function renderMessageNode(msg, idx, allMsgs) {
    var row = document.createElement('div');
    row.className = 'msg-row ' + (msg.role === 'user' ? 'user' : 'assistant');

    var bubble = document.createElement('div');
    bubble.className = 'msg-bubble';

    var showModelName = canSelectModels();
    var headerLabel = msg.role === 'user' ? 'You' : ('Agent' + (showModelName && msg.modelUsed ? ' · ' + msg.modelUsed : ''));
    var html =
      '<div class="msg-header">' +
        '<span>' + escapeHtml(headerLabel) + '</span>' +
        '<span>' + formatTime(msg.timestamp) + '</span>' +
      '</div>' +
      '<div class="msg-text">' + escapeHtml(msg.content || '') + '</div>';

    if (Array.isArray(msg.images) && msg.images.length > 0) {
      html += '<div class="msg-images">';
      msg.images.forEach(function (img) {
        if (img.dataUrl) {
          if (img.isAutoCanvas) {
            html +=
              '<div class="msg-thumb-wrap" title="' + escapeHtml(img.name || 'Open project screenshot') + '">' +
                '<img class="msg-thumb" src="' + img.dataUrl + '">' +
                '<span class="msg-canvas-tag">Canvas</span>' +
              '</div>';
          } else {
            html += '<img class="msg-thumb" src="' + img.dataUrl + '" title="' + escapeHtml(img.name || 'image') + '">';
          }
        } else if (img.name) {
          html += '<span class="spec-pill">🖼 ' + escapeHtml(img.name) + '</span>';
        }
      });
      html += '</div>';
    }

    bubble.innerHTML = html;

    // Inline Add API Key CTA (e.g., when free 5 credits finish)
    if (msg.role === 'assistant' && msg.showAddApiButton) {
      var actRow = document.createElement('div');
      actRow.className = 'inline-action-row';
      var addKeyActionBtn = document.createElement('button');
      addKeyActionBtn.type = 'button';
      addKeyActionBtn.className = 'btn primary small';
      addKeyActionBtn.textContent = msg.addApiButtonLabel || '🔑 Add API Key (Extend to 50/day)';
      addKeyActionBtn.addEventListener('click', function () {
        openApiModal();
      });
      actRow.appendChild(addKeyActionBtn);
      bubble.appendChild(actRow);
    }

    // Quick-reply chips when AI asks for clarification
    if (msg.role === 'assistant' && msg.action === 'ask_user' && Array.isArray(msg.questions) && msg.questions.length > 0) {
      var qWrap = document.createElement('div');
      qWrap.className = 'question-chips';
      msg.questions.forEach(function (qText) {
        var chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'q-chip';
        chip.textContent = qText;
        chip.addEventListener('click', function () {
          if (state.isBusy) return;
          $('chatInput').value = qText;
          handleSend();
        });
        qWrap.appendChild(chip);
      });
      bubble.appendChild(qWrap);
    }

    // Execution status & saved JSX script drawer
    if (msg.role === 'assistant' && msg.execution) {
      var ex = msg.execution;
      var execBox = document.createElement('div');
      execBox.className = 'exec-box';

      var badgesHtml = '<div class="exec-badges">';
      if (ex.previewOnly) {
        badgesHtml += '<span class="status-pill preview">' + (canViewJsx() ? 'Preview Mode · JSX Saved' : 'Preview Mode') + '</span>';
      } else if (ex.ok) {
        badgesHtml += '<span class="status-pill ok">✓ Done in ' + escapeHtml(ex.hostLabel || 'Adobe') + '</span>';
      } else {
        badgesHtml += '<span class="status-pill err">✕ Could not complete' + (canViewJsx() && ex.error ? ': ' + escapeHtml(ex.error) : '') + '</span>';
      }

      if (canViewJsx() && ex.details && ex.details.audit && typeof ex.details.audit.outOfBoundsCount === 'number') {
        badgesHtml += '<span class="spec-pill">Bounds Guard: ' + ex.details.audit.outOfBoundsCount + ' outside</span>';
      }
      if (ex.recheck && ex.recheck.performed) {
        if (ex.recheck.status === 'fixed') {
          badgesHtml += '<span class="status-pill ok">🛠 Stock QA: Auto-Fixed</span>';
        } else if (ex.recheck.status === 'passed') {
          badgesHtml += '<span class="status-pill ok">🔍 Stock QA: Passed</span>';
        } else {
          badgesHtml += '<span class="status-pill preview">🔍 Stock QA: Skipped</span>';
        }
      }
      if (msg.exportMode === 'multiple' && msg.exportCount > 1) {
        badgesHtml += '<span class="spec-pill">Multiple Export: ' + msg.exportCount + '</span>';
      }
      badgesHtml += '</div>';

      execBox.innerHTML = badgesHtml;

      if (ex.recheck && ex.recheck.performed && ex.recheck.summary) {
        var recheckNote = document.createElement('div');
        recheckNote.className = 'recheck-note';
        recheckNote.textContent = '🔍 Recheck: ' + ex.recheck.summary;
        execBox.appendChild(recheckNote);
      }

      // Exported files chips
      if (Array.isArray(ex.exportedFiles) && ex.exportedFiles.length > 0) {
        var filesDiv = document.createElement('div');
        filesDiv.className = 'export-files-list';
        ex.exportedFiles.forEach(function (fp) {
          var fName = String(fp).split(/[\\/]/).pop();
          var chipBtn = document.createElement('button');
          chipBtn.type = 'button';
          chipBtn.className = 'export-file-chip';
          chipBtn.textContent = '📄 ' + fName;
          chipBtn.title = fp;
          chipBtn.addEventListener('click', function () {
            CepBridge.openFolderInExplorer(fp);
          });
          filesDiv.appendChild(chipBtn);
        });
        execBox.appendChild(filesDiv);
      }

      // Collapsible Saved JSX Viewer (1st & 2nd Grade only)
      if (ex.jsxScript && canViewJsx()) {
        var details = document.createElement('details');
        details.className = 'jsx-details';
        details.innerHTML =
          '<summary><span>📜 Saved JSX: ' + escapeHtml(ex.scriptFile || 'command.jsx') + '</span><span>▾</span></summary>' +
          '<div class="jsx-toolbar">' +
            '<button type="button" class="btn small btn-copy-jsx">Copy JSX</button>' +
            '<button type="button" class="btn small btn-rerun-jsx">▶ Re-run in App</button>' +
            '<button type="button" class="btn small btn-open-jsx">Open File</button>' +
          '</div>' +
          '<pre class="jsx-code">' + escapeHtml(ex.jsxScript) + '</pre>';

        details.querySelector('.btn-copy-jsx').addEventListener('click', function (ev) {
          copyToClipboard(ex.jsxScript, ev.target);
        });
        details.querySelector('.btn-rerun-jsx').addEventListener('click', function () {
          rerunJsxScript(ex.jsxScript, ex.scriptFile);
        });
        details.querySelector('.btn-open-jsx').addEventListener('click', function () {
          if (ex.scriptPath) CepBridge.openFolderInExplorer(ex.scriptPath);
        });

        execBox.appendChild(details);
      }

      bubble.appendChild(execBox);
    }

    // Show best-quality + higher-limit tip on every Admin-API response until user adds a personal API key
    if (msg.role === 'assistant' && msg.usedAdminApi && !api.getActiveKeyObj() && !msg.showAddApiButton) {
      var tipBox = document.createElement('div');
      tipBox.className = 'admin-api-tip';
      var tipSpan = document.createElement('span');
      tipSpan.className = 'admin-api-tip-text';
      tipSpan.textContent = '💡 ' + getApiUpgradeTipText();
      var tipBtn = document.createElement('button');
      tipBtn.type = 'button';
      tipBtn.className = 'btn primary small';
      tipBtn.textContent = '🔑 Add API Key';
      tipBtn.addEventListener('click', function () {
        openApiModal();
      });
      tipBox.appendChild(tipSpan);
      tipBox.appendChild(tipBtn);
      bubble.appendChild(tipBox);
    }

    // Retry & Edit actions (on assistant replies to a prompt, or on a dangling last user message)
    if (msg.role === 'assistant' && !msg.isSystemNote && !msg.showAddApiButton && String(msg.content || '').indexOf('⚠️ ') !== 0) {
      var prevUserMsg = findPrecedingUserMessage(allMsgs, idx);
      if (prevUserMsg) {
        var isErr = isErrorAssistantMessage(msg);
        var isLastMsg = Array.isArray(allMsgs) && idx === allMsgs.length - 1;
        appendMessageActionButtons(bubble, prevUserMsg, {
          isError: isErr,
          replaceAssistantMsg: (isErr && isLastMsg) ? msg : null
        });
      }
    } else if (msg.role === 'user' && Array.isArray(allMsgs) && idx === allMsgs.length - 1) {
      appendMessageActionButtons(bubble, msg, {
        userSide: true,
        reuseDanglingUserMsg: msg
      });
    }

    row.appendChild(bubble);
    return row;
  }

  function renderChatFeed(preserveScroll) {
    var feed = $('chatFeed');
    var inner = $('chatFeedInner');
    var prevTop = feed ? feed.scrollTop : 0;
    var wasNearBottom = !feed || (feed.scrollHeight - feed.scrollTop - feed.clientHeight < 60);

    inner.innerHTML = '';

    var msgs = (state.currentSession && state.currentSession.messages) || [];
    if (msgs.length === 0) {
      inner.appendChild(renderWelcomeState());
    } else {
      msgs.forEach(function (m, idx) {
        inner.appendChild(renderMessageNode(m, idx, msgs));
      });
    }

    if (preserveScroll && !wasNearBottom && feed) {
      feed.scrollTop = prevTop;
    } else {
      scrollFeedToBottom();
      eachNode(inner.querySelectorAll('img.msg-thumb'), function (imgEl) {
        if (!imgEl.complete) {
          imgEl.addEventListener('load', function onImgLoad() {
            imgEl.removeEventListener('load', onImgLoad);
            scrollFeedToBottom();
          });
        }
      });
    }
  }

  function scrollFeedToBottom() {
    var feed = $('chatFeed');
    if (!feed) return;
    feed.scrollTop = feed.scrollHeight;
    if (typeof global.requestAnimationFrame === 'function') {
      global.requestAnimationFrame(function () {
        feed.scrollTop = feed.scrollHeight;
      });
    }
    setTimeout(function () {
      feed.scrollTop = feed.scrollHeight;
    }, 40);
  }

  // ───────── Helpers: Clipboard, Re-run, Images ─────────

  function copyToClipboard(text, btnEl) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
      } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }
      if (btnEl) {
        var orig = btnEl.textContent;
        btnEl.textContent = 'Copied!';
        setTimeout(function () { btnEl.textContent = orig; }, 1200);
      }
    } catch (e) {}
  }

  function rerunJsxScript(jsxCode, label) {
    if (!state.hostInfo.isAdobe) {
      alert('Open this panel inside Adobe Photoshop or Illustrator to re-run JSX scripts.');
      return;
    }
    CepBridge.evalScriptSafe(jsxCode).then(function (res) {
      return refreshDocContext().then(function () {
        if (res && res.ok) {
          addSystemNote('✓ Re-ran "' + (label || 'script.jsx') + '" successfully.');
        } else {
          addSystemNote('✕ Re-run error: ' + ((res && res.error) || 'Unknown error'));
        }
      });
    })['catch'](function (e) {
      addSystemNote('✕ Re-run failed: ' + (e && e.message ? e.message : String(e)));
    });
  }

  function addSystemNote(text, opts) {
    if (!state.currentSession) return;
    var note = {
      id: 'msg_' + Date.now(),
      role: 'assistant',
      timestamp: Date.now(),
      action: 'chat',
      isSystemNote: true,
      content: text
    };
    if (opts && opts.showAddApiButton) {
      note.showAddApiButton = true;
      if (opts.addApiButtonLabel) note.addApiButtonLabel = opts.addApiButtonLabel;
    }
    state.currentSession.messages.push(note);
    state.currentSession.updatedAt = Date.now();
    storage.saveSession(state.currentSession);
    renderChatFeed();
  }

  function renderPendingImages() {
    var bar = $('pendingImagesBar');
    bar.innerHTML = '';
    if (state.pendingImages.length === 0) {
      bar.classList.add('hidden');
      return;
    }
    bar.classList.remove('hidden');
    state.pendingImages.forEach(function (img, idx) {
      var chip = document.createElement('div');
      chip.className = 'pending-img-chip';
      chip.innerHTML =
        '<img src="' + img.dataUrl + '" title="' + escapeHtml(img.name) + '">' +
        '<button type="button" class="pending-img-remove" title="Remove">×</button>';
      chip.querySelector('.pending-img-remove').addEventListener('click', function () {
        state.pendingImages.splice(idx, 1);
        renderPendingImages();
      });
      bar.appendChild(chip);
    });
  }

  function handleImageFiles(fileList) {
    if (!fileList || fileList.length === 0) return;
    for (var i = 0; i < fileList.length; i++) {
      var file = fileList[i];
      if (!file.type || file.type.indexOf('image/') !== 0) continue;
      (function (f) {
        var reader = new FileReader();
        reader.onload = function (ev) {
          var rawUrl = ev.target.result;
          var diskPath = state.currentSession ? storage.saveUploadedImage(state.currentSession.id, rawUrl, f.name) : null;
          compressForVisionIfNeeded(rawUrl, function (visionUrl) {
            state.pendingImages.push({
              name: f.name || 'image.png',
              dataUrl: visionUrl,
              diskPath: diskPath
            });
            renderPendingImages();
          });
        };
        reader.readAsDataURL(f);
      })(file);
    }
  }

  function compressForVisionIfNeeded(dataUrl, cb) {
    if (!dataUrl || dataUrl.length < 1800000) {
      cb(dataUrl);
      return;
    }
    var img = new Image();
    img.onload = function () {
      var maxDim = 1400;
      var w = img.width;
      var h = img.height;
      if (w > maxDim || h > maxDim) {
        var s = Math.min(maxDim / w, maxDim / h);
        w = Math.round(w * s);
        h = Math.round(h * s);
      }
      var canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, w, h);
      cb(canvas.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = function () { cb(dataUrl); };
    img.src = dataUrl;
  }

  function normalizeCanvasPreviewDataUrl(dataUrl) {
    return new Promise(function (resolve) {
      if (!dataUrl) {
        resolve('');
        return;
      }
      var img = new Image();
      img.onload = function () {
        try {
          var maxDim = 1280;
          var w = img.width;
          var h = img.height;
          if (w > maxDim || h > maxDim) {
            var s = Math.min(maxDim / w, maxDim / h);
            w = Math.max(1, Math.round(w * s));
            h = Math.max(1, Math.round(h * s));
          }
          var canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          var ctx = canvas.getContext('2d');
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL('image/jpeg', 0.85));
        } catch (e) {
          resolve(dataUrl);
        }
      };
      img.onerror = function () { resolve(dataUrl); };
      img.src = dataUrl;
    });
  }

  function updateAutoCanvasButton() {
    var btn = $('autoCanvasBtn');
    if (!btn) return;
    var on = !!state.autoCaptureCanvas;
    setClass(btn, 'active', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    btn.title = on
      ? 'Auto-screenshot open Adobe project with prompt (ON) — click to turn OFF'
      : 'Auto-screenshot open Adobe project with prompt (OFF) — click to turn ON';
  }

  function updateAdvancedOptionsUI() {
    var recheckOn = !!state.recheckStock;
    var notifyOn = !!state.notifyOnComplete;
    var recheckToggle = $('recheckStockToggle');
    var notifyToggle = $('notifyCompleteToggle');
    var btn = $('advancedOptionsBtn');
    var dot = $('advancedStatusDot');
    if (recheckToggle) recheckToggle.checked = recheckOn;
    if (notifyToggle) notifyToggle.checked = notifyOn;
    if (btn) {
      setClass(btn, 'active', recheckOn);
      btn.title = 'Advanced Options (Alerts: ' + (notifyOn ? 'ON' : 'OFF') + ' · Stock Recheck: ' + (recheckOn ? 'ON' : 'OFF') + ')';
    }
    if (dot) {
      setClass(dot, 'hidden', !recheckOn);
    }
  }

  // ───────── Completion Sound, Toast & Desktop Notification ─────────

  var sharedAudioCtx = null;
  var toastTimer = null;

  function unlockAudioContext() {
    try {
      var AudioCtx = global.AudioContext || global.webkitAudioContext;
      if (!AudioCtx) return;
      if (!sharedAudioCtx) {
        sharedAudioCtx = new AudioCtx();
      }
      if (sharedAudioCtx.state === 'suspended' && typeof sharedAudioCtx.resume === 'function') {
        sharedAudioCtx.resume();
      }
      if (!CepBridge.hasCEP() && typeof global.Notification === 'function' && global.Notification.permission === 'default') {
        global.Notification.requestPermission();
      }
    } catch (e) {}
  }

  function playCompletionChime(kind) {
    try {
      var AudioCtx = global.AudioContext || global.webkitAudioContext;
      if (!AudioCtx) return;
      if (!sharedAudioCtx) {
        sharedAudioCtx = new AudioCtx();
      }
      if (sharedAudioCtx.state === 'suspended' && typeof sharedAudioCtx.resume === 'function') {
        sharedAudioCtx.resume();
      }
      var notes = kind === 'error'
        ? [330, 262]
        : (kind === 'design' ? [523.25, 659.25, 783.99] : [523.25, 659.25]);
      var now = sharedAudioCtx.currentTime;
      for (var i = 0; i < notes.length; i++) {
        var osc = sharedAudioCtx.createOscillator();
        var gain = sharedAudioCtx.createGain();
        var start = now + i * 0.11;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(notes[i], start);
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.11, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.28);
        osc.connect(gain);
        gain.connect(sharedAudioCtx.destination);
        osc.start(start);
        osc.stop(start + 0.3);
      }
    } catch (e) {}
  }

  function hideCompletionToast() {
    var toast = $('completionToast');
    if (toast) toast.classList.add('hidden');
    if (toastTimer) {
      clearTimeout(toastTimer);
      toastTimer = null;
    }
  }

  function showCompletionToast(title, msg, isError) {
    var toast = $('completionToast');
    if (!toast) return;
    if (toastTimer) clearTimeout(toastTimer);
    setClass(toast, 'err', !!isError);
    if ($('completionToastIcon')) $('completionToastIcon').textContent = isError ? '!' : '✓';
    if ($('completionToastTitle')) $('completionToastTitle').textContent = title || 'Task Complete';
    if ($('completionToastMsg')) $('completionToastMsg').textContent = msg || '';
    toast.classList.remove('hidden');
    toastTimer = setTimeout(hideCompletionToast, 5500);
  }

  function notifyTaskDone(kind, title, msg) {
    if (!state.notifyOnComplete) return;
    var isErr = kind === 'error';
    playCompletionChime(kind);
    showCompletionToast(title, msg, isErr);
    if (typeof CepBridge.showDesktopNotification === 'function') {
      CepBridge.showDesktopNotification(title, msg, isErr);
    }
  }

  // ───────── Auth, Credits, Remote Branding & Force Update ─────────

  function applyBrandingAndConfig(cfg) {
    if (!cfg || typeof cfg !== 'object') return;
    state.uiConfig = cfg;

    var prefix = cfg.brand_prefix || 'A Product by';
    var name = cfg.brand_name || 'FV Labs';
    var url = cfg.brand_url || 'https://fv-labs.vercel.app';
    var slogan = cfg.brand_slogan || 'Workflow Automation & AI Tools';
    var logoUrl = cfg.brand_logo_url || '';

    eachNode(document.querySelectorAll('.brand-prefix'), function (el) { el.textContent = prefix; });
    eachNode(document.querySelectorAll('.brand-name-text'), function (el) { el.textContent = name; });
    eachNode(document.querySelectorAll('.brand-slogan'), function (el) { el.textContent = slogan; });
    eachNode(document.querySelectorAll('.brand-link-el'), function (el) {
      el.onclick = function (ev) {
        ev.preventDefault();
        if (url) CepBridge.openURL(url);
      };
    });
    eachNode(document.querySelectorAll('.brand-logo-img'), function (el) {
      if (logoUrl) {
        el.src = logoUrl;
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    });

    if (cfg.theme_primary_color && String(cfg.theme_primary_color).toUpperCase() !== '#8A5A2B') {
      document.documentElement.style.setProperty('--accent', cfg.theme_primary_color);
      document.documentElement.style.setProperty('--accent-hover', cfg.theme_primary_color);
    }
    if (cfg.theme_bg_color) {
      document.documentElement.style.setProperty('--bg-gradient', cfg.theme_bg_color);
    }

    var annBar = $('announcementBar');
    if (cfg.announcement_visible && cfg.announcement_text) {
      annBar.classList.remove('hidden');
      annBar.style.backgroundColor = cfg.announcement_color || '#d97706';
      $('announcementText').textContent = cfg.announcement_text;
    } else {
      annBar.classList.add('hidden');
    }

    if (cfg.credit_price_text) {
      $('accPriceText').textContent = cfg.credit_price_text;
    }

    setupCustomLink('customLink1', cfg.link_visible, cfg.link_text, cfg.link_url);
    setupCustomLink('customLink2', cfg.link2_visible, cfg.link2_text, cfg.link2_url);
    setupCustomLink('customLink3', cfg.link3_visible, cfg.link3_text, cfg.link3_url);

    var currentVer = auth.getVersion();
    var latestVer = cfg.latest_version || currentVer;
    var isOutdated = auth.isVersionOlder(currentVer, latestVer);
    var mustLock = !!(cfg.require_update || (cfg.force_update && isOutdated));

    if (mustLock) {
      showForceUpdateLock(cfg);
      return;
    }

    hideForceUpdateLock();
    var banner = $('updateBanner');
    if (isOutdated) {
      banner.classList.remove('hidden');
      $('updateBannerText').textContent = '🚀 New Version v' + latestVer + ' Available! Click to Download';
      banner.onclick = function () {
        if (cfg.update_download_url) CepBridge.openURL(cfg.update_download_url);
      };
    } else {
      banner.classList.add('hidden');
    }
  }

  function setupCustomLink(id, visible, text, url) {
    var el = $(id);
    if (!el) return;
    if (visible && text && url) {
      el.classList.remove('hidden');
      el.textContent = text;
      el.onclick = function (ev) {
        ev.preventDefault();
        CepBridge.openURL(url);
      };
    } else {
      el.classList.add('hidden');
    }
  }

  function showForceUpdateLock(info) {
    state.isLockedUpdate = true;
    var cfg = Object.assign({}, state.uiConfig || {}, info || {});
    var currentVer = auth.getVersion();
    var latestVer = cfg.latest_version || 'New Version';
    var downloadUrl = cfg.update_download_url || cfg.brand_url || 'https://fv-labs.vercel.app';
    var msg = cfg.update_announcement_text || cfg.message || 'Your version is outdated. Please update to continue using Adobe AI Agent.';

    $('lockVersionCompare').textContent = 'v' + currentVer + ' → v' + latestVer;
    $('lockUpdateMsg').textContent = msg;
    $('lockUrlInput').value = downloadUrl;
    $('lockDownloadBtn').onclick = function () {
      CepBridge.openURL(downloadUrl);
    };
    $('lockCopyUrlBtn').onclick = function () {
      copyToClipboard(downloadUrl, $('lockCopyUrlBtn'));
    };
    $('updateLockOverlay').classList.remove('hidden');
  }

  function hideForceUpdateLock() {
    state.isLockedUpdate = false;
    $('updateLockOverlay').classList.add('hidden');
  }

  function openWhatsAppSupport() {
    var cfg = state.uiConfig || {};
    var phone = String(cfg.whatsapp_number || '8801795624600').replace(/[^0-9]/g, '');
    var emailNote = state.currentUser && state.currentUser.email ? (' (Email: ' + state.currentUser.email + ')') : '';
    var msg = (cfg.whatsapp_message || 'Hello, I want to upgrade or buy credits for Adobe AI Agent.') + emailNote;
    CepBridge.openURL('https://wa.me/' + phone + '?text=' + encodeURIComponent(msg));
  }

  function showLimitReachedModal(opts) {
    var title = (opts && opts.title) || '⚡ Daily Free Limit Reached';
    var msg = (opts && opts.message) || 'If you want to extend your limit up to 50 per day, please add your own API key.';
    var btnText = (opts && opts.addButtonText) || '🔑 Add API Key (Extend up to 50/day)';
    $('limitModalTitle').textContent = title;
    $('limitModalMessage').textContent = msg;
    $('limitAddApiBtn').textContent = btnText;
    $('limitReachedModal').classList.remove('hidden');
  }

  function closeLimitReachedModal() {
    $('limitReachedModal').classList.add('hidden');
  }

  function applyUserState(user) {
    var prevEmail = storage.getActiveAccountEmail();
    var nextEmail = (user && user.email) ? String(user.email).trim().toLowerCase() : '';
    state.currentUser = user || null;

    if (prevEmail !== nextEmail) {
      state.noApiNoticeDismissed = false;
      storage.setActiveAccount(user || null);
      state.pendingImages = [];
      renderPendingImages();
      initSession();
    }

    if (!user) {
      api.setUserGrade(3);
      $('loginMainView').classList.remove('hidden');
      $('blockedView').classList.add('hidden');
      $('loginOverlay').classList.remove('hidden');
      if ($('noApiNoticeBar')) $('noApiNoticeBar').classList.add('hidden');
      if ($('iconPresetBtn')) $('iconPresetBtn').classList.add('hidden');
      if ($('iconPresetModal')) $('iconPresetModal').classList.add('hidden');
      updateApiDot();
      renderSidebar();
      renderChatFeed();
      return;
    }

    if (user.is_blocked) {
      api.setUserGrade(3);
      $('loginMainView').classList.add('hidden');
      $('blockedView').classList.remove('hidden');
      $('loginOverlay').classList.remove('hidden');
      if ($('noApiNoticeBar')) $('noApiNoticeBar').classList.add('hidden');
      if ($('iconPresetBtn')) $('iconPresetBtn').classList.add('hidden');
      if ($('iconPresetModal')) $('iconPresetModal').classList.add('hidden');
      updateApiDot();
      return;
    }

    $('loginOverlay').classList.add('hidden');
    $('loginMainView').classList.remove('hidden');
    $('blockedView').classList.add('hidden');

    var grade = Number(user.grade || 3);
    api.setUserGrade(grade);

    var gradeClass = grade === 1 ? 'g1' : (grade === 2 ? 'g2' : 'g3');
    var gradeShort = grade === 1 ? '1st' : (grade === 2 ? '2nd' : '3rd');
    var gradeBadge = $('gradeShortBadge');
    gradeBadge.className = 'grade-tag ' + gradeClass;
    gradeBadge.textContent = gradeShort;

    var hasPersonalKey = !!api.getActiveKeyObj();
    var pill = $('accountPillBtn');
    var credits = Number(user.credits || 0);
    var dailyUsed = Number(user.daily_uses || 0);
    var adminUsed = Number(user.admin_api_uses_today != null ? user.admin_api_uses_today : dailyUsed);
    var freeLim = Number(user.effective_daily_limit != null ? user.effective_daily_limit : (grade === 2 ? 30 : 5));
    var byokLim = Number(user.byok_daily_limit != null ? user.byok_daily_limit : 50);

    // Update Account Modal info
    $('accUserEmail').textContent = user.email || '-';
    var accBadge = $('accGradeBadge');
    accBadge.className = 'grade-tag ' + gradeClass;
    accBadge.textContent = user.grade_label || (gradeShort + ' Grade');

    var extendBox = $('accExtendBox');
    if (grade === 1 || user.is_unlimited) {
      $('creditsBadgeText').textContent = '∞';
      pill.classList.remove('empty');
      $('accCreditsValue').textContent = '∞ Unlimited';
      $('accDailyRule').textContent = 'Admin Unlimited Access';
      if (extendBox) extendBox.classList.add('hidden');
    } else if (grade === 2) {
      if (hasPersonalKey) {
        $('creditsBadgeText').textContent = '∞';
        pill.classList.remove('empty');
        $('accCreditsValue').textContent = '∞ Unlimited (Personal API)';
        $('accDailyRule').textContent = '2nd Grade Unlimited BYOK + Model Select';
        if (extendBox) extendBox.classList.add('hidden');
      } else {
        $('creditsBadgeText').textContent = '⚡ ' + credits;
        setClass(pill, 'empty', credits <= 0);
        $('accCreditsValue').textContent = credits + ' / ' + freeLim;
        $('accDailyRule').textContent = 'Daily Admin API Limit: ' + freeLim;
        if (extendBox) {
          extendBox.classList.remove('hidden');
          $('accExtendText').textContent = 'Add your personal API key for best quality output & ∞ Unlimited daily use!';
          $('accAddApiBtn').textContent = '🔑 Add Personal API Key';
        }
      }
    } else {
      // Grade 3 (Free User): 5 free daily Admin API credits, extends up to 50/day with personal API key
      if (hasPersonalKey) {
        var byokRem = Math.max(0, byokLim - dailyUsed);
        $('creditsBadgeText').textContent = '⚡ ' + byokRem + '/' + byokLim;
        setClass(pill, 'empty', byokRem <= 0);
        $('accCreditsValue').textContent = byokRem + ' / ' + byokLim;
        $('accDailyRule').textContent = 'Personal API Limit: ' + byokLim + '/day (Used today: ' + dailyUsed + ')';
        if (extendBox) extendBox.classList.add('hidden');
      } else {
        var freeRem = Math.max(0, credits);
        $('creditsBadgeText').textContent = '⚡ ' + freeRem + '/' + freeLim;
        setClass(pill, 'empty', freeRem <= 0);
        $('accCreditsValue').textContent = freeRem + ' / ' + freeLim;
        $('accDailyRule').textContent = 'Free Daily Limit: ' + freeLim + ' (Used: ' + adminUsed + ')';
        if (extendBox) {
          extendBox.classList.remove('hidden');
          $('accExtendText').textContent = 'Add your own API key for best quality output & up to ' + byokLim + '/day!';
          $('accAddApiBtn').textContent = '🔑 Add API Key (' + byokLim + '/day)';
        }
      }
    }

    $('accAppVersionLabel').textContent = 'Version: v' + auth.getVersion();

    // Grade 1 & 2 can see JSX; Grade 3 public users cannot
    var showJsx = canViewJsx();
    setClass($('tabScriptsBtn'), 'hidden', !showJsx);
    if (!showJsx && state.sidebarTab === 'scripts') {
      state.sidebarTab = 'chats';
    }

    // Icon Set Preset is strictly for 1st Grade (Admin) & 2nd Grade users only
    var allowIconPreset = canUseIconPreset();
    setClass($('iconPresetBtn'), 'hidden', !allowIconPreset);
    if (!allowIconPreset && $('iconPresetModal')) {
      $('iconPresetModal').classList.add('hidden');
    }

    var noticeBar = $('noApiNoticeBar');
    if (noticeBar) {
      if (!hasPersonalKey && !state.noApiNoticeDismissed) {
        $('noApiNoticeText').textContent = '✨ ' + getApiUpgradeTipText();
        noticeBar.classList.remove('hidden');
      } else {
        noticeBar.classList.add('hidden');
      }
    }

    if (grade === 1 || user.is_unlimited) {
      $('composerFooterHint').textContent = hasPersonalKey
        ? 'Auto-detects host app (CC 2015–2026) · Unlimited Access · Personal API Active'
        : 'Auto-detects host app (CC 2015–2026) · Unlimited Access · Add API key for best quality & higher limits';
    } else if (grade === 2) {
      $('composerFooterHint').textContent = hasPersonalKey
        ? 'Auto-detects host app (CC 2015–2026) · ∞ Unlimited Personal API Active · Chat & JSX saved'
        : 'Auto-detects host app (CC 2015–2026) · ' + credits + ' credits left · Add API key for best quality & ∞ Unlimited';
    } else {
      $('composerFooterHint').textContent = hasPersonalKey
        ? 'Auto-detects host app (CC 2015–2026) · Personal API Active (' + Math.max(0, byokLim - dailyUsed) + '/' + byokLim + ' left today)'
        : 'Auto-detects host app (CC 2015–2026) · ' + Math.max(0, credits) + '/' + freeLim + ' Free Credits · Add API key for best quality & ' + byokLim + '/day';
    }

    updateApiDot();
    renderSidebar();
    renderChatFeed(true);
  }

  function syncRemoteSessionAndConfig() {
    return auth.fetchUiConfig().then(function (cfg) {
      applyBrandingAndConfig(cfg);
    })['catch'](function () {})
      .then(function () {
        if (state.isLockedUpdate) return;
        if (!auth.token) {
          applyUserState(null);
          return;
        }
        $('loginStatusMsg').className = 'login-msg';
        $('loginStatusMsg').textContent = 'Restoring session...';
        return auth.verifyUser().then(function (verify) {
          if (verify && verify.require_update) {
            showForceUpdateLock(verify);
            return;
          }
          if (verify && verify.success && verify.user) {
            $('loginStatusMsg').textContent = '';
            applyUserState(verify.user);
          } else {
            $('loginStatusMsg').textContent = '';
            applyUserState(null);
          }
        })['catch'](function (err) {
          if (auth.user) {
            applyUserState(auth.user);
          } else {
            $('loginStatusMsg').className = 'login-msg err';
            $('loginStatusMsg').textContent = (err && err.message) || 'Server connection failed.';
            applyUserState(null);
          }
        });
      });
  }

  function startGoogleLoginFlow() {
    var msgEl = $('loginStatusMsg');
    msgEl.className = 'login-msg';
    msgEl.textContent = 'Connecting to server...';

    auth.startLogin().then(function (data) {
      state.currentLoginUrl = data.loginUrl;
      $('loginUrlDisplay').value = data.loginUrl;
      $('fallbackLoginBox').classList.remove('hidden');
      msgEl.textContent = 'Browser opened. Complete Google sign-in...';

      CepBridge.openURL(data.loginUrl);

      auth.pollLogin(
        data.sessionId,
        function (user) {
          msgEl.className = 'login-msg ok';
          msgEl.textContent = 'Login successful!';
          applyUserState(user);
        },
        function (err) {
          msgEl.className = 'login-msg err';
          msgEl.textContent = (err && err.message) || 'Login expired. Please try again.';
        }
      );
    })['catch'](function (err) {
      msgEl.className = 'login-msg err';
      msgEl.textContent = (err && err.message) || 'Server connection failed.';
    });
  }

  function handleLogout() {
    auth.clearAuth();
    $('accountModal').classList.add('hidden');
    $('fallbackLoginBox').classList.add('hidden');
    $('loginStatusMsg').textContent = '';
    applyUserState(null);
  }

  // ───────── Send / Agent Turn Flow ─────────

  function handleSend() {
    if (state.isBusy) {
      api.requestStop();
      return;
    }

    var text = $('chatInput').value.trim();
    var images = state.pendingImages.slice();
    if (!text && images.length === 0) return;

    executePromptTurn(text, images, { fromComposer: true });
  }

  function executePromptTurn(rawText, rawImages, options) {
    var opts = options || {};
    if (state.isBusy) return;

    if (state.isLockedUpdate) {
      showForceUpdateLock(state.uiConfig || {});
      return;
    }

    if (!state.currentUser || !auth.token) {
      applyUserState(null);
      return;
    }

    var text = String(rawText || '').trim();
    var images = cloneUserImages(rawImages);
    if (!text && images.length === 0) return;

    if (state.notifyOnComplete) {
      unlockAudioContext();
    }

    var hasPersonalKey = !!api.getActiveKeyObj();

    // Authorize & deduct 1 credit on server BEFORE running AI turn
    setBusy(true);
    auth.useCredit({ hostApp: state.hostInfo.app, hasPersonalKey: hasPersonalKey }).then(function (creditRes) {
      if (creditRes.requireUpdate) {
        setBusy(false);
        showForceUpdateLock(creditRes);
        return;
      }
      if (creditRes.unauthenticated) {
        setBusy(false);
        applyUserState(null);
        $('loginStatusMsg').className = 'login-msg err';
        $('loginStatusMsg').textContent = creditRes.message || 'Please sign in again.';
        return;
      }
      if (creditRes.blocked) {
        setBusy(false);
        applyUserState(Object.assign({}, state.currentUser, { is_blocked: true }));
        return;
      }
      if (!creditRes.success) {
        setBusy(false);
        if (creditRes.user) applyUserState(creditRes.user);
        if (creditRes.outOfCredits) {
          if (creditRes.canExtendWithApi) {
            var extMsg = creditRes.message || 'Your 5 free daily credits are finished. If you want to extend your limit up to 50 per day, please add your API key.';
            showLimitReachedModal({
              title: '⚡ 5 Free Credits Finished',
              message: extMsg,
              addButtonText: '🔑 Add API Key (Extend up to ' + (creditRes.extendedLimit || 50) + '/day)'
            });
            addSystemNote('⚠️ ' + extMsg, {
              showAddApiButton: true,
              addApiButtonLabel: '🔑 Add API Key (Extend to ' + (creditRes.extendedLimit || 50) + '/day)'
            });
          } else if (creditRes.canExtendUnlimitedWithApi) {
            var g2Msg = creditRes.message || 'Your daily Admin API credits are finished. Add your personal API key for unlimited use!';
            showLimitReachedModal({
              title: '⚡ Admin Credits Finished',
              message: g2Msg,
              addButtonText: '🔑 Add Personal API Key (∞ Unlimited)'
            });
            addSystemNote('⚠️ ' + g2Msg, {
              showAddApiButton: true,
              addApiButtonLabel: '🔑 Add Personal API Key (Unlimited)'
            });
          } else {
            $('accountModal').classList.remove('hidden');
            addSystemNote('⚠️ ' + (creditRes.message || 'Daily credits finished. Resets at 12:00 AM BD Time.'));
          }
        } else {
          alert(creditRes.message || 'Could not authorize request.');
        }
        return;
      }

      if (creditRes.user) {
        applyUserState(creditRes.user);
      }

      // Store short-lived Admin API turnToken (empty when using personal key)
      api.setTurnToken(creditRes.turnToken || '');

      if (!state.currentSession) createNewSession();

      var capturePromise = Promise.resolve(null);
      if (state.hostInfo.isAdobe && state.autoCaptureCanvas && typeof CepBridge.captureActivePreview === 'function') {
        var sessionPaths = storage.getStoragePaths(state.currentSession.id);
        capturePromise = CepBridge.captureActivePreview(sessionPaths.tempDir).then(function (cap) {
          if (!cap || !cap.dataUrl) return null;
          return normalizeCanvasPreviewDataUrl(cap.dataUrl).then(function (normUrl) {
            if (!normUrl) return null;
            return {
              name: cap.name,
              docName: cap.docName,
              dataUrl: normUrl,
              isAutoCanvas: true
            };
          });
        })['catch'](function () { return null; });
      }

      capturePromise.then(function (canvasImg) {
        if (canvasImg) {
          images.push(canvasImg);
        }

        var sessionMsgs = state.currentSession.messages || [];
        var userMsg = null;

        if (
          opts.replaceAssistantMsg &&
          opts.reuseUserMsg &&
          sessionMsgs.length >= 2 &&
          sessionMsgs[sessionMsgs.length - 1] === opts.replaceAssistantMsg &&
          sessionMsgs[sessionMsgs.length - 2] === opts.reuseUserMsg
        ) {
          sessionMsgs.pop();
          userMsg = opts.reuseUserMsg;
          userMsg.timestamp = Date.now();
          userMsg.images = images;
        } else if (
          opts.reuseDanglingUserMsg &&
          sessionMsgs.length >= 1 &&
          sessionMsgs[sessionMsgs.length - 1] === opts.reuseDanglingUserMsg
        ) {
          userMsg = opts.reuseDanglingUserMsg;
          userMsg.timestamp = Date.now();
          userMsg.images = images;
        } else {
          userMsg = {
            id: 'msg_' + Date.now(),
            role: 'user',
            timestamp: Date.now(),
            content: text || '(Attached reference image)',
            images: images
          };
          if (sessionMsgs.length === 0 && text) {
            state.currentSession.title = text.slice(0, 42) + (text.length > 42 ? '...' : '');
          }
          sessionMsgs.push(userMsg);
        }

        state.currentSession.hostApp = state.hostInfo.app;
        state.currentSession.messages = sessionMsgs;
        state.currentSession.updatedAt = Date.now();
        storage.saveSession(state.currentSession);

        if (opts.fromComposer) {
          $('chatInput').value = '';
          autoResizeTextarea();
          state.pendingImages = [];
          renderPendingImages();
        }
        renderSidebar();
        renderChatFeed();

        // Show thinking indicator
        var thinkingEl = document.createElement('div');
        thinkingEl.className = 'thinking-bar';
        thinkingEl.innerHTML =
          '<div class="spinner"></div>' +
          '<div class="thinking-copy">' +
            '<span id="thinkingLabel">Working on your request...</span>' +
            '<span class="thinking-eta">Please wait — this normally takes 1–2 minutes.</span>' +
          '</div>';
        $('chatFeedInner').appendChild(thinkingEl);
        scrollFeedToBottom();

        api.stopRequested = false;
        agent.runTurn(state.currentSession, userMsg, function (statusText) {
          var lbl = document.getElementById('thinkingLabel');
          if (lbl) lbl.textContent = statusText;
        }, {
          recheckStock: !!state.recheckStock,
          normalizePreviewFn: normalizeCanvasPreviewDataUrl
        }).then(function (assistantMsg) {
          if (thinkingEl.parentNode) thinkingEl.parentNode.removeChild(thinkingEl);
          if (!hasPersonalKey) {
            assistantMsg.usedAdminApi = true;
          }

          state.currentSession.messages.push(assistantMsg);
          if (assistantMsg.execution && assistantMsg.execution.jsxScript) {
            state.currentSession.scripts = state.currentSession.scripts || [];
            state.currentSession.scripts.push({
              timestamp: assistantMsg.timestamp,
              hostLabel: assistantMsg.execution.hostLabel,
              scriptName: assistantMsg.execution.scriptName,
              scriptFile: assistantMsg.execution.scriptFile,
              scriptPath: assistantMsg.execution.scriptPath,
              jsxScript: assistantMsg.execution.jsxScript
            });
          }
          state.currentSession.updatedAt = Date.now();
          storage.saveSession(state.currentSession);
          return refreshDocContext().then(function () {
            if (assistantMsg.execution && assistantMsg.execution.ok) {
              var hostLbl = assistantMsg.execution.hostLabel || 'Adobe';
              var fileCount = Array.isArray(assistantMsg.execution.exportedFiles) ? assistantMsg.execution.exportedFiles.length : 0;
              var doneBody = fileCount > 0
                ? ('Completed in ' + hostLbl + ' (' + fileCount + ' file' + (fileCount > 1 ? 's' : '') + ' exported).')
                : ('Completed in ' + hostLbl + '.');
              notifyTaskDone('design', 'Design Ready — Adobe AI Agent', doneBody);
            } else if (assistantMsg.execution && !assistantMsg.execution.ok) {
              notifyTaskDone('error', 'Execution Issue — Adobe AI Agent', assistantMsg.execution.error || 'Could not complete script execution.');
            } else if (assistantMsg.action === 'ask_user') {
              notifyTaskDone('reply', 'Input Needed — Adobe AI Agent', assistantMsg.content || 'AI asked a follow-up question.');
            } else {
              notifyTaskDone('reply', 'Response Ready — Adobe AI Agent', assistantMsg.content || 'AI replied in chat.');
            }
          });
        })['catch'](function (err) {
          if (thinkingEl.parentNode) thinkingEl.parentNode.removeChild(thinkingEl);
          var errMsg = (err && err.message) ? err.message : String(err);
          state.currentSession.messages.push({
            id: 'msg_' + Date.now(),
            role: 'assistant',
            timestamp: Date.now(),
            action: 'chat',
            isError: true,
            content: 'Error: ' + errMsg
          });
          state.currentSession.updatedAt = Date.now();
          storage.saveSession(state.currentSession);
          if (!api.stopRequested && errMsg !== 'Stopped by user') {
            notifyTaskDone('error', 'Request Failed — Adobe AI Agent', errMsg);
          }
        }).then(function () {
          api.setTurnToken('');
          setBusy(false);
          renderSidebar();
          renderChatFeed();
        });
      });
    })['catch'](function (authErr) {
      setBusy(false);
      api.setTurnToken('');
      alert((authErr && authErr.message) || 'Cannot verify credits with server. Check your internet connection.');
    });
  }

  function setBusy(busy) {
    state.isBusy = busy;
    setClass(document.body, 'is-busy', !!busy);
    eachNode(document.querySelectorAll('.msg-actions-row button'), function (btn) {
      btn.disabled = !!busy;
    });
    var sendBtn = $('sendBtn');
    if (busy) {
      sendBtn.classList.add('stop');
      sendBtn.textContent = '■';
      sendBtn.title = 'Stop';
    } else {
      sendBtn.classList.remove('stop');
      sendBtn.textContent = '➤';
      sendBtn.title = 'Send';
    }
  }

  function autoResizeTextarea() {
    var ta = $('chatInput');
    ta.style.height = 'auto';
    ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
  }

  // ───────── API Settings Modal (Metadata-Generator Style) ─────────

  function updateApiDot() {
    var dot = $('apiStatusDot');
    var btn = $('openApiModalBtn');
    var hasKey = !!api.getActiveKeyObj();
    var hasAdminCredits = !!(state.currentUser && (Number(state.currentUser.credits || 0) > 0 || state.currentUser.is_unlimited || Number(state.currentUser.grade) === 1));

    if (dot) {
      dot.classList.remove('ready', 'needs-key');
      if (hasKey) {
        dot.classList.add('ready');
      } else if (hasAdminCredits) {
        dot.classList.add('needs-key');
      }
    }
    if (btn) {
      if (hasKey) {
        btn.classList.remove('needs-key');
        btn.title = 'Personal API Key Active — Settings';
      } else if (hasAdminCredits) {
        btn.classList.add('needs-key');
        btn.title = 'No Personal API Key Added — Click to Add Key for Best Quality & Higher Limits';
      } else {
        btn.classList.add('needs-key');
        btn.title = 'No API Key Added — Click to Add API Key';
      }
    }
  }

  function openApiModal() {
    renderApiModal();
    $('apiSettingsModal').classList.remove('hidden');
  }

  function closeApiModal() {
    $('apiSettingsModal').classList.add('hidden');
    if (state.currentUser) {
      applyUserState(state.currentUser);
    } else {
      updateApiDot();
    }
  }

  function renderApiModal() {
    var allowModels = canSelectModels();
    var grade = state.currentUser ? Number(state.currentUser.grade || 3) : 3;
    var hasKey = !!api.getActiveKeyObj();

    setClass($('btnKeyAuto'), 'active', api.mode === 'auto');
    setClass($('btnKeyManual'), 'active', api.mode === 'manual');
    setClass($('btnModelAuto'), 'active', api.modelMode === 'auto');
    setClass($('btnModelSingle'), 'active', api.modelMode === 'single');

    // Tier banner & hiding model controls strictly for 3rd grade users
    var modalTitle = $('apiModalTitle');
    var tierBanner = $('apiTierBanner');
    var modelSection = $('modelSettingsSection');

    if (allowModels) {
      if (modalTitle) modalTitle.textContent = '⚙️ API Key & Model Settings';
      if (modelSection) modelSection.classList.remove('hidden');
      if (tierBanner) {
        tierBanner.className = 'api-tier-banner' + (hasKey || grade === 1 ? ' active-tier' : '');
        if (grade === 1 || (state.currentUser && state.currentUser.is_unlimited)) {
          tierBanner.textContent = hasKey
            ? '👑 1st Grade (Unlimited Access) · Personal API active · Model priority unlocked.'
            : '👑 1st Grade (Unlimited Access) · Add your own API key for best quality output & higher limits.';
        } else {
          tierBanner.textContent = hasKey
            ? '⚡ 2nd Grade (Unlimited Mode Active) · Personal API enabled + Model selection unlocked.'
            : '⚡ 2nd Grade: Add your own API key for best quality output & ∞ Unlimited daily usage (or use ' + (state.currentUser && state.currentUser.effective_daily_limit != null ? state.currentUser.effective_daily_limit : 30) + '/day included credits).';
        }
      }
    } else {
      if (modalTitle) modalTitle.textContent = '🔑 Personal API Key Settings';
      if (modelSection) modelSection.classList.add('hidden');
      if (tierBanner) {
        var freeLim = (state.currentUser && state.currentUser.effective_daily_limit != null) ? state.currentUser.effective_daily_limit : 5;
        var byokLim = (state.currentUser && state.currentUser.byok_daily_limit != null) ? state.currentUser.byok_daily_limit : 50;
        tierBanner.className = 'api-tier-banner' + (hasKey ? ' active-tier' : '');
        tierBanner.textContent = hasKey
          ? '✓ Personal API Key Active: Best quality output enabled & daily limit extended to ' + byokLim + '/day!'
          : '🎁 Free Plan: ' + freeLim + ' daily credits included (no key needed). Add your own API key below for best quality output & up to ' + byokLim + '/day!';
      }
    }

    // Keys list
    var keyUl = $('apiKeyList');
    keyUl.innerHTML = '';
    if (api.keys.length === 0) {
      keyUl.innerHTML = '<li class="api-key-item" style="color:var(--text-muted); justify-content:center;">No personal API keys added yet.</li>';
    } else {
      api.keys.forEach(function (kObj, idx) {
        var li = document.createElement('li');
        li.className = 'api-key-item';
        var masked = kObj.key.slice(0, 6) + '••••' + kObj.key.slice(-4);
        var res = state.keyTestResults[idx];
        var resHtml = res ? ('<span class="test-msg ' + (res.success ? 'ok' : 'err') + '">' + escapeHtml(res.message) + '</span>') : '';

        li.innerHTML =
          '<div class="item-left">' +
            (api.mode === 'manual' ? '<input type="radio" name="manualKeySelect" ' + (api.selectedKeyIndex === idx ? 'checked' : '') + '>' : '') +
            '<span class="badge-provider">' + escapeHtml(kObj.provider) + '</span>' +
            '<span style="font-family:var(--font-mono);">' + escapeHtml(masked) + '</span>' +
            resHtml +
          '</div>' +
          '<div class="item-right">' +
            '<button type="button" class="btn small btn-test-key">Test</button>' +
            '<button type="button" class="btn small btn-del-key">✕</button>' +
          '</div>';

        var radio = li.querySelector('input[type="radio"]');
        if (radio) {
          radio.addEventListener('change', function () {
            api.selectKey(idx);
            renderApiModal();
          });
        }
        li.querySelector('.btn-test-key').addEventListener('click', function (ev) {
          var btn = ev.target;
          btn.textContent = '...';
          api.testConnection(kObj.key, kObj.provider).then(function (testRes) {
            state.keyTestResults[idx] = testRes;
            renderApiModal();
          });
        });
        li.querySelector('.btn-del-key').addEventListener('click', function () {
          delete state.keyTestResults[idx];
          api.removeKey(idx);
          renderApiModal();
          if (state.currentUser) applyUserState(state.currentUser);
          else updateApiDot();
        });
        keyUl.appendChild(li);
      });
    }

    // Gemini Model list (strictly 1st & 2nd Grade only)
    var modUl = $('modelList');
    modUl.innerHTML = '';
    if (!allowModels) return;

    api.geminiModels.forEach(function (m, idx) {
      var li = document.createElement('li');
      li.className = 'model-item';
      var tRes = state.modelTestResults[m.id];
      var tHtml = tRes ? ('<span class="test-msg ' + (tRes.success ? 'ok' : 'err') + '">' + escapeHtml(tRes.message) + '</span>') : '';

      var toggleHtml = api.modelMode === 'single'
        ? '<input type="radio" name="singleModelSelect" ' + (api.selectedModel === m.id ? 'checked' : '') + '>'
        : '<input type="checkbox" ' + (m.enabled !== false ? 'checked' : '') + '>';

      var agentBadge = m.kind === 'agent'
        ? ' <span class="badge-provider" style="margin-left:4px;">AGENT</span>'
        : '';

      li.innerHTML =
        '<div class="item-left">' +
          toggleHtml +
          '<span style="font-family:var(--font-mono); font-weight:700; color:var(--text-secondary); width:22px;">#' + (idx + 1) + '</span>' +
          '<div style="min-width:0;">' +
            '<div style="font-weight:700; color:var(--text-primary);">' + escapeHtml(m.name) + agentBadge + '</div>' +
            '<div style="font-size:0.73rem; font-weight:600; color:var(--text-secondary); font-family:var(--font-mono);">' + escapeHtml(m.id) + ' · ' + m.rpm + ' RPM · ' + m.rpd + ' RPD</div>' +
            tHtml +
          '</div>' +
        '</div>' +
        '<div class="item-right">' +
          '<button type="button" class="btn small btn-up" title="Move up">▲</button>' +
          '<button type="button" class="btn small btn-down" title="Move down">▼</button>' +
          '<button type="button" class="btn small btn-test-mod">Test</button>' +
        '</div>';

      var input = li.querySelector('input');
      input.addEventListener('change', function () {
        if (api.modelMode === 'single') {
          api.setSelectedModel(m.id);
        } else {
          api.toggleModelEnabled(m.id, input.checked);
        }
        renderApiModal();
      });

      li.querySelector('.btn-up').addEventListener('click', function () {
        if (idx > 0) {
          api.reorderGeminiModels(idx, idx - 1);
          renderApiModal();
        }
      });
      li.querySelector('.btn-down').addEventListener('click', function () {
        if (idx < api.geminiModels.length - 1) {
          api.reorderGeminiModels(idx, idx + 1);
          renderApiModal();
        }
      });
      li.querySelector('.btn-test-mod').addEventListener('click', function (ev) {
        var btn = ev.target;
        btn.textContent = '...';
        api.testGeminiModel(m.id).then(function (testRes) {
          state.modelTestResults[m.id] = testRes;
          renderApiModal();
        });
      });

      modUl.appendChild(li);
    });
  }

  // ───────── Event Binding & Init ─────────

  function bindEvents() {
    $('toggleSidebarBtn').addEventListener('click', function () {
      $('historySidebar').classList.toggle('collapsed');
    });
    $('closeSidebarBtn').addEventListener('click', function () {
      closeSidebar();
    });
    $('newChatBtn').addEventListener('click', function () {
      createNewSession();
      closeSidebar();
    });

    $('tabChatsBtn').addEventListener('click', function () {
      state.sidebarTab = 'chats';
      renderSidebar();
    });
    $('tabScriptsBtn').addEventListener('click', function () {
      state.sidebarTab = 'scripts';
      renderSidebar();
    });

    $('openStorageBtn').addEventListener('click', function () {
      var paths = storage.getStoragePaths(state.currentSession ? state.currentSession.id : 'default');
      var targetDir = canViewJsx() ? paths.rootDir : paths.exportsDir;
      if (!CepBridge.openFolderInExplorer(targetDir)) {
        alert('Storage directory: ' + targetDir);
      }
    });

    // Auth, Account & Force-Update Controls
    $('googleLoginBtn').addEventListener('click', startGoogleLoginFlow);
    $('copyLoginUrlBtn').addEventListener('click', function () {
      if (state.currentLoginUrl) {
        copyToClipboard(state.currentLoginUrl, $('copyLoginUrlBtn'));
      }
    });
    $('blockedWhatsappBtn').addEventListener('click', openWhatsAppSupport);
    $('blockedLogoutBtn').addEventListener('click', handleLogout);
    $('lockRecheckBtn').addEventListener('click', syncRemoteSessionAndConfig);

    $('accountPillBtn').addEventListener('click', function () {
      $('accountModal').classList.remove('hidden');
    });
    $('closeAccountModalBtn').addEventListener('click', function () {
      $('accountModal').classList.add('hidden');
    });
    $('doneAccountModalBtn').addEventListener('click', function () {
      $('accountModal').classList.add('hidden');
    });
    if ($('accAddApiBtn')) {
      $('accAddApiBtn').addEventListener('click', function () {
        $('accountModal').classList.add('hidden');
        openApiModal();
      });
    }
    $('accWhatsappBtn').addEventListener('click', openWhatsAppSupport);
    $('logoutBtn').addEventListener('click', handleLogout);
    $('refreshAccountBtn').addEventListener('click', function () {
      var btn = $('refreshAccountBtn');
      btn.textContent = '...';
      syncRemoteSessionAndConfig().then(function () {
        btn.textContent = '↻ Sync Credits';
      });
    });

    // Limit Reached -> Extend to 50/day Modal Controls
    if ($('closeLimitModalBtn')) $('closeLimitModalBtn').addEventListener('click', closeLimitReachedModal);
    if ($('dismissLimitModalBtn')) $('dismissLimitModalBtn').addEventListener('click', closeLimitReachedModal);
    if ($('limitAddApiBtn')) {
      $('limitAddApiBtn').addEventListener('click', function () {
        closeLimitReachedModal();
        openApiModal();
      });
    }
    if ($('limitGetKeyLink')) {
      $('limitGetKeyLink').addEventListener('click', function (ev) {
        ev.preventDefault();
        CepBridge.openURL('https://aistudio.google.com/apikey');
      });
    }
    if ($('limitOpenAccountBtn')) {
      $('limitOpenAccountBtn').addEventListener('click', function () {
        closeLimitReachedModal();
        $('accountModal').classList.remove('hidden');
      });
    }

    $('refreshContextBtn').addEventListener('click', refreshDocContext);
    if ($('noApiNoticeBtn')) {
      $('noApiNoticeBtn').addEventListener('click', openApiModal);
    }
    if ($('noApiNoticeCloseBtn')) {
      $('noApiNoticeCloseBtn').addEventListener('click', function () {
        state.noApiNoticeDismissed = true;
        if ($('noApiNoticeBar')) $('noApiNoticeBar').classList.add('hidden');
      });
    }
    $('openApiModalBtn').addEventListener('click', openApiModal);
    $('closeApiModalBtn').addEventListener('click', closeApiModal);
    $('doneApiModalBtn').addEventListener('click', closeApiModal);

    $('getGeminiKeyLink').addEventListener('click', function (ev) {
      ev.preventDefault();
      CepBridge.openURL('https://aistudio.google.com/apikey');
    });

    $('addKeyBtn').addEventListener('click', function () {
      var val = $('newApiKeyInput').value;
      var prov = $('providerSelect').value;
      var count = api.addKey(val, prov);
      if (count > 0) {
        $('newApiKeyInput').value = '';
        $('keyTestStatusMsg').className = 'test-msg ok';
        $('keyTestStatusMsg').textContent = 'Added ' + count + ' key(s).';
        renderApiModal();
        if (state.currentUser) applyUserState(state.currentUser);
        else updateApiDot();
      }
    });

    $('uploadKeysTxtBtn').addEventListener('click', function () {
      $('keysTxtInput').click();
    });
    $('keysTxtInput').addEventListener('change', function (ev) {
      var file = ev.target.files && ev.target.files[0];
      if (!file) return;
      var r = new FileReader();
      r.onload = function (e) {
        var added = api.addKey(e.target.result, $('providerSelect').value);
        $('keyTestStatusMsg').className = 'test-msg ok';
        $('keyTestStatusMsg').textContent = 'Loaded ' + added + ' key(s) from .txt';
        renderApiModal();
        if (state.currentUser) applyUserState(state.currentUser);
        else updateApiDot();
      };
      r.readAsText(file);
      ev.target.value = '';
    });

    $('btnKeyAuto').addEventListener('click', function () {
      api.setMode('auto');
      renderApiModal();
    });
    $('btnKeyManual').addEventListener('click', function () {
      api.setMode('manual');
      renderApiModal();
    });

    $('testActiveKeyBtn').addEventListener('click', function () {
      $('keyTestStatusMsg').className = 'test-msg';
      $('keyTestStatusMsg').textContent = 'Testing...';
      api.testConnection().then(function (res) {
        $('keyTestStatusMsg').className = 'test-msg ' + (res.success ? 'ok' : 'err');
        $('keyTestStatusMsg').textContent = res.message;
      });
    });

    $('btnModelAuto').addEventListener('click', function () {
      if (!canSelectModels()) return;
      api.setModelMode('auto');
      renderApiModal();
    });
    $('btnModelSingle').addEventListener('click', function () {
      if (!canSelectModels()) return;
      api.setModelMode('single');
      renderApiModal();
    });

    $('testAllModelsBtn').addEventListener('click', function () {
      if (!canSelectModels()) return;
      $('modelTestStatusMsg').className = 'test-msg';
      $('modelTestStatusMsg').textContent = 'Testing models...';
      var seq = Promise.resolve();
      api.geminiModels.forEach(function (m) {
        seq = seq.then(function () {
          return api.testGeminiModel(m.id).then(function (res) {
            state.modelTestResults[m.id] = res;
            renderApiModal();
          });
        });
      });
      seq.then(function () {
        $('modelTestStatusMsg').className = 'test-msg ok';
        $('modelTestStatusMsg').textContent = 'Done';
      });
    });

    $('resetModelsBtn').addEventListener('click', function () {
      if (!canSelectModels()) return;
      state.modelTestResults = {};
      api.resetGeminiModels();
      renderApiModal();
    });

    // Chat Composer
    $('sendBtn').addEventListener('click', handleSend);
    $('chatInput').addEventListener('input', autoResizeTextarea);
    $('chatInput').addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && !ev.shiftKey) {
        ev.preventDefault();
        handleSend();
      }
    });

    $('attachImageBtn').addEventListener('click', function () {
      $('imageFileInput').click();
    });
    if ($('autoCanvasBtn')) {
      $('autoCanvasBtn').addEventListener('click', function () {
        state.autoCaptureCanvas = !state.autoCaptureCanvas;
        try {
          global.localStorage.setItem('adobe_ai_agent_auto_canvas', state.autoCaptureCanvas ? 'true' : 'false');
        } catch (e) {}
        updateAutoCanvasButton();
      });
    }
    if ($('advancedOptionsBtn') && $('advancedOptionsPanel')) {
      $('advancedOptionsBtn').addEventListener('click', function (ev) {
        ev.stopPropagation();
        var panel = $('advancedOptionsPanel');
        var opening = panel.classList.contains('hidden');
        setClass(panel, 'hidden', !opening);
        $('advancedOptionsBtn').setAttribute('aria-expanded', opening ? 'true' : 'false');
      });
    }
    if ($('closeAdvancedBtn') && $('advancedOptionsPanel')) {
      $('closeAdvancedBtn').addEventListener('click', function () {
        $('advancedOptionsPanel').classList.add('hidden');
        if ($('advancedOptionsBtn')) $('advancedOptionsBtn').setAttribute('aria-expanded', 'false');
      });
    }
    if ($('recheckStockToggle')) {
      $('recheckStockToggle').addEventListener('change', function () {
        state.recheckStock = !!$('recheckStockToggle').checked;
        try {
          global.localStorage.setItem('adobe_ai_agent_recheck_stock', state.recheckStock ? 'true' : 'false');
        } catch (e) {}
        updateAdvancedOptionsUI();
      });
    }
    if ($('notifyCompleteToggle')) {
      $('notifyCompleteToggle').addEventListener('change', function () {
        state.notifyOnComplete = !!$('notifyCompleteToggle').checked;
        try {
          global.localStorage.setItem('adobe_ai_agent_notify_complete', state.notifyOnComplete ? 'true' : 'false');
        } catch (e) {}
        if (state.notifyOnComplete) {
          unlockAudioContext();
          playCompletionChime('reply');
        }
        updateAdvancedOptionsUI();
      });
    }
    if ($('closeToastBtn')) {
      $('closeToastBtn').addEventListener('click', hideCompletionToast);
    }
    document.addEventListener('click', function (ev) {
      var panel = $('advancedOptionsPanel');
      var advBtn = $('advancedOptionsBtn');
      if (!panel || panel.classList.contains('hidden')) return;
      if (panel.contains(ev.target) || (advBtn && advBtn.contains(ev.target))) return;
      panel.classList.add('hidden');
      if (advBtn) advBtn.setAttribute('aria-expanded', 'false');
    });
    $('imageFileInput').addEventListener('change', function (ev) {
      handleImageFiles(ev.target.files);
      ev.target.value = '';
    });

    // Paste image from clipboard
    $('chatInput').addEventListener('paste', function (ev) {
      var items = (ev.clipboardData && ev.clipboardData.items) || [];
      var files = [];
      for (var i = 0; i < items.length; i++) {
        if (items[i].type && items[i].type.indexOf('image/') === 0) {
          files.push(items[i].getAsFile());
        }
      }
      if (files.length > 0) handleImageFiles(files);
    });

    // Drag and drop images onto composer
    var box = $('composerBox');
    box.addEventListener('dragover', function (ev) {
      ev.preventDefault();
      box.classList.add('dragover');
    });
    box.addEventListener('dragleave', function () {
      box.classList.remove('dragover');
    });
    box.addEventListener('drop', function (ev) {
      ev.preventDefault();
      box.classList.remove('dragover');
      if (ev.dataTransfer && ev.dataTransfer.files) {
        handleImageFiles(ev.dataTransfer.files);
      }
    });

    bindIconPresetEvents();
  }

  // ───────── Icon Set Preset (1st & 2nd Grade Only) ─────────

  var ICON_PRESET_STORAGE_KEY = 'adobe_ai_agent_icon_preset_v1';

  function loadIconPresetPrefs() {
    try {
      var raw = global.localStorage.getItem(ICON_PRESET_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function saveIconPresetPrefs() {
    try {
      var data = {
        folderPath: ($('iconFolderPathInput') && $('iconFolderPathInput').value.trim()) || '',
        outputDir: ($('presetOutputDirInput') && $('presetOutputDirInput').value.trim()) || '',
        demoPrompt: ($('presetDemoPromptInput') && $('presetDemoPromptInput').value) || '',
        iconsPerSet: parseInt(($('presetIconsPerSet') && $('presetIconsPerSet').value) || '24', 10) || 24,
        setCount: parseInt(($('presetSetCount') && $('presetSetCount').value) || '0', 10) || 0,
        groupingMode: ($('presetGroupingMode') && $('presetGroupingMode').value) || 'sequential',
        fmtDefaultsV2: true,
        fmtAi: $('presetFmtAi') ? !!$('presetFmtAi').checked : false,
        fmtEps: $('presetFmtEps') ? !!$('presetFmtEps').checked : true,
        fmtPng: $('presetFmtPng') ? !!$('presetFmtPng').checked : false,
        fmtJpg: $('presetFmtJpg') ? !!$('presetFmtJpg').checked : false,
        outlineText: $('presetOutlineText') ? !!$('presetOutlineText').checked : true,
        removeWhiteBg: $('presetRemoveWhiteBg') ? !!$('presetRemoveWhiteBg').checked : true,
        closeIntermediate: $('presetCloseIntermediate') ? !!$('presetCloseIntermediate').checked : true,
        refImage: state.iconPreset.refImage || null
      };
      global.localStorage.setItem(ICON_PRESET_STORAGE_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  function updateIconPresetBatchSummary() {
    var summaryEl = $('iconBatchSummary');
    var badgeEl = $('iconFolderCountBadge');
    if (!summaryEl || !badgeEl) return;
    var total = state.iconPreset.svgFiles.length;
    var perSet = Math.max(1, parseInt(($('presetIconsPerSet') && $('presetIconsPerSet').value) || '24', 10) || 24);
    var reqSets = Math.max(0, parseInt(($('presetSetCount') && $('presetSetCount').value) || '0', 10) || 0);

    if (total === 0) {
      badgeEl.textContent = 'No SVGs loaded';
      summaryEl.textContent = 'Select a folder containing your traced .svg icons (30 or 500+ icons supported).';
      return;
    }

    var possible = Math.ceil(total / perSet);
    var planned = reqSets > 0 ? reqSets : possible;
    var usesShuffle = (planned * perSet > total);
    badgeEl.textContent = '✓ ' + total + ' SVG files';
    summaryEl.textContent = 'Ready: ' + total + ' SVGs → will build ' + planned + ' set' + (planned > 1 ? 's' : '') + ' (' + perSet + ' icons/set' + (usesShuffle ? ', shuffled order & hero variations' : '') + ').';
  }

  function scanSelectedIconFolder(folderPath) {
    var pathVal = String(folderPath || ($('iconFolderPathInput') && $('iconFolderPathInput').value) || '').trim();
    if (!pathVal) {
      state.iconPreset.folderPath = '';
      state.iconPreset.svgFiles = [];
      updateIconPresetBatchSummary();
      return false;
    }
    var scanRes = CepBridge.listSvgFilesInFolder(pathVal);
    if (!scanRes || !scanRes.ok) {
      state.iconPreset.folderPath = pathVal;
      state.iconPreset.svgFiles = [];
      updateIconPresetBatchSummary();
      setPresetStatus((scanRes && scanRes.error) || 'Could not scan SVG folder.', 'err');
      return false;
    }
    state.iconPreset.folderPath = scanRes.folderPath;
    state.iconPreset.svgFiles = scanRes.files || [];
    if ($('iconFolderPathInput')) $('iconFolderPathInput').value = scanRes.folderPath;
    setPresetStatus(scanRes.files.length > 0 ? '' : 'No .svg files found in this folder.', scanRes.files.length > 0 ? '' : 'err');
    updateIconPresetBatchSummary();
    saveIconPresetPrefs();
    return scanRes.files.length > 0;
  }

  function renderPresetRefImageUI() {
    var imgEl = $('presetRefPreviewImg');
    var phEl = $('presetRefPlaceholder');
    var clrBtn = $('clearPresetRefBtn');
    var ref = state.iconPreset.refImage;
    if (ref && ref.dataUrl) {
      if (imgEl) {
        imgEl.src = ref.dataUrl;
        imgEl.classList.remove('hidden');
      }
      if (phEl) phEl.classList.add('hidden');
      if (clrBtn) clrBtn.classList.remove('hidden');
    } else {
      if (imgEl) {
        imgEl.src = '';
        imgEl.classList.add('hidden');
      }
      if (phEl) phEl.classList.remove('hidden');
      if (clrBtn) clrBtn.classList.add('hidden');
    }
  }

  function setPresetStatus(msg, kind) {
    var el = $('presetStatusBanner');
    if (!el) return;
    if (!msg) {
      el.classList.add('hidden');
      el.textContent = '';
      return;
    }
    el.className = 'preset-status-banner' + (kind ? (' ' + kind) : '');
    el.textContent = msg;
    el.classList.remove('hidden');
  }

  function setPresetBusyUI(running) {
    state.iconPreset.isRunning = !!running;
    if ($('runIconBatchBtn')) $('runIconBatchBtn').disabled = !!running;
    if ($('previewFirstSetBtn')) $('previewFirstSetBtn').disabled = !!running;
    if ($('buildReviewedSetBtn')) $('buildReviewedSetBtn').disabled = !!running;
    setClass($('stopIconBatchBtn'), 'hidden', !running);
    setClass($('iconPresetBtn'), 'active', !!running);
  }

  function openIconPresetModal() {
    if (!canUseIconPreset() || !iconPreset) return;
    var prefs = loadIconPresetPrefs();
    if ($('iconFolderPathInput')) $('iconFolderPathInput').value = prefs.folderPath || state.iconPreset.folderPath || '';
    if ($('presetOutputDirInput')) $('presetOutputDirInput').value = prefs.outputDir || '';
    if ($('presetDemoPromptInput')) {
      var savedPrompt = (prefs.demoPrompt && prefs.demoPrompt.trim()) ? prefs.demoPrompt : '';
      // Auto-upgrade old default prompts that still included "AI • EPS • SVG"
      if (!savedPrompt || /AI\s*•\s*EPS\s*•\s*SVG/i.test(savedPrompt)) {
        savedPrompt = NS.IconPresetManager.DEFAULT_DEMO_PROMPT;
      }
      $('presetDemoPromptInput').value = savedPrompt;
    }
    if ($('presetIconsPerSet')) $('presetIconsPerSet').value = prefs.iconsPerSet || 24;
    if ($('presetSetCount')) $('presetSetCount').value = (prefs.setCount != null) ? prefs.setCount : 0;
    if ($('presetGroupingMode')) $('presetGroupingMode').value = prefs.groupingMode || 'sequential';
    var hasFmtV2 = !!prefs.fmtDefaultsV2;
    if ($('presetFmtAi')) $('presetFmtAi').checked = hasFmtV2 ? (prefs.fmtAi === true) : false;
    if ($('presetFmtEps')) $('presetFmtEps').checked = hasFmtV2 ? (prefs.fmtEps !== false) : true;
    if ($('presetFmtPng')) $('presetFmtPng').checked = hasFmtV2 ? (prefs.fmtPng === true) : false;
    if ($('presetFmtJpg')) $('presetFmtJpg').checked = hasFmtV2 ? (prefs.fmtJpg === true) : false;
    if ($('presetOutlineText')) $('presetOutlineText').checked = prefs.outlineText !== false;
    if ($('presetRemoveWhiteBg')) $('presetRemoveWhiteBg').checked = prefs.removeWhiteBg !== false;
    if ($('presetCloseIntermediate')) $('presetCloseIntermediate').checked = prefs.closeIntermediate !== false;
    if (prefs.refImage && !state.iconPreset.refImage) {
      state.iconPreset.refImage = prefs.refImage;
    }
    renderPresetRefImageUI();
    if ($('iconFolderPathInput') && $('iconFolderPathInput').value.trim()) {
      scanSelectedIconFolder($('iconFolderPathInput').value.trim());
    } else {
      updateIconPresetBatchSummary();
    }
    $('iconPresetModal').classList.remove('hidden');
  }

  function closeIconPresetModal() {
    if ($('iconPresetModal')) $('iconPresetModal').classList.add('hidden');
  }

  function getSelectedPresetFormats() {
    var fmts = [];
    if ($('presetFmtAi') && $('presetFmtAi').checked) fmts.push('ai');
    if ($('presetFmtEps') && $('presetFmtEps').checked) fmts.push('eps');
    if ($('presetFmtPng') && $('presetFmtPng').checked) fmts.push('png');
    if ($('presetFmtJpg') && $('presetFmtJpg').checked) fmts.push('jpg');
    return fmts.length > 0 ? fmts : ['eps'];
  }

  function resolvePresetOutputDir() {
    var custom = ($('presetOutputDirInput') && $('presetOutputDirInput').value.trim()) || '';
    if (custom) return custom.replace(/\\/g, '/');
    if (!state.currentSession) createNewSession();
    return storage.getStoragePaths(state.currentSession.id).exportsDir;
  }

  function renderPresetReviewDrawer(reviewData) {
    state.iconPreset.reviewData = reviewData;
    var sec = $('presetReviewSection');
    var list = $('presetReviewList');
    if (!sec || !list || !reviewData || !reviewData.setPlan) return;

    var plan = reviewData.setPlan;
    $('reviewSeoLine1').value = plan.seoTitleLine1 || '';
    $('reviewSeoLine2').value = plan.seoTitleLine2 || '';
    $('reviewFeaturesInput').value = Array.isArray(plan.featureLines) ? plan.featureLines.join(', ') : '';

    list.innerHTML = '';
    plan.icons.forEach(function (ic, idx) {
      var row = document.createElement('div');
      row.className = 'preset-review-item';
      row.innerHTML =
        '<span class="preset-review-num">#' + (idx + 1) + '</span>' +
        (ic.thumbUrl ? '<img class="preset-review-thumb" src="' + ic.thumbUrl + '">' : '<span class="preset-review-thumb"></span>') +
        '<input type="text" class="text-input preset-review-label-input" data-idx="' + idx + '" value="' + escapeHtml(ic.label) + '" style="flex:1; min-width:80px; padding:4px 6px; font-size:0.75rem;">' +
        '<label class="preset-review-hero" title="Use as Side Panel Hero Icon">' +
          '<input type="radio" name="presetHeroRadio" value="' + (idx + 1) + '" ' + ((plan.heroIconIndex || 1) === (idx + 1) ? 'checked' : '') + '>' +
          '<span>Hero</span>' +
        '</label>';
      list.appendChild(row);
    });

    sec.classList.remove('hidden');
  }

  function recordIconBatchInChat(summaryText, exportedFiles, isErr) {
    if (!state.currentSession) createNewSession();
    state.currentSession.messages.push({
      id: 'msg_' + Date.now(),
      role: 'assistant',
      timestamp: Date.now(),
      action: 'execute',
      isError: !!isErr,
      content: summaryText,
      execution: isErr ? null : {
        ok: true,
        hostApp: state.hostInfo.app,
        hostLabel: state.hostInfo.label,
        exportedFiles: exportedFiles || []
      }
    });
    state.currentSession.updatedAt = Date.now();
    storage.saveSession(state.currentSession);
    renderSidebar();
    renderChatFeed();
  }

  function preflightIconPresetRun() {
    if (!canUseIconPreset()) return Promise.resolve({ ok: false, message: 'Icon Preset is available for Admin & 2nd Grade accounts only.' });
    if (state.hostInfo.app !== 'illustrator' || !state.hostInfo.isAdobe) {
      return Promise.resolve({ ok: false, message: 'Please open Adobe Illustrator before building Icon Sets.' });
    }
    if (state.iconPreset.svgFiles.length === 0) {
      return Promise.resolve({ ok: false, message: 'Please select and scan a folder containing .svg files first.' });
    }
    var hasPersonalKey = !!api.getActiveKeyObj();
    return auth.useCredit({ hostApp: state.hostInfo.app, hasPersonalKey: hasPersonalKey }).then(function (creditRes) {
      if (!creditRes || !creditRes.success) {
        if (creditRes && creditRes.user) applyUserState(creditRes.user);
        return { ok: false, message: (creditRes && creditRes.message) || 'Could not authorize request.' };
      }
      if (creditRes.user) applyUserState(creditRes.user);
      api.setTurnToken(creditRes.turnToken || '');
      return { ok: true, hasPersonalKey: hasPersonalKey };
    });
  }

  function bindIconPresetEvents() {
    if (!$('iconPresetBtn')) return;

    $('iconPresetBtn').addEventListener('click', openIconPresetModal);
    $('closeIconPresetBtn').addEventListener('click', closeIconPresetModal);

    $('browseIconFolderBtn').addEventListener('click', function () {
      var cur = $('iconFolderPathInput').value.trim();
      CepBridge.browseFolderDialog('Select SVG Icons Folder', cur).then(function (picked) {
        if (picked) {
          $('iconFolderPathInput').value = picked;
          scanSelectedIconFolder(picked);
        }
      });
    });

    $('scanIconFolderBtn').addEventListener('click', function () {
      scanSelectedIconFolder($('iconFolderPathInput').value);
    });

    $('iconFolderPathInput').addEventListener('change', function () {
      scanSelectedIconFolder($('iconFolderPathInput').value);
    });

    $('browseOutputDirBtn').addEventListener('click', function () {
      var cur = $('presetOutputDirInput').value.trim();
      CepBridge.browseFolderDialog('Select Export Output Folder', cur).then(function (picked) {
        if (picked) {
          $('presetOutputDirInput').value = picked;
          saveIconPresetPrefs();
        }
      });
    });

    $('pickPresetRefBtn').addEventListener('click', function () {
      $('presetRefFileInput').click();
    });

    $('presetRefFileInput').addEventListener('change', function (ev) {
      var file = ev.target.files && ev.target.files[0];
      ev.target.value = '';
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function (e) {
        compressForVisionIfNeeded(e.target.result, function (visionUrl) {
          state.iconPreset.refImage = { name: file.name || 'side_panel_ref.jpg', dataUrl: visionUrl };
          renderPresetRefImageUI();
          saveIconPresetPrefs();
        });
      };
      reader.readAsDataURL(file);
    });

    $('clearPresetRefBtn').addEventListener('click', function () {
      state.iconPreset.refImage = null;
      renderPresetRefImageUI();
      saveIconPresetPrefs();
    });

    $('resetPresetPromptBtn').addEventListener('click', function () {
      $('presetDemoPromptInput').value = NS.IconPresetManager.DEFAULT_DEMO_PROMPT;
      saveIconPresetPrefs();
    });

    ['presetDemoPromptInput', 'presetOutputDirInput', 'presetGroupingMode', 'presetFmtAi', 'presetFmtEps', 'presetFmtPng', 'presetFmtJpg', 'presetOutlineText', 'presetRemoveWhiteBg', 'presetCloseIntermediate'].forEach(function (id) {
      if ($(id)) {
        $(id).addEventListener('change', saveIconPresetPrefs);
      }
    });

    ['presetIconsPerSet', 'presetSetCount'].forEach(function (id) {
      if ($(id)) {
        $(id).addEventListener('input', function () {
          updateIconPresetBatchSummary();
          saveIconPresetPrefs();
        });
      }
    });

    $('closePresetReviewBtn').addEventListener('click', function () {
      $('presetReviewSection').classList.add('hidden');
    });

    $('stopIconBatchBtn').addEventListener('click', function () {
      if (iconPreset) iconPreset.requestStop();
      setPresetStatus('Stopping after current step...', '');
    });

    $('previewFirstSetBtn').addEventListener('click', function () {
      if (!iconPreset || state.iconPreset.isRunning) return;
      saveIconPresetPrefs();
      setPresetStatus('Checking authorization...', '');
      preflightIconPresetRun().then(function (pre) {
        if (!pre.ok) {
          setPresetStatus(pre.message, 'err');
          return;
        }
        setPresetBusyUI(true);
        api.stopRequested = false;
        iconPreset.previewFirstSet({
          svgFiles: state.iconPreset.svgFiles,
          iconsPerSet: $('presetIconsPerSet').value,
          refImage: state.iconPreset.refImage,
          demoPrompt: $('presetDemoPromptInput').value,
          hostApp: state.hostInfo.app,
          hasPersonalKey: pre.hasPersonalKey,
          onProgress: function (txt) { setPresetStatus(txt, ''); }
        }).then(function (reviewData) {
          renderPresetReviewDrawer(reviewData);
          setPresetStatus('Set #1 recognized! Review or edit any label below, then click "Build Reviewed Set in Illustrator".', 'ok');
        })['catch'](function (err) {
          setPresetStatus((err && err.message) ? err.message : String(err), 'err');
        }).then(function () {
          api.setTurnToken('');
          setPresetBusyUI(false);
        });
      });
    });

    $('buildReviewedSetBtn').addEventListener('click', function () {
      if (!iconPreset || state.iconPreset.isRunning || !state.iconPreset.reviewData) return;
      if (state.hostInfo.app !== 'illustrator' || !state.hostInfo.isAdobe) {
        setPresetStatus('Please open Adobe Illustrator to build the icon set.', 'err');
        return;
      }

      var rd = state.iconPreset.reviewData;
      rd.setPlan.seoTitleLine1 = $('reviewSeoLine1').value.trim() || 'VECTOR';
      rd.setPlan.seoTitleLine2 = $('reviewSeoLine2').value.trim() || 'ICONS';
      var featRaw = $('reviewFeaturesInput').value.trim();
      if (featRaw) {
        rd.setPlan.featureLines = featRaw.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      }
      var heroRadio = document.querySelector('input[name="presetHeroRadio"]:checked');
      if (heroRadio) {
        rd.setPlan.heroIconIndex = parseInt(heroRadio.value, 10) || 1;
      }
      eachNode(document.querySelectorAll('.preset-review-label-input'), function (inp) {
        var idx = parseInt(inp.getAttribute('data-idx'), 10);
        if (!isNaN(idx) && rd.setPlan.icons[idx]) {
          rd.setPlan.icons[idx].label = inp.value.trim() || rd.setPlan.icons[idx].label;
        }
      });

      setPresetBusyUI(true);
      setPresetStatus('Building reviewed icon set in Illustrator...', '');
      var outDir = resolvePresetOutputDir();
      iconPreset.buildSingleSetInIllustrator(rd.setPlan, rd.styleSpec, {
        setNumber: 1,
        outputDir: outDir,
        formats: getSelectedPresetFormats(),
        closeAfterExport: false,
        outlineText: $('presetOutlineText') ? !!$('presetOutlineText').checked : true,
        removeWhiteBg: $('presetRemoveWhiteBg') ? !!$('presetRemoveWhiteBg').checked : true
      }).then(function (execRes) {
        if (execRes && execRes.ok) {
          var resData = execRes.result || execRes;
          var files = resData.exportedFiles || [];
          var title = (rd.setPlan.seoTitleLine1 + ' ' + rd.setPlan.seoTitleLine2).trim();
          setPresetStatus('✓ Built "' + title + '" in Illustrator (' + files.length + ' exported files).', 'ok');
          recordIconBatchInChat('✓ Built Icon Set "' + title + '" (' + rd.setPlan.icons.length + ' icons) with Side Panel & AI labels.', files, false);
          refreshDocContext();
          notifyTaskDone('design', 'Icon Set Ready — Adobe AI Agent', title + ' exported.');
        } else {
          setPresetStatus((execRes && execRes.error) || 'Illustrator build failed.', 'err');
        }
      })['catch'](function (err) {
        setPresetStatus((err && err.message) ? err.message : String(err), 'err');
      }).then(function () {
        setPresetBusyUI(false);
      });
    });

    $('runIconBatchBtn').addEventListener('click', function () {
      if (!iconPreset || state.iconPreset.isRunning) return;
      saveIconPresetPrefs();
      setPresetStatus('Authorizing batch run...', '');
      preflightIconPresetRun().then(function (pre) {
        if (!pre.ok) {
          setPresetStatus(pre.message, 'err');
          return;
        }
        setPresetBusyUI(true);
        api.stopRequested = false;
        var outDir = resolvePresetOutputDir();
        iconPreset.runBatch({
          svgFiles: state.iconPreset.svgFiles,
          iconsPerSet: $('presetIconsPerSet').value,
          setCount: $('presetSetCount').value,
          groupingMode: $('presetGroupingMode').value,
          refImage: state.iconPreset.refImage,
          demoPrompt: $('presetDemoPromptInput').value,
          formats: getSelectedPresetFormats(),
          closeIntermediate: $('presetCloseIntermediate').checked,
          outlineText: $('presetOutlineText') ? !!$('presetOutlineText').checked : true,
          removeWhiteBg: $('presetRemoveWhiteBg') ? !!$('presetRemoveWhiteBg').checked : true,
          outputDir: outDir,
          hostApp: state.hostInfo.app,
          hasPersonalKey: pre.hasPersonalKey,
          onProgress: function (txt) { setPresetStatus(txt, ''); }
        }).then(function (summary) {
          var allFiles = [];
          var lines = [];
          summary.builtSets.forEach(function (bs) {
            lines.push('• Set #' + bs.setNumber + ': ' + bs.title + ' (' + bs.iconCount + ' icons)');
            if (Array.isArray(bs.exportedFiles)) {
              bs.exportedFiles.forEach(function (f) { allFiles.push(f); });
            }
          });
          if (summary.errors && summary.errors.length > 0) {
            lines.push('\nErrors / Warnings:\n' + summary.errors.join('\n'));
          }
          if (summary.builtSets.length === 0) {
            var firstErr = (summary.errors && summary.errors[0]) || 'Could not build any icon set.';
            var failMsg = '✕ Icon Set Batch Failed (0/' + summary.totalPlanned + ' set(s) built).\n\n' + lines.join('\n');
            setPresetStatus('✕ Failed (0/' + summary.totalPlanned + ' sets): ' + firstErr, 'err');
            recordIconBatchInChat(failMsg, [], true);
            notifyTaskDone('error', 'Icon Set Batch Failed', firstErr);
          } else {
            var msg = '✓ Icon Set Batch Complete: ' + summary.builtSets.length + '/' + summary.totalPlanned + ' set(s) built.\n\n' + lines.join('\n');
            var hasWarns = summary.errors && summary.errors.length > 0;
            setPresetStatus((hasWarns ? '⚠ Built ' : '✓ Done! Built ') + summary.builtSets.length + '/' + summary.totalPlanned + ' icon set(s). Output: ' + outDir, hasWarns ? '' : 'ok');
            recordIconBatchInChat(msg, allFiles.slice(0, 18), false);
            refreshDocContext();
            notifyTaskDone('design', 'Icon Sets Complete — Adobe AI Agent', summary.builtSets.length + ' icon set(s) exported.');
          }
        })['catch'](function (err) {
          var em = (err && err.message) ? err.message : String(err);
          setPresetStatus(em, 'err');
          if (em !== 'Stopped by user') {
            notifyTaskDone('error', 'Icon Set Batch Failed', em);
          }
        }).then(function () {
          api.setTurnToken('');
          setPresetBusyUI(false);
        });
      });
    });
  }

  function init() {
    if (typeof CepBridge.fitPanelToScreen === 'function') {
      CepBridge.fitPanelToScreen(false);
    }
    updateHostBadge();
    storage.setActiveAccount(auth.user || null);
    initSession();
    bindEvents();
    updateAutoCanvasButton();
    updateAdvancedOptionsUI();
    updateApiDot();
    if (auth.token && auth.user) {
      applyUserState(auth.user);
    } else {
      renderSidebar();
      renderChatFeed();
    }
    refreshDocContext();
    syncRemoteSessionAndConfig();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(window);
