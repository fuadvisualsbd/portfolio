var APP_VERSION = "1.2.0";

var csInterface;
try {
    csInterface = new CSInterface();
} catch (e) {
    console.log("Not running inside Adobe environment");
}

var SERVER_URL = 'https://autopro-eight.vercel.app';
var currentUserEmail = null;
var pollingInterval = null;
var currentLoginUrl = "";
var isForceUpdateBlocked = false;
var isExecutingScript = false;

// Helper to compare semantic versions (pure ES5)
function isVersionOlder(current, latest) {
    if (!current) return true;
    if (!latest) return false;
    var v1 = ('' + current).split('.');
    var v2 = ('' + latest).split('.');
    for (var i = 0; i < Math.max(v1.length, v2.length); i++) {
        var num1 = parseInt(v1[i], 10) || 0;
        var num2 = parseInt(v2[i], 10) || 0;
        if (num1 < num2) return true;
        if (num1 > num2) return false;
    }
    return false;
}

// Universal HTTP Helper (Works on ALL old & new CEP versions instead of fetch)
function apiRequest(method, url, bodyData, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    callback(null, data);
                } catch (err) {
                    callback(err, null);
                }
            } else {
                callback(new Error("HTTP Error: " + xhr.status), null);
            }
        }
    };
    xhr.onerror = function () {
        callback(new Error("Network Error"), null);
    };
    if (bodyData) {
        xhr.send(JSON.stringify(bodyData));
    } else {
        xhr.send();
    }
}

// 100% Reliable Browser Opener for Weak PCs & All CEP Versions
function openBrowser(url) {
    var opened = false;

    // 1. Try Node.js child_process FIRST (Fastest on weak PCs)
    try {
        var cepNode = window.cep_node || window;
        var req = cepNode.require || (typeof require !== 'undefined' ? require : null);
        if (req) {
            var exec = req('child_process').exec;
            var isWin = (navigator.platform.toLowerCase().indexOf('win') > -1);
            var cmd = isWin ? 'start "" "' + url + '"' : 'open "' + url + '"';
            exec(cmd);
            opened = true;
        }
    } catch (e) {}

    // 2. CSInterface fallback
    if (!opened) {
        try {
            if (csInterface && typeof csInterface.openURLInDefaultBrowser === 'function') {
                csInterface.openURLInDefaultBrowser(url);
                opened = true;
            }
        } catch (e2) {}
    }

    // 3. Final browser fallback
    if (!opened) {
        try {
            window.open(url, '_blank');
        } catch (e3) {}
    }
}

// Clipboard copy helper
function copyTextToClipboard(text) {
    var input = document.createElement('input');
    input.style.position = 'fixed';
    input.style.opacity = '0';
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
}

function getSelectedScript() {
    var normalEl = document.getElementById('normal-script-select');
    var proEl = document.getElementById('pro-script-select');
    var normalVal = normalEl ? normalEl.value : "";
    var proVal = proEl ? proEl.value : "";
    if (proVal) return { type: 'pro', name: proVal };
    if (normalVal) return { type: 'normal', name: normalVal };
    return null;
}

function updateRunButtonState() {
    var runBtn = document.getElementById('run-script-btn');
    if (!runBtn) return;

    var selected = getSelectedScript();
    runBtn.disabled = (!selected || isForceUpdateBlocked || isExecutingScript);

    var labelSpan = runBtn.getElementsByTagName('span')[0];
    if (isExecutingScript) {
        runBtn.className = 'run-btn' + (selected && selected.type === 'pro' ? ' pro-btn' : '');
        if (labelSpan) labelSpan.textContent = 'Running Script...';
        return;
    }

    if (selected && selected.type === 'pro') {
        runBtn.className = 'run-btn pro-btn';
        if (labelSpan) labelSpan.textContent = '⚡ Run Pro Script';
    } else if (selected && selected.type === 'normal') {
        runBtn.className = 'run-btn';
        if (labelSpan) labelSpan.textContent = '▶ Run Free Script';
    } else {
        runBtn.className = 'run-btn';
        if (labelSpan) labelSpan.textContent = '▶ Select a Script to Run';
    }
}

window.onload = function () {
    // Show current extension version in UI
    var versionBadge = document.getElementById('app-version-badge');
    if (versionBadge) {
        versionBadge.textContent = 'v' + APP_VERSION;
    }

    // 1. Load UI Config with Version Tag
    loadUIConfig();

    document.getElementById('login-btn').addEventListener('click', startBrowserLogin);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    // Fallback Copy Button
    var copyBtn = document.getElementById('copy-url-btn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            if (currentLoginUrl) {
                copyTextToClipboard(currentLoginUrl);
                var msgEl = document.getElementById('login-msg');
                msgEl.textContent = "Link Copied! Open any browser and paste it.";
                msgEl.className = "msg success";
            }
        });
    }

    var normalSelect = document.getElementById('normal-script-select');
    var proSelect = document.getElementById('pro-script-select');

    if (normalSelect) {
        normalSelect.addEventListener('change', function () {
            if (normalSelect.value && proSelect) {
                proSelect.value = "";
            }
            updateRunButtonState();
        });
    }

    if (proSelect) {
        proSelect.addEventListener('change', function () {
            if (proSelect.value && normalSelect) {
                normalSelect.value = "";
            }
            updateRunButtonState();
        });
    }

    var runBtn = document.getElementById('run-script-btn');
    if (runBtn) {
        runBtn.addEventListener('click', function () {
            var selected = getSelectedScript();
            if (selected) {
                executeRemoteScript(selected.type, selected.name);
            }
        });
    }

    updateRunButtonState();

    // WhatsApp Button
    document.getElementById('whatsapp-btn').addEventListener('click', function () {
        var phone = window.WA_NUM || "8801795624600";
        var msg = encodeURIComponent(window.WA_MSG || "Hello, I would like to buy Pro Credits for the Adobe Script Panel.");
        var url = "https://wa.me/" + phone + "?text=" + msg;
        showMsg("Opening WhatsApp... Please check your browser.", "success");
        openBrowser(url);
    });

    // 2. Persistent Login Check
    var savedEmail = localStorage.getItem('autopro_email');
    if (savedEmail) {
        document.getElementById('login-msg').textContent = "Restoring session...";
        apiRequest('POST', SERVER_URL + '/api/verify-user', { email: savedEmail }, function (err, data) {
            if (!err && data && data.success) {
                currentUserEmail = data.user.email;
                document.getElementById('user-display').textContent = data.user.email;
                document.getElementById('free-display').textContent = data.user.free_credits;
                document.getElementById('pro-display').textContent = data.user.pro_credits;
                document.getElementById('login-container').style.display = 'none';
                document.getElementById('app-container').style.display = 'block';
                fetchScripts();
            } else {
                localStorage.removeItem('autopro_email');
                document.getElementById('login-msg').textContent = "";
            }
        });
    }
};

function loadUIConfig() {
    // Send APP_VERSION as ?v= parameter so server knows client version
    apiRequest('GET', SERVER_URL + '/api/ui-config?v=' + APP_VERSION + '&t=' + new Date().getTime(), null, function (err, config) {
        if (err || !config) return;

        // Future update banner check
        if (config.latest_version && isVersionOlder(APP_VERSION, config.latest_version)) {
            var updateBar = document.getElementById('update-bar');
            if (updateBar) {
                updateBar.style.display = 'block';
                var updateText = document.getElementById('update-bar-text');
                if (updateText) {
                    updateText.textContent = "New Version v" + config.latest_version + " Available! Click to Download";
                }
                updateBar.onclick = function () {
                    if (config.update_download_url) {
                        openBrowser(config.update_download_url);
                    }
                };
            }
            if (config.force_update) {
                isForceUpdateBlocked = true;
                updateRunButtonState();
                showMsg("Please update to v" + config.latest_version + " to run scripts.", "error");
            }
        }

        if (config.brand_name) {
            var bName = document.getElementById('brand-name');
            if (bName) bName.textContent = config.brand_name;
        }
        if (config.brand_prefix) {
            var bPrefix = document.getElementById('brand-prefix');
            if (bPrefix) bPrefix.textContent = config.brand_prefix;
        }
        if (config.brand_slogan) {
            var bSlogan = document.getElementById('brand-slogan');
            if (bSlogan) bSlogan.textContent = config.brand_slogan;
        }
        if (config.brand_url) {
            var bLink = document.getElementById('brand-link');
            if (bLink) {
                bLink.onclick = function (e) {
                    e.preventDefault();
                    openBrowser(config.brand_url);
                };
            }
        }
        if (config.brand_logo_url) {
            var logoEl = document.getElementById('brand-logo');
            if (logoEl) {
                logoEl.src = config.brand_logo_url;
                logoEl.style.display = 'inline-block';
            }
        }

        if (config.announcement_visible) {
            var annEl = document.getElementById('announcement-bar');
            annEl.style.display = 'block';
            annEl.style.backgroundColor = config.announcement_color || '#ff9800';
            document.getElementById('announcement-text').textContent = config.announcement_text;
        } else {
            var annElHidden = document.getElementById('announcement-bar');
            if (annElHidden) annElHidden.style.display = 'none';
        }

        if (config.theme_primary_color) {
            document.documentElement.style.setProperty('--primary-color', config.theme_primary_color);
        }
        if (config.theme_bg_color) {
            document.body.style.backgroundColor = config.theme_bg_color;
        }

        if (config.whatsapp_number) window.WA_NUM = config.whatsapp_number;
        if (config.whatsapp_message) window.WA_MSG = config.whatsapp_message;

        if (config.show_free_section === false) {
            document.getElementById('normal-section').style.display = 'none';
            var normSel = document.getElementById('normal-script-select');
            if (normSel) normSel.value = '';
            updateRunButtonState();
        }
        if (config.show_pro_section === false) {
            document.getElementById('pro-section').style.display = 'none';
            var pSel = document.getElementById('pro-script-select');
            if (pSel) pSel.value = '';
            updateRunButtonState();
        }

        if (config.link_visible) {
            var linkEl = document.getElementById('custom-link');
            linkEl.style.display = 'inline-block';
            linkEl.textContent = config.link_text || "Visit Link";
            linkEl.onclick = function (e) {
                e.preventDefault();
                openBrowser(config.link_url || "#");
            };
        }

        if (config.link2_visible) {
            var linkEl2 = document.getElementById('custom-link-2');
            linkEl2.style.display = 'inline-block';
            linkEl2.textContent = config.link2_text || "Visit Link 2";
            linkEl2.onclick = function (e) {
                e.preventDefault();
                openBrowser(config.link2_url || "#");
            };
        }

        if (config.link3_visible) {
            var linkEl3 = document.getElementById('custom-link-3');
            linkEl3.style.display = 'inline-block';
            linkEl3.textContent = config.link3_text || "Visit Link 3";
            linkEl3.onclick = function (e) {
                e.preventDefault();
                openBrowser(config.link3_url || "#");
            };
        }

        if (config.credit_price_text) {
            document.getElementById('credit-price-text').textContent = config.credit_price_text;
        }
    });
}

function showMsg(text, type) {
    var msgEl = document.getElementById('app-msg');
    msgEl.textContent = text;
    msgEl.className = "msg " + type;
}

function startBrowserLogin() {
    var msgEl = document.getElementById('login-msg');
    msgEl.textContent = "Connecting to server...";
    msgEl.className = "msg";

    apiRequest('GET', SERVER_URL + '/api/start-login?t=' + new Date().getTime(), null, function (err, data) {
        if (err || !data || !data.loginUrl) {
            msgEl.textContent = "Server connection failed.";
            msgEl.className = "msg error";
            return;
        }

        currentLoginUrl = data.loginUrl;
        msgEl.textContent = "Opening browser... Please login.";

        // Show manual fallback in case browser does not launch or is delayed
        var fallbackBox = document.getElementById('fallback-login');
        var urlInput = document.getElementById('login-url-display');
        if (fallbackBox && urlInput) {
            fallbackBox.style.display = 'block';
            urlInput.value = currentLoginUrl;
        }

        openBrowser(data.loginUrl);

        if (pollingInterval) clearInterval(pollingInterval);

        // Polling loop
        pollingInterval = setInterval(function () {
            apiRequest('GET', SERVER_URL + '/api/check-login?session=' + data.sessionId + '&t=' + new Date().getTime(), null, function (checkErr, checkData) {
                if (checkErr || !checkData) return;

                if (checkData.status === 'completed') {
                    clearInterval(pollingInterval);
                    currentUserEmail = checkData.user.email;
                    localStorage.setItem('autopro_email', currentUserEmail);

                    document.getElementById('user-display').textContent = checkData.user.email;
                    document.getElementById('free-display').textContent = checkData.user.free_credits;
                    document.getElementById('pro-display').textContent = checkData.user.pro_credits;

                    document.getElementById('login-container').style.display = 'none';
                    document.getElementById('app-container').style.display = 'block';

                    fetchScripts();
                } else if (checkData.status === 'expired') {
                    clearInterval(pollingInterval);
                    msgEl.textContent = "Login session expired. Try again.";
                    msgEl.className = "msg error";
                }
            });
        }, 2500);
    });
}

function handleLogout() {
    currentUserEmail = null;
    isExecutingScript = false;
    localStorage.removeItem('autopro_email');
    if (pollingInterval) clearInterval(pollingInterval);
    document.getElementById('login-msg').textContent = '';
    document.getElementById('app-msg').textContent = '';
    var normalEl = document.getElementById('normal-script-select');
    var proEl = document.getElementById('pro-script-select');
    if (normalEl) normalEl.value = '';
    if (proEl) proEl.value = '';
    updateRunButtonState();
    var fallbackBox = document.getElementById('fallback-login');
    if (fallbackBox) fallbackBox.style.display = 'none';
    document.getElementById('app-container').style.display = 'none';
    document.getElementById('login-container').style.display = 'block';
}

function fetchScripts() {
    apiRequest('GET', SERVER_URL + '/api/list-scripts?t=' + new Date().getTime(), null, function (err, data) {
        if (!err && data && data.success) {
            populateDropdown('normal-script-select', data.normal);
            populateDropdown('pro-script-select', data.pro);
            updateRunButtonState();
        } else {
            showMsg("Failed to load script lists.", "error");
        }
    });
}

function populateDropdown(selectId, scriptArray) {
    var selectEl = document.getElementById(selectId);
    var placeholder = (selectId === 'pro-script-select') ? '-- Select a Pro script --' : '-- Select a script --';
    selectEl.innerHTML = '<option value="">' + placeholder + '</option>';
    if (!scriptArray || scriptArray.length === 0) return;
    for (var i = 0; i < scriptArray.length; i++) {
        var script = scriptArray[i];
        var opt = document.createElement('option');
        opt.value = script.id;
        opt.textContent = script.name;
        selectEl.appendChild(opt);
    }
}

function executeRemoteScript(type, scriptName) {
    if (!currentUserEmail || isExecutingScript || isForceUpdateBlocked) return;
    isExecutingScript = true;
    updateRunButtonState();
    showMsg("Fetching script...", "msg");

    var payload = {
        email: currentUserEmail,
        type: type,
        scriptName: scriptName,
        version: APP_VERSION
    };

    apiRequest('POST', SERVER_URL + '/api/get-script', payload, function (err, data) {
        isExecutingScript = false;
        updateRunButtonState();

        if (err || !data) {
            showMsg("Server connection failed.", "error");
            return;
        }

        if (data.success) {
            document.getElementById('free-display').textContent = data.free_credits;
            document.getElementById('pro-display').textContent = data.pro_credits;
            showMsg(data.message, "success");

            if (csInterface) {
                csInterface.evalScript(data.code, function (result) {
                    if (result && result !== "EvalScript error.") showMsg(result, "success");
                    else if (result === "EvalScript error.") showMsg("Error running script.", "error");
                });
            } else {
                console.log("Simulated execution:", data.code);
            }
        } else {
            showMsg(data.message, "error");
        }
    });
}
