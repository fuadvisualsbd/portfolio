@echo off
color 0C
echo ========================================================
echo        AutoPro Premium Plugin Uninstaller
echo ========================================================
echo.

:: Check for Administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] This uninstaller needs Administrator rights to remove files.
    echo Please wait... Requesting privileges...
    powershell -Command "Start-Process '%~0' -Verb RunAs"
    exit /b
)

echo [1/3] Checking if Adobe Illustrator or Photoshop is running...
:CHECK_ADOBE
set "ILL_OPEN=0"
set "PS_OPEN=0"
tasklist /FI "IMAGENAME eq Illustrator.exe" 2>nul | find /I "Illustrator.exe" >nul && set "ILL_OPEN=1"
tasklist /FI "IMAGENAME eq Photoshop.exe" 2>nul | find /I "Photoshop.exe" >nul && set "PS_OPEN=1"

if "%ILL_OPEN%"=="1" goto ADOBE_WARN
if "%PS_OPEN%"=="1" goto ADOBE_WARN
goto ADOBE_CLEAR

:ADOBE_WARN
color 0E
echo.
echo ========================================================
echo   WARNING: Please Close Adobe Before Uninstalling!
echo ========================================================
echo.
if "%ILL_OPEN%"=="1" echo   [!] Adobe Illustrator is currently running.
if "%PS_OPEN%"=="1" echo   [!] Adobe Photoshop is currently running.
echo.
echo   Please save your work and CLOSE the open Adobe app^(s^).
echo.
echo   After closing, press any key to continue...
pause >nul
goto CHECK_ADOBE

:ADOBE_CLEAR
color 0C
echo [2/3] Removing AutoPro Plugin files...
set "DEST1=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.fuadvisuals.autopro"
set "DEST2=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.mycompany.proscripts"

if exist "%DEST1%" (
    rmdir /s /q "%DEST1%"
    echo Removed folder: com.fuadvisuals.autopro
)

if exist "%DEST2%" (
    rmdir /s /q "%DEST2%"
    echo Removed folder: com.mycompany.proscripts
)

echo.
echo [3/3] Cleanup completed.
echo.
echo ========================================================
echo   SUCCESS! AutoPro has been completely uninstalled.
echo ========================================================
echo.
echo Please restart Adobe Illustrator or Photoshop.
echo.
pause
