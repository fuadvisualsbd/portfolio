@echo off
color 0C
echo ========================================================
echo        AutoPro Premium Plugin Uninstaller
echo ========================================================
echo.

:: Check for Administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] This uninstaller needs Administrator rights to remove files.
    echo Please wait... Requesting privileges...
    powershell -Command "Start-Process '%~0' -Verb RunAs"
    exit /b
)

echo [1/2] Removing AutoPro Plugin files...
set "DEST1=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.fuadvisuals.autopro"
set "DEST2=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.mycompany.proscripts"

if exist "%DEST1%" (
    rmdir /s /q "%DEST1%"
    echo Removed folder: com.fuadvisuals.autopro
)

if exist "%DEST2%" (
    rmdir /s /q "%DEST2%"
    echo Removed folder: com.mycompany.proscripts
)

echo.
echo [2/2] Cleanup completed.
echo.
echo ========================================================
echo   SUCCESS! AutoPro has been completely uninstalled.
echo ========================================================
echo.
echo Please restart Adobe Illustrator or Photoshop.
echo.
pause
