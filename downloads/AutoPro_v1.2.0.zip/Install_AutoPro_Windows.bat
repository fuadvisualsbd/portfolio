@echo off
color 0A
echo ========================================================
echo        AutoPro Premium Plugin Installer
echo ========================================================
echo.

:: Enable PlayerDebugMode for current user BEFORE any admin elevation
echo [1/4] Enabling Adobe Extension Support (User Profile)...
for /L %%i in (5,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

:: Check for Administrator privileges to copy into Program Files
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Requesting administrator privileges to copy extension files...
    powershell -Command "Start-Process '%~0' -Verb RunAs"
    exit /b
)

:: Also set in elevated session just in case
for /L %%i in (5,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo [2/4] Checking if Adobe Illustrator or Photoshop is running...
:CHECK_ADOBE
set "ILL_OPEN=0"
set "PS_OPEN=0"
tasklist /FI "IMAGENAME eq Illustrator.exe" 2>nul | find /I "Illustrator.exe" >nul && set "ILL_OPEN=1"
tasklist /FI "IMAGENAME eq Photoshop.exe" 2>nul | find /I "Photoshop.exe" >nul && set "PS_OPEN=1"

if "%ILL_OPEN%"=="1" goto ADOBE_WARN
if "%PS_OPEN%"=="1" goto ADOBE_WARN
goto ADOBE_CLEAR

:ADOBE_WARN
color 0E
echo.
echo ========================================================
echo   WARNING: Please Close Adobe Before Continuing!
echo ========================================================
echo.
if "%ILL_OPEN%"=="1" echo   [!] Adobe Illustrator is currently running.
if "%PS_OPEN%"=="1" echo   [!] Adobe Photoshop is currently running.
echo.
echo   Please save your work and CLOSE the open Adobe app^(s^).
echo   The plugin cannot install or load properly while open.
echo.
echo   After closing, press any key to continue...
pause >nul
goto CHECK_ADOBE

:ADOBE_CLEAR
color 0A
echo [3/4] Preparing files...
set "DEST=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.fuadvisuals.autopro"
if exist "%DEST%" (
    echo [!] Removing old version...
    rmdir /s /q "%DEST%"
)

echo [4/4] Copying AutoPro to Adobe...
mkdir "%DEST%"
xcopy "%~dp0extension" "%DEST%" /E /I /H /Y >nul

echo.
echo ========================================================
echo   SUCCESS! AutoPro is now installed!
echo ========================================================
echo.
echo You can now open Adobe Illustrator or Photoshop.
echo Go to: Window ^> Extensions ^> Pro Scripts Login
echo.
pause
