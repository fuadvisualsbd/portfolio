@echo off
color 0A
echo ========================================================
echo        AutoPro Premium Plugin Installer
echo ========================================================
echo.

:: Enable PlayerDebugMode for current user BEFORE any admin elevation
echo [1/3] Enabling Adobe Extension Support (User Profile)...
for /L %%i in (5,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

:: Check for Administrator privileges to copy into Program Files
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Requesting administrator privileges to copy extension files...
    powershell -Command "Start-Process '%~0' -Verb RunAs"
    exit /b
)

:: Also set in elevated session just in case
for /L %%i in (5,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo [2/3] Preparing files...
set "DEST=%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.fuadvisuals.autopro"
if exist "%DEST%" (
    echo [!] Removing old version...
    rmdir /s /q "%DEST%"
)

echo [3/3] Copying AutoPro to Adobe...
mkdir "%DEST%"
xcopy "%~dp0extension" "%DEST%" /E /I /H /Y >nul

echo.
echo ========================================================
echo   SUCCESS! AutoPro is now installed!
echo ========================================================
echo.
echo Please restart Adobe Illustrator or Photoshop.
echo Go to: Window ^> Extensions ^> Pro Scripts Login
echo.
pause
