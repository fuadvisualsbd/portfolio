@echo off
setlocal
color 0C

set "USER_APPDATA=%~1"
if not defined USER_APPDATA set "USER_APPDATA=%APPDATA%"
set "USER_LOCALAPPDATA=%~2"
if not defined USER_LOCALAPPDATA set "USER_LOCALAPPDATA=%LOCALAPPDATA%"

set "NEED_ADMIN=0"
if exist "%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent" set "NEED_ADMIN=1"
if exist "%ProgramFiles%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent" set "NEED_ADMIN=1"
if exist "%ProgramData%\Adobe\CEP\extensions\com.adobe.aiagent" set "NEED_ADMIN=1"

if not "%NEED_ADMIN%"=="1" goto SKIP_ELEVATE
net session >nul 2>&1
if %errorLevel% equ 0 goto SKIP_ELEVATE
echo Requesting administrator privileges to remove system-wide extension...
set "SELF_PATH=%~f0"
set "ORIG_APPDATA=%USER_APPDATA%"
set "ORIG_LOCALAPPDATA=%USER_LOCALAPPDATA%"
powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c ' + [char]34 + [char]34 + $env:SELF_PATH + [char]34 + ' ' + [char]34 + $env:ORIG_APPDATA + [char]34 + ' ' + [char]34 + $env:ORIG_LOCALAPPDATA + [char]34 + [char]34) -Verb RunAs"
exit /b

:SKIP_ELEVATE
echo ========================================================
echo        Adobe AI Agent Uninstaller
echo ========================================================
echo.

:CHECK_ADOBE_RUNNING
tasklist /NH /FI "IMAGENAME eq Photoshop.exe" 2>nul | "%SystemRoot%\System32\findstr.exe" /I "Photoshop.exe" >nul
if %errorLevel% equ 0 goto ADOBE_OPEN
tasklist /NH /FI "IMAGENAME eq Illustrator.exe" 2>nul | "%SystemRoot%\System32\findstr.exe" /I "Illustrator.exe" >nul
if %errorLevel% equ 0 goto ADOBE_OPEN
tasklist /NH /FI "IMAGENAME eq AfterFX.exe" 2>nul | "%SystemRoot%\System32\findstr.exe" /I "AfterFX.exe" >nul
if %errorLevel% equ 0 goto ADOBE_OPEN
goto DO_UNINSTALL

:ADOBE_OPEN
echo.
echo [WARN] Adobe Photoshop, Illustrator, or After Effects is currently running!
echo Please CLOSE all Adobe apps so plugin files are not locked.
echo After closing Adobe, press any key to continue...
pause >nul
goto CHECK_ADOBE_RUNNING

:DO_UNINSTALL
taskkill /F /IM CEPHtmlEngine.exe >nul 2>&1
powershell -NoProfile -Command "$d=(Get-Date).AddSeconds(4); while ((Get-Process -Name 'CEPHtmlEngine' -ErrorAction SilentlyContinue) -and ((Get-Date) -lt $d)) { Start-Sleep -Milliseconds 200 }" >nul 2>&1

set "FOUND_ANY=0"
set "HAD_ERROR=0"
call :REMOVE_ONE "%USER_APPDATA%\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%USER_LOCALAPPDATA%\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%ProgramFiles(x86)%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%ProgramFiles%\Common Files\Adobe\CEP\extensions\com.adobe.aiagent"
call :REMOVE_ONE "%ProgramData%\Adobe\CEP\extensions\com.adobe.aiagent"

powershell -NoProfile -Command "foreach ($b in @($env:TEMP, (Join-Path $env:USER_LOCALAPPDATA 'Temp'))) { if ($b) { $c = Join-Path $b 'cep_cache'; if (Test-Path -LiteralPath $c) { Remove-Item -LiteralPath $c -Recurse -Force -ErrorAction SilentlyContinue } } }" >nul 2>&1

if "%FOUND_ANY%"=="0" if "%HAD_ERROR%"=="0" echo [INFO] Adobe AI Agent was not found in any Adobe CEP folder.

echo.
if "%HAD_ERROR%"=="1" goto UNINSTALL_WARN
echo Done! Restart Photoshop / Illustrator.
pause
exit /b 0

:UNINSTALL_WARN
echo [WARN] Some files were locked. Close Photoshop/Illustrator and run again.
pause
exit /b 1

:REMOVE_ONE
set "TARGET_DIR=%~1"
if not defined TARGET_DIR exit /b 0
if not exist "%TARGET_DIR%" exit /b 0
set "DEL_TARGET=%TARGET_DIR%"
powershell -NoProfile -Command "$p=$env:DEL_TARGET; for ($try=1; $try -le 6; $try++) { if (-not (Test-Path -LiteralPath $p)) { break }; try { $i=Get-Item -LiteralPath $p -Force; if ($i.Attributes -band [IO.FileAttributes]::ReparsePoint) { $i.Delete() } else { Get-ChildItem -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { try { if ($_.Attributes -band [IO.FileAttributes]::ReadOnly) { $_.Attributes = $_.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly) } } catch {} }; Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop } } catch {}; if (Test-Path -LiteralPath $p) { Start-Sleep -Milliseconds 300 } }"
if exist "%TARGET_DIR%" goto REMOVE_FAILED
echo [OK] Removed old version: "%TARGET_DIR%"
set "FOUND_ANY=1"
exit /b 0
:REMOVE_FAILED
echo [WARN] Could not remove: "%TARGET_DIR%" - close Photoshop/Illustrator and retry
set "HAD_ERROR=1"
exit /b 0
