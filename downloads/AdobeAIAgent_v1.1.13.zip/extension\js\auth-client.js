(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  var TOKEN_KEY = 'adobe_ai_agent_auth_token';
  var USER_KEY = 'adobe_ai_agent_auth_user';

  function AuthClient() {
    this.token = this._loadToken();
    this.user = this._loadCachedUser();
    this.uiConfig = null;
    this._pollingTimer = null;
  }

  AuthClient.prototype.getVersion = function () {
    return (NS.AppConfig && NS.AppConfig.APP_VERSION) || '1.0.0';
  };

  AuthClient.prototype.getBackendUrl = function () {
    return ((NS.AppConfig && NS.AppConfig.BACKEND_URL) || '').replace(/\/+$/, '');
  };

  AuthClient.prototype._loadToken = function () {
    try {
      return global.localStorage.getItem(TOKEN_KEY) || '';
    } catch (e) {
      return '';
    }
  };

  AuthClient.prototype._loadCachedUser = function () {
    try {
      var raw = global.localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  };

  AuthClient.prototype.saveAuth = function (token, user) {
    this.token = token || '';
    this.user = user || null;
    try {
      if (this.token) global.localStorage.setItem(TOKEN_KEY, this.token);
      else global.localStorage.removeItem(TOKEN_KEY);

      if (this.user) global.localStorage.setItem(USER_KEY, JSON.stringify(this.user));
      else global.localStorage.removeItem(USER_KEY);
    } catch (e) {}
  };

  AuthClient.prototype.clearAuth = function () {
    this.stopPolling();
    this.saveAuth('', null);
  };

  AuthClient.prototype.stopPolling = function () {
    if (this._pollingTimer) {
      clearInterval(this._pollingTimer);
      this._pollingTimer = null;
    }
  };

  AuthClient.prototype.isVersionOlder = function (current, latest) {
    if (!latest) return false;
    if (!current) return true;
    var v1 = String(current).replace(/^v/i, '').split('.');
    var v2 = String(latest).replace(/^v/i, '').split('.');
    var len = Math.max(v1.length, v2.length);
    for (var i = 0; i < len; i++) {
      var a = parseInt(v1[i], 10) || 0;
      var b = parseInt(v2[i], 10) || 0;
      if (a < b) return true;
      if (a > b) return false;
    }
    return false;
  };

  AuthClient.prototype._request = function (method, path, bodyData, useAuth, timeoutMs) {
    var self = this;
    var url = this.getBackendUrl() + path;
    var waitMs = timeoutMs || 20000;
    var payloadStr = (bodyData !== null && bodyData !== undefined) ? JSON.stringify(bodyData) : null;

    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open(method, url, true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      if (useAuth && self.token) {
        xhr.setRequestHeader('Authorization', 'Bearer ' + self.token);
      }
      xhr.timeout = waitMs;
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
          if (xhr.status === 0) return; // handled by onerror/ontimeout
          var parsed = null;
          try {
            parsed = xhr.responseText ? JSON.parse(xhr.responseText) : {};
          } catch (e) {
            parsed = { success: false, message: 'Invalid server response (' + xhr.status + ')' };
          }
          resolve({
            ok: xhr.status >= 200 && xhr.status < 300,
            status: xhr.status,
            data: parsed
          });
        }
      };
      xhr.onerror = function () {
        var bridge = NS.CepBridge;
        if (bridge && bridge.hasNodeFS()) {
          var headers = { 'Content-Type': 'application/json' };
          if (useAuth && self.token) {
            headers.Authorization = 'Bearer ' + self.token;
          }
          bridge.nodeHttpsRequest(url, { method: method, headers: headers }, payloadStr)
            .then(function (nRes) {
              return nRes.text().then(function (txt) {
                var parsed = null;
                try {
                  parsed = txt ? JSON.parse(txt) : {};
                } catch (e2) {
                  parsed = { success: false, message: 'Invalid server response (' + nRes.status + ')' };
                }
                resolve({
                  ok: nRes.ok,
                  status: nRes.status,
                  data: parsed
                });
              });
            })
            .catch(function () {
              reject(new Error('Cannot connect to server. Check your internet connection.'));
            });
          return;
        }
        reject(new Error('Cannot connect to server. Check your internet connection.'));
      };
      xhr.ontimeout = function () {
        reject(new Error('Server request timed out.'));
      };
      if (payloadStr !== null) {
        xhr.send(payloadStr);
      } else {
        xhr.send();
      }
    });
  };

  AuthClient.prototype.fetchUiConfig = function () {
    var self = this;
    var ver = encodeURIComponent(this.getVersion());
    return this._request('GET', '/api/ui-config?v=' + ver + '&t=' + Date.now(), null, false)
      .then(function (res) {
        if (res.data && typeof res.data === 'object') {
          self.uiConfig = res.data;
        }
        return res.data;
      });
  };

  AuthClient.prototype.startLogin = function () {
    return this._request('GET', '/api/start-login?t=' + Date.now(), null, false)
      .then(function (res) {
        if (!res.ok || !res.data || !res.data.loginUrl) {
          throw new Error((res.data && res.data.message) || 'Failed to start Google login.');
        }
        return res.data;
      });
  };

  AuthClient.prototype.pollLogin = function (sessionId, onComplete, onError) {
    var self = this;
    this.stopPolling();
    this._pollingTimer = setInterval(function () {
      self._request(
        'GET',
        '/api/check-login?session=' + encodeURIComponent(sessionId) + '&t=' + Date.now(),
        null,
        false
      ).then(function (res) {
        var d = res.data || {};
        if (d.status === 'completed' && d.token && d.user) {
          self.stopPolling();
          self.saveAuth(d.token, d.user);
          if (onComplete) onComplete(d.user);
        } else if (d.status === 'expired') {
          self.stopPolling();
          if (onError) onError(new Error('Login session expired. Please try again.'));
        }
      }).catch(function () {
        // Keep polling softly on transient network glitches
      });
    }, 2500);
  };

  AuthClient.prototype.verifyUser = function () {
    var self = this;
    if (!this.token) return Promise.resolve({ success: false, unauthenticated: true });
    return this._request(
      'POST',
      '/api/verify-user',
      { version: this.getVersion() },
      true
    ).then(function (res) {
      if (res.status === 401 || res.status === 404) {
        self.clearAuth();
        return { success: false, unauthenticated: true, message: (res.data && res.data.message) || 'Session expired.' };
      }
      if (res.data && res.data.user) {
        self.saveAuth(self.token, res.data.user);
      }
      return res.data;
    });
  };

  AuthClient.prototype.useCredit = function (meta) {
    var self = this;
    if (!this.token) {
      return Promise.resolve({ success: false, unauthenticated: true, message: 'Please sign in first.' });
    }
    var payload = {
      version: this.getVersion(),
      hostApp: (meta && meta.hostApp) || 'unknown',
      hasPersonalKey: !!(meta && meta.hasPersonalKey)
    };
    return this._request('POST', '/api/use-credit', payload, true)
      .then(function (res) {
        if (res.status === 401) {
          self.clearAuth();
          return { success: false, unauthenticated: true, message: (res.data && res.data.message) || 'Session expired.' };
        }
        if (res.data && res.data.user) {
          self.saveAuth(self.token, res.data.user);
        }
        return res.data || { success: false, message: 'Credit check failed.' };
      });
  };

  AuthClient.prototype.adminChat = function (payload) {
    var self = this;
    if (!this.token) {
      return Promise.reject(new Error('Please sign in first.'));
    }
    return this._request('POST', '/api/admin-chat', payload, true, 90000)
      .then(function (res) {
        if (res.status === 401) {
          self.clearAuth();
          throw new Error((res.data && res.data.message) || 'Session expired. Please sign in again.');
        }
        if (!res.ok || !res.data || !res.data.success) {
          throw new Error((res.data && res.data.message) || ('Admin AI error (' + res.status + ')'));
        }
        return {
          text: res.data.text,
          finishReason: res.data.finishReason || '',
          modelUsed: res.data.modelUsed || 'admin-ai'
        };
      });
  };

  NS.AuthClient = AuthClient;
})(window);
