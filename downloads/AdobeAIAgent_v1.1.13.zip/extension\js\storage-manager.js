(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  function StorageManager() {
    this.bridge = NS.CepBridge;
    this.fs = this.bridge.fs;
    this.path = this.bridge.path;
    this.rootDir = this._resolveStorageRoot();
    this.isDiskAvailable = !!(this.fs && this.path && this.rootDir);
    this.activeAccountEmail = '';
    this.activeAccountSlug = '';
    if (this.isDiskAvailable) {
      this._ensureBaseDirs();
    }
  }

  StorageManager.prototype._resolveStorageRoot = function () {
    if (!this.bridge.hasNodeFS()) return '';
    var osMod = this.bridge.os;
    if (osMod && typeof osMod.homedir === 'function' && this.path) {
      return this.path.join(osMod.homedir(), 'Documents', 'AdobeAIAgent');
    }
    var extRoot = this.bridge.getExtensionRoot();
    if (!extRoot) return '';
    return this.path.join(extRoot, 'storage');
  };

  StorageManager.prototype._ensureDir = function (dirPath) {
    if (!this.isDiskAvailable || !dirPath) return;
    try {
      if (this.fs.existsSync(dirPath)) return;
      var parent = this.path.dirname(dirPath);
      if (parent && parent !== dirPath && !this.fs.existsSync(parent)) {
        this._ensureDir(parent);
      }
      this.fs.mkdirSync(dirPath);
    } catch (e) {}
  };

  StorageManager.prototype._postLocalJson = function (url, payload) {
    try {
      if (!global.location || global.location.protocol.indexOf('http') !== 0) return;
      var xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(JSON.stringify(payload));
    } catch (e) {}
  };

  StorageManager.prototype._ensureBaseDirs = function () {
    this._ensureDir(this.rootDir);
    this._ensureDir(this.path.join(this.rootDir, 'accounts'));
  };

  StorageManager.prototype._hashString = function (str) {
    var h = 2166136261;
    var s = String(str || '');
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(36);
  };

  StorageManager.prototype._makeAccountSlug = function (email) {
    var clean = String(email || '').trim().toLowerCase();
    if (!clean) return '';
    var safe = clean
      .replace(/@/g, '_at_')
      .replace(/[^a-z0-9_\-]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 36) || 'user';
    return safe + '_' + this._hashString(clean);
  };

  StorageManager.prototype._getAccountRootDir = function () {
    if (!this.isDiskAvailable || !this.activeAccountSlug) return '';
    return this.path.join(this.rootDir, 'accounts', this.activeAccountSlug);
  };

  StorageManager.prototype._ensureAccountDirs = function () {
    var accRoot = this._getAccountRootDir();
    if (!accRoot) return;
    this._ensureDir(accRoot);
    this._ensureDir(this.path.join(accRoot, 'chats'));
    this._ensureDir(this.path.join(accRoot, 'scripts'));
    this._ensureDir(this.path.join(accRoot, 'uploads'));
    this._ensureDir(this.path.join(accRoot, 'exports'));
    this._ensureDir(this.path.join(accRoot, 'temp'));
  };

  StorageManager.prototype.setActiveAccount = function (userOrEmail) {
    var rawEmail = typeof userOrEmail === 'string'
      ? userOrEmail
      : ((userOrEmail && userOrEmail.email) || '');
    var cleanEmail = String(rawEmail || '').trim().toLowerCase();
    this.activeAccountEmail = cleanEmail;
    this.activeAccountSlug = cleanEmail ? this._makeAccountSlug(cleanEmail) : '';
    if (this.isDiskAvailable && this.activeAccountSlug) {
      this._ensureAccountDirs();
    }
    return this.activeAccountSlug;
  };

  StorageManager.prototype.getActiveAccountEmail = function () {
    return this.activeAccountEmail;
  };

  StorageManager.prototype._lsKey = function (suffix) {
    if (!this.activeAccountSlug) return '';
    return 'adobe_ai_agent_acc_' + this.activeAccountSlug + '_' + suffix;
  };

  StorageManager.prototype.getDownloadsDir = function () {
    var osMod = this.bridge && this.bridge.os;
    if (osMod && typeof osMod.homedir === 'function' && this.path) {
      return this.path.join(osMod.homedir(), 'Downloads').replace(/\\/g, '/');
    }
    if (typeof process !== 'undefined' && process.env && (process.env.USERPROFILE || process.env.HOME)) {
      return String(process.env.USERPROFILE || process.env.HOME).replace(/\\/g, '/') + '/Downloads';
    }
    return '~/Downloads';
  };

  StorageManager.prototype.getStoragePaths = function (sessionId) {
    var sid = this._safeSlug(sessionId || 'default');
    var downloadsDir = this.getDownloadsDir();
    var accRoot = this._getAccountRootDir();
    if (this.isDiskAvailable && accRoot) {
      var exportsDir = this.path.join(accRoot, 'exports', sid);
      var scriptsDir = this.path.join(accRoot, 'scripts', sid);
      var uploadsDir = this.path.join(accRoot, 'uploads', sid);
      var tempDir = this.path.join(accRoot, 'temp', sid);
      this._ensureDir(exportsDir);
      this._ensureDir(scriptsDir);
      this._ensureDir(uploadsDir);
      this._ensureDir(tempDir);
      return {
        rootDir: accRoot.replace(/\\/g, '/'),
        exportsDir: exportsDir.replace(/\\/g, '/'),
        downloadsDir: downloadsDir,
        scriptsDir: scriptsDir.replace(/\\/g, '/'),
        uploadsDir: uploadsDir.replace(/\\/g, '/'),
        tempDir: tempDir.replace(/\\/g, '/')
      };
    }
    if (this.isDiskAvailable && this.rootDir) {
      return {
        rootDir: this.rootDir.replace(/\\/g, '/'),
        exportsDir: this.path.join(this.rootDir, 'exports').replace(/\\/g, '/'),
        downloadsDir: downloadsDir,
        scriptsDir: this.path.join(this.rootDir, 'scripts').replace(/\\/g, '/'),
        uploadsDir: this.path.join(this.rootDir, 'uploads').replace(/\\/g, '/'),
        tempDir: this.path.join(this.rootDir, 'temp').replace(/\\/g, '/')
      };
    }
    var baseSlug = this.activeAccountSlug ? ('accounts/' + this.activeAccountSlug) : 'guest';
    return {
      rootDir: 'storage/' + baseSlug,
      exportsDir: 'storage/' + baseSlug + '/exports/' + sid,
      downloadsDir: downloadsDir,
      scriptsDir: 'storage/' + baseSlug + '/scripts/' + sid,
      uploadsDir: 'storage/' + baseSlug + '/uploads/' + sid,
      tempDir: 'storage/' + baseSlug + '/temp/' + sid
    };
  };

  StorageManager.prototype._safeSlug = function (str) {
    return String(str || 'item')
      .toLowerCase()
      .replace(/[^a-z0-9_\-]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 48) || 'item';
  };

  // ───────── Config Persistence ─────────

  StorageManager.prototype.loadConfig = function () {
    if (this.isDiskAvailable) {
      try {
        var cfgPath = this.path.join(this.rootDir, 'config.json');
        if (this.fs.existsSync(cfgPath)) {
          return JSON.parse(this.fs.readFileSync(cfgPath, 'utf8'));
        }
      } catch (e) {}
    }
    try {
      var raw = global.localStorage.getItem('adobe_ai_agent_config');
      if (raw) return JSON.parse(raw);
    } catch (e2) {}
    return null;
  };

  StorageManager.prototype.saveConfig = function (cfg) {
    try {
      global.localStorage.setItem('adobe_ai_agent_config', JSON.stringify(cfg));
    } catch (e) {}

    if (this.isDiskAvailable) {
      try {
        this._ensureDir(this.rootDir);
        var cfgPath = this.path.join(this.rootDir, 'config.json');
        this.fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), 'utf8');
      } catch (e2) {}
    } else {
      this._postLocalJson('/api/storage/config', cfg);
    }
  };

  // ───────── Chat History Persistence (Scoped per Google Account) ─────────

  StorageManager.prototype.listSessions = function () {
    if (!this.activeAccountSlug) return [];
    var accRoot = this._getAccountRootDir();
    if (this.isDiskAvailable && accRoot) {
      try {
        var idxPath = this.path.join(accRoot, 'chats', 'index.json');
        if (this.fs.existsSync(idxPath)) {
          var arr = JSON.parse(this.fs.readFileSync(idxPath, 'utf8'));
          if (Array.isArray(arr)) return arr;
        }
      } catch (e) {}
    }
    try {
      var key = this._lsKey('sessions_index');
      var raw = key ? global.localStorage.getItem(key) : null;
      if (raw) {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e2) {}
    return [];
  };

  StorageManager.prototype._saveSessionsIndex = function (sessionsIndex) {
    if (!this.activeAccountSlug) return;
    try {
      var key = this._lsKey('sessions_index');
      if (key) global.localStorage.setItem(key, JSON.stringify(sessionsIndex));
    } catch (e) {}
    var accRoot = this._getAccountRootDir();
    if (this.isDiskAvailable && accRoot) {
      try {
        var chatsDir = this.path.join(accRoot, 'chats');
        this._ensureDir(chatsDir);
        this.fs.writeFileSync(
          this.path.join(chatsDir, 'index.json'),
          JSON.stringify(sessionsIndex, null, 2),
          'utf8'
        );
      } catch (e2) {}
    }
  };

  StorageManager.prototype.loadSession = function (sessionId) {
    if (!this.activeAccountSlug || !sessionId) return null;
    var accRoot = this._getAccountRootDir();
    if (this.isDiskAvailable && accRoot) {
      try {
        var filePath = this.path.join(accRoot, 'chats', this._safeSlug(sessionId) + '.json');
        if (this.fs.existsSync(filePath)) {
          return JSON.parse(this.fs.readFileSync(filePath, 'utf8'));
        }
      } catch (e) {}
    }
    try {
      var key = this._lsKey('session_' + sessionId);
      var raw = key ? global.localStorage.getItem(key) : null;
      if (raw) return JSON.parse(raw);
    } catch (e2) {}
    return null;
  };

  StorageManager.prototype.saveSession = function (sessionObj) {
    if (!this.activeAccountSlug || !sessionObj || !sessionObj.id) return;

    // Strip ultra-heavy base64 data when saving index, keep lightweight image previews or disk paths in session
    var cleanSession = JSON.parse(JSON.stringify(sessionObj));
    cleanSession.accountEmail = this.activeAccountEmail;
    var lsSessionKey = this._lsKey('session_' + sessionObj.id);
    try {
      if (lsSessionKey) {
        global.localStorage.setItem(lsSessionKey, JSON.stringify(cleanSession));
      }
    } catch (e) {
      // If localStorage quota is tight due to base64 images, strip inline dataUrls for localStorage backup only
      try {
        var compact = JSON.parse(JSON.stringify(cleanSession));
        (compact.messages || []).forEach(function (m) {
          if (Array.isArray(m.images)) {
            m.images = m.images.map(function (img) {
              return { name: img.name, diskPath: img.diskPath, mimeType: img.mimeType };
            });
          }
        });
        if (lsSessionKey) {
          global.localStorage.setItem(lsSessionKey, JSON.stringify(compact));
        }
      } catch (eQuota) {}
    }

    var accRoot = this._getAccountRootDir();
    if (this.isDiskAvailable && accRoot) {
      try {
        var chatsDir = this.path.join(accRoot, 'chats');
        this._ensureDir(chatsDir);
        this.fs.writeFileSync(
          this.path.join(chatsDir, this._safeSlug(sessionObj.id) + '.json'),
          JSON.stringify(cleanSession, null, 2),
          'utf8'
        );
      } catch (e2) {}
    } else {
      this._postLocalJson('/api/storage/session', cleanSession);
    }

    // Update index
    var idx = this.listSessions();
    var summary = {
      id: sessionObj.id,
      title: sessionObj.title || 'New Chat',
      hostApp: sessionObj.hostApp || 'unknown',
      updatedAt: sessionObj.updatedAt || Date.now(),
      messageCount: (sessionObj.messages || []).length,
      scriptCount: (sessionObj.scripts || []).length
    };
    var existingIdx = -1;
    for (var i = 0; i < idx.length; i++) {
      if (idx[i].id === sessionObj.id) {
        existingIdx = i;
        break;
      }
    }
    if (existingIdx >= 0) {
      idx[existingIdx] = summary;
    } else {
      idx.unshift(summary);
    }
    idx.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); });
    this._saveSessionsIndex(idx);
  };

  StorageManager.prototype.deleteSession = function (sessionId) {
    if (!this.activeAccountSlug || !sessionId) return;
    try {
      var key = this._lsKey('session_' + sessionId);
      if (key) global.localStorage.removeItem(key);
    } catch (e) {}
    var accRoot = this._getAccountRootDir();
    if (this.isDiskAvailable && accRoot) {
      try {
        var p = this.path.join(accRoot, 'chats', this._safeSlug(sessionId) + '.json');
        if (this.fs.existsSync(p)) this.fs.unlinkSync(p);
      } catch (e2) {}
    }
    var idx = this.listSessions().filter(function (s) { return s.id !== sessionId; });
    this._saveSessionsIndex(idx);
  };

  // ───────── JSX Script & Asset Persistence ─────────

  StorageManager.prototype.saveScriptFile = function (sessionId, scriptName, jsxCode, meta) {
    var paths = this.getStoragePaths(sessionId);
    var ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    var fileName = ts + '_' + this._safeSlug(scriptName || 'command') + '.jsx';
    var fullPath = paths.scriptsDir + '/' + fileName;

    var header =
      '// ============================================================================\n' +
      '// Adobe AI Agent — Saved ExtendScript Command\n' +
      '// Host App : ' + ((meta && meta.hostApp) || 'unknown') + '\n' +
      '// Timestamp: ' + new Date().toLocaleString() + '\n' +
      '// Prompt   : ' + String((meta && meta.prompt) || '').replace(/\r?\n/g, ' ').slice(0, 180) + '\n' +
      '// Status   : ' + ((meta && meta.status) || 'executed') + '\n' +
      '// ============================================================================\n\n';

    var fileContent = header + String(jsxCode || '');

    if (this.isDiskAvailable) {
      try {
        this.fs.writeFileSync(fullPath, fileContent, 'utf8');
      } catch (e) {}
    } else {
      this._postLocalJson('/api/storage/script', { sessionId: sessionId, fileName: fileName, content: fileContent });
    }

    return {
      fileName: fileName,
      fullPath: fullPath
    };
  };

  StorageManager.prototype.saveUploadedImage = function (sessionId, dataUrl, origName) {
    var paths = this.getStoragePaths(sessionId);
    var match = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!match) return null;

    var mime = match[1];
    var b64 = match[2];
    var ext = mime.indexOf('png') >= 0 ? 'png' : (mime.indexOf('webp') >= 0 ? 'webp' : 'jpg');
    var base = this._safeSlug((origName || 'upload').replace(/\.[^\.]+$/, ''));
    var fileName = Date.now() + '_' + base + '.' + ext;
    var fullPath = paths.uploadsDir + '/' + fileName;

    if (this.isDiskAvailable && typeof Buffer !== 'undefined') {
      try {
        var buf = typeof Buffer.from === 'function' ? Buffer.from(b64, 'base64') : new Buffer(b64, 'base64');
        this.fs.writeFileSync(fullPath, buf);
        return fullPath;
      } catch (e) {}
    }
    return null;
  };

  StorageManager.prototype.saveTempAsset = function (sessionId, filename, content) {
    var paths = this.getStoragePaths(sessionId);
    var safe = String(filename || 'asset.svg').replace(/[^a-zA-Z0-9._\-]/g, '_');
    var fullPath = paths.tempDir + '/' + safe;

    if (this.isDiskAvailable) {
      try {
        this.fs.writeFileSync(fullPath, String(content || ''), 'utf8');
        return fullPath;
      } catch (e) {}
    }
    return fullPath;
  };

  NS.StorageManager = StorageManager;
})(window);
