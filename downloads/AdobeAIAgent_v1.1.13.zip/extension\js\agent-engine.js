(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  function AgentEngine(apiHandler, storageManager) {
    this.api = apiHandler;
    this.storage = storageManager;
    this.bridge = NS.CepBridge;
  }

  AgentEngine.prototype._buildSystemPrompt = function (hostInfo, docContext, paths, attachedUploads) {
    var targetApp = hostInfo.label || hostInfo.app;
    if (hostInfo.app === 'browser') {
      targetApp = 'photoshop or illustrator (currently in Browser Preview mode)';
    }

    var isPS = hostInfo.app === 'photoshop';
    var isAI = hostInfo.app === 'illustrator';

    var userUploads = [];
    var autoCanvasImg = null;
    if (Array.isArray(attachedUploads)) {
      for (var ui = 0; ui < attachedUploads.length; ui++) {
        var item = attachedUploads[ui];
        if (!item) continue;
        if (item.isAutoCanvas) autoCanvasImg = item;
        else userUploads.push(item);
      }
    }

    var uploadDesc = 'None';
    if (userUploads.length > 0) {
      uploadDesc = userUploads
        .map(function (u, i) {
          return 'Upload #' + i + ': name="' + u.name + '", localPath="' + (u.diskPath || 'not-saved') + '"';
        })
        .join('\n');
    }

    var liveCanvasDesc = autoCanvasImg
      ? ('YES — An automatic live screenshot of the user\'s currently open project ("' + (autoCanvasImg.docName || (docContext && docContext.docName) || 'Active Document') + '") is attached to the latest user message. Inspect it visually to see the current artwork, layout, colors, text, and composition before editing or answering. NEVER treat this auto-captured live screenshot as an uploaded asset file to place onto the canvas.')
      : 'None';

    var commonRules = [
      'You are "Adobe AI Agent", an expert interactive creative automation assistant working directly inside Adobe (CC 2015 through 2026).',
      'DETECTED HOST APP: ' + targetApp + ' (Auto-detected from Adobe CEP host environment — NEVER ask the user which app they opened).',
      'LANGUAGE: Reply naturally in the same language/style the user writes in (e.g., Banglish, Bengali, or English). Keep replies concise, friendly, and clear.',
      '',
      'LIVE HOST & DOCUMENT CONTEXT (JSON):',
      JSON.stringify(docContext || {}, null, 2),
      '',
      'LIVE OPEN PROJECT SCREENSHOT:',
      liveCanvasDesc,
      '',
      'FILESYSTEM PATHS (Always use forward slashes "/" in ExtendScript):',
      '- Default Exports folder: "' + paths.exportsDir + '"',
      '- User Downloads folder (ONLY use when user explicitly asks to save/export to Downloads): "' + (paths.downloadsDir || '~/Downloads') + '"',
      '- Temp SVG/assets folder: "' + paths.tempDir + '"',
      '- Attached uploads on disk:\n' + uploadDesc,
      '- SAVE DESTINATION RULE: By default save/export to "' + paths.exportsDir + '". If the user explicitly asks to save to Downloads ("download folder", "downloads"), pass "' + (paths.downloadsDir || '~/Downloads') + '" as outputDir.',
      '',
      'SINGLE VS MULTIPLE EXPORT RULE (NO UI SELECTOR — PROMPT DRIVEN):',
      '- Determine single vs multiple export strictly from the user prompt.',
      '- If the user does NOT ask for multiple variations/exports, default to SINGLE (1 design, 1 export).',
      '- If the user specifies a count (e.g. "3 ta banao", "5 versions", "4 colorways export koro"), set exportMode="multiple", exportCount=N, and create/export ALL N distinct variations in one clean run (e.g. design_01, design_02, ..., design_0N).',
      '- If the user says "multiple" / "koekta" / "several" WITHOUT saying how many, do NOT guess — use action="ask_user" to ask how many they want.',
      '',
      'CLARIFICATION RULE (ASK WHEN CONFUSED):',
      '- If the user prompt is ambiguous, missing key info (like count for "multiple", unclear edit target when no document is open, unclear text/copy when required, or unclear whether to use uploaded image as a style reference vs placing it directly), set action="ask_user" and ask clearly in chat with 2-4 helpful quick-reply options in "questions".',
      '- Do NOT execute guesswork in the Adobe app if the request is genuinely unclear.',
      '',
      'EXTENDSCRIPT (JSX) STRICT ES3 SYNTAX RULES (COMPATIBLE WITH ADOBE CC 2015 - 2026):',
      '- Adobe ExtendScript uses ES3 ONLY! NEVER use let, const, arrow functions (=>), template backticks (`), spread (...), destructuring, classes, or Array.prototype.map/forEach.',
      '- ALWAYS use var, function() {}, and standard for (var i = 0; ...) loops.',
      '- Your jsxScript runs inside a function body where all pre-loaded helpers are available. Always end your jsxScript with: return { ok: true, message: "...", exportedFiles: [...], details: {...} };'
    ].join('\n');

    var psRules = [
      '',
      'PHOTOSHOP SPECIFIC RULES (CC 2015–2026):',
      '1. MINIMUM CANVAS / ARTBOARD SIZE = 4K (3840x2160 px, >= 8,294,400 pixels). DEFAULT RATIO = 16:9 (3840x2160 px).',
      '2. NEVER create a document smaller than 4K! Always call PS_createDoc(name, widthPx, heightPx, ratioStr, bgRGB, 72) — passing null, null, "16:9" creates 3840x2160.',
      '3. If the user asks for another aspect ratio (e.g. "1:1", "4:3", "9:16"), pass that ratioStr to PS_createDoc; PS_ensure4KDims automatically scales it to >= 4K.',
      '4. If an existing document is already open and the user asks to edit/modify THAT document, work on app.activeDocument instead of overwriting it. If no doc is open or user wants a new design, call PS_createDoc.',
      '5. Available Pre-loaded Photoshop Helpers:',
      '   - PS_createDoc(name, widthPx, heightPx, ratioStr, bgRGB, resolutionPpi) -> returns Document',
      '   - PS_fillBackground(r, g, b)',
      '   - PS_addGradientLayer(name, r1, g1, b1, r2, g2, b2, angleDeg, opacity)',
      '   - PS_addSolidRect(name, x, y, w, h, r, g, b, opacity, cornerRadius)',
      '   - PS_addEllipse(name, x, y, w, h, r, g, b, opacity)',
      '   - PS_addText(name, textStr, x, y, fontSizePx, r, g, b, fontName, alignStr, tracking)',
      '   - PS_placeImage(filePath, layerName, x, y, targetW, targetH)',
      '   - PS_export(doc, outputDir, baseName, ["psd", "png"]) -> returns array of exported file paths',
      '6. When generating multiple variations, create each variation cleanly, export with PS_export(doc, "' + paths.exportsDir + '", baseName + "_01", ["psd", "png"]), and close intermediate temp docs if creating many so memory stays clean (or keep the final one open for preview!).'
    ].join('\n');

    var aiRules = [
      '',
      'ILLUSTRATOR SPECIFIC RULES (CC 2015–2026):',
      '1. ARTBOARD SIZE = 20 MP (20,000,000 sq pt/px). DEFAULT RATIO = 4:3 (5164 x 3873 pt/px).',
      '2. Always create new documents via AI_createDoc(name, ratioStr, customW, customH, "RGB") — passing null for customW/customH and "4:3" for ratioStr creates exact 5164x3873 (20.00 MP 4:3).',
      '3. MANDATORY PRE-SAVE BOUNDS CHECK: Every save/export MUST go through AI_saveAndExport(doc, outputDir, baseName, formatsArray) — it automatically runs AI_enforceArtboardBounds(doc) BEFORE saving to guarantee 0 objects extend outside the artboard!',
      '4. VECTOR CRAFT & SVG PIPELINE (STRONGLY RECOMMENDED FOR RICH ARTWORK):',
      '   - For icons, illustrations, logos, patterns, badges, UI cards, or recreating an uploaded image in vector: write rich, high-detail pure vector SVG(s) in the "assets" array with viewBox="0 0 5164 3873" (or matching the requested 20MP aspect ratio), save-safe for Illustrator & EPS-10 (100% opaque 6-digit hex colors #RRGGBB, NO opacity < 1, NO rgba(), NO <filter>, NO <clipPath>, NO <mask>, NO stroke="url(#...)").',
      '   - Keep ALL SVG coordinates strictly inside the viewBox (0..width, 0..height)!',
      '   - In jsxScript, import each generated SVG file from "' + paths.tempDir + '/<filename>" into your 20MP 4:3 document using AI_importSVG(svgPath, doc, 0)!',
      '5. Available Pre-loaded Illustrator Helpers (top-left origin: x=0..width right, y=0..height down):',
      '   - AI_createDoc(name, ratioStr, customW, customH, colorSpaceStr) -> returns Document (default "4:3" = 5164x3873)',
      '   - AI_rgb(r, g, b) -> RGBColor',
      '   - AI_rect(parent, x, y, w, h, fillColor, strokeColor, strokeWidth)',
      '   - AI_roundedRect(parent, x, y, w, h, rx, ry, fillColor, strokeColor, strokeWidth)',
      '   - AI_ellipse(parent, x, y, w, h, fillColor, strokeColor, strokeWidth)',
      '   - AI_polygon(parent, cx, cy, radius, sides, fillColor, strokeColor, strokeWidth)',
      '   - AI_path(parent, ptsArray, closed, fillColor, strokeColor, strokeWidth)',
      '   - AI_linearGradient(doc, name, [{offset:0,r:...,g:...,b:...}, {offset:100,r:...,g:...,b:...}], angleDeg)',
      '   - AI_text(parent, textStr, x, y, fontSize, fillColor, fontName, outlineBool)',
      '   - AI_importSVG(svgFilePath, targetDoc, fitMarginPt)',
      '   - AI_enforceArtboardBounds(doc) -> returns { ok, removedCount, adjustedCount, outOfBoundsCount }',
      '   - AI_saveAndExport(doc, outputDir, baseName, ["ai", "eps", "png"]) -> runs bounds check first, returns { audit, files }'
    ].join('\n');

    var outputFormat = [
      '',
      'RESPONSE FORMAT (STRICT JSON ONLY — NO MARKDOWN OUTSIDE JSON):',
      '{',
      '  "action": "ask_user" | "execute" | "chat",',
      '  "reply": "Clear response to show the user in chat",',
      '  "questions": ["Optional short clickable answer chips when action is ask_user"],',
      '  "planSummary": "1-line summary of what the script builds",',
      '  "exportMode": "single" | "multiple" | "none",',
      '  "exportCount": 1,',
      '  "scriptName": "short_snake_case_name",',
      '  "assets": [',
      '    { "type": "svg", "filename": "art_01.svg", "content": "<svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 5164 3873\\">...</svg>" }',
      '  ],',
      '  "jsxScript": "Pure ES3 ExtendScript code to run inside the host app (only when action is execute)"',
      '}'
    ].join('\n');

    if (isPS) return commonRules + psRules + outputFormat;
    if (isAI) return commonRules + aiRules + outputFormat;
    return commonRules + psRules + aiRules + outputFormat;
  };

  AgentEngine.prototype._normalizeParsed = function (obj) {
    if (!obj || typeof obj !== 'object') return obj;
    var act = String(obj.action || '').trim();
    var hasScript = !!(obj.jsxScript && String(obj.jsxScript).trim());
    if (hasScript && (!act || act === 'executeScript' || act === 'execute_script' || act === 'run')) {
      obj.action = 'execute';
    }
    obj._parseOk = true;
    return obj;
  };

  AgentEngine.prototype._parseAgentJSON = function (rawText) {
    var txt = String(rawText || '').trim();
    if (!txt) {
      return { action: 'chat', reply: 'Empty response from AI model.', _parseOk: false, _looksLikeJson: false };
    }

    var fenced = txt.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
    if (fenced && fenced[1]) {
      try {
        return this._normalizeParsed(JSON.parse(fenced[1]));
      } catch (e1) {}
    }

    try {
      return this._normalizeParsed(JSON.parse(txt));
    } catch (e2) {}

    var firstBrace = txt.indexOf('{');
    var lastBrace = txt.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      try {
        return this._normalizeParsed(JSON.parse(txt.slice(firstBrace, lastBrace + 1)));
      } catch (e3) {}
    }

    return {
      action: 'chat',
      reply: txt,
      _parseOk: false,
      _looksLikeJson: /^[\s`]*\{/.test(txt)
    };
  };

  AgentEngine.prototype._sanitizeES3Basic = function (code) {
    if (!code) return '';
    return String(code)
      .replace(/^(\s*)(const|let)\s+/gm, '$1var ')
      .replace(/([;{]\s*)(const|let)\s+/g, '$1var ');
  };

  AgentEngine.prototype._buildApiConversation = function (sessionMessages) {
    var out = [];
    var recent = (sessionMessages || []).slice(-14);
    for (var i = 0; i < recent.length; i++) {
      var m = recent[i];
      var isLatest = (i === recent.length - 1);
      if (m.role === 'user') {
        out.push({
          role: 'user',
          content: m.content || '',
          images: Array.isArray(m.images) ? m.images.filter(function (img) {
            if (!img || !img.dataUrl) return false;
            if (!isLatest && img.isAutoCanvas) return false;
            return true;
          }) : []
        });
      } else if (m.role === 'assistant') {
        var summary = String(m.content || '');
        if (!m.execution && (/^[\s`]*\{/.test(summary) || summary.indexOf('Error:') === 0)) {
          continue;
        }
        if (m.execution && m.execution.ok) {
          summary += '\n[Executed script "' + (m.execution.scriptFile || '') + '" successfully.]';
        }
        out.push({
          role: 'assistant',
          content: summary
        });
      }
    }
    return out;
  };

  AgentEngine.prototype._writeAssetsToTemp = function (sessionId, assets) {
    var saved = [];
    if (Array.isArray(assets)) {
      for (var a = 0; a < assets.length; a++) {
        var asset = assets[a];
        if (asset && asset.filename && asset.content) {
          var assetPath = this.storage.saveTempAsset(sessionId, asset.filename, asset.content);
          saved.push({ filename: asset.filename, path: assetPath });
        }
      }
    }
    return saved;
  };

  AgentEngine.prototype._buildRecheckPrompt = function (hostInfo, originalPrompt, planSummary, resultData, postDocContext, hasPostPreview) {
    var auditInfo = (resultData && resultData.audit) ? JSON.stringify(resultData.audit) : 'N/A';
    var exportedInfo = (resultData && (resultData.exportedFiles || resultData.files))
      ? JSON.stringify(resultData.exportedFiles || resultData.files)
      : 'None';

    return [
      'STOCK ASSET QUALITY RECHECK (1-TIME QA PASS — DO NOT RECREATE FROM SCRATCH UNLESS BROKEN):',
      'Original User Request: ' + String(originalPrompt || ''),
      'Target App: ' + (hostInfo.label || hostInfo.app),
      'Build Plan Summary: ' + String(planSummary || 'N/A'),
      'Execution Result Details: ' + JSON.stringify(resultData || {}),
      'Bounds Audit: ' + auditInfo,
      'Exported Files: ' + exportedInfo,
      'Post-Execution Document Context: ' + JSON.stringify(postDocContext || {}),
      'Post-Execution Live Canvas Screenshot Attached: ' + (hasPostPreview ? 'YES (inspect visually now)' : 'NO (inspect metadata & context)'),
      '',
      'Evaluate whether the generated output in the active document is READY as a clean, commercial-grade stock asset (Adobe Stock / Shutterstock / Freepik):',
      '1. Canvas/Artboard Specs & Bounds: Illustrator should be 20MP with 0 out-of-bounds objects; Photoshop should be >= 4K; no clipped/cut-off edges.',
      '2. Visual & Structural Quality: Clean composition, balanced spacing/centering, no overlapping/broken text or shapes, no blank/empty artboard, crisp contrast, clean isolated/transparent or intentional background.',
      '3. Stock Compliance (IP & Technical): No branded devices/logos/crypto symbols; EPS-10/AI safe clean layers and colors.',
      '4. Prompt Match: Matches what the user asked for.',
      '',
      'RESPONSE RULES (STRICT JSON ONLY):',
      '- If it looks GOOD and ready as a stock asset: return {"action":"chat","reply":"Short QA confirmation in the user\'s language that the asset passed stock quality check."}',
      '- ONLY if there is an actual visual/layout/bounds/export issue that needs fixing: return {"action":"execute","reply":"Short note of what issue was found and fixed","planSummary":"Stock QA fix","scriptName":"stock_qa_fix","assets":[...optional SVG assets...],"jsxScript":"Pure ES3 ExtendScript that fixes the currently open document (or repairs & re-exports to the same exported path) without breaking good elements."}'
    ].join('\n');
  };

  AgentEngine.prototype._runStockRecheckOnce = function (session, hostInfo, paths, systemPrompt, originalPrompt, planSummary, initialExecResult, notify, normalizePreviewFn) {
    var self = this;
    notify('Rechecking stock asset quality (1/1)...');

    var captureP = (typeof self.bridge.captureActivePreview === 'function')
      ? self.bridge.captureActivePreview(paths.tempDir).then(function (cap) {
          if (!cap || !cap.dataUrl) return null;
          if (typeof normalizePreviewFn === 'function') {
            return normalizePreviewFn(cap.dataUrl).then(function (normUrl) {
              if (!normUrl) return null;
              cap.dataUrl = normUrl;
              return cap;
            });
          }
          return cap;
        })['catch'](function () { return null; })
      : Promise.resolve(null);

    return Promise.all([
      captureP,
      self.bridge.getDocumentContext()['catch'](function () { return null; })
    ]).then(function (pair) {
      var postCap = pair[0];
      var postCtx = pair[1];
      var resultData = (initialExecResult && initialExecResult.result) || {};
      var qaPrompt = self._buildRecheckPrompt(hostInfo, originalPrompt, planSummary, resultData, postCtx, !!(postCap && postCap.dataUrl));

      var qaMessages = [{
        role: 'user',
        content: qaPrompt,
        images: postCap ? [postCap] : []
      }];

      return self.api.sendAgentChat(qaMessages, systemPrompt, 0, { expectJson: true }).then(function (qaRaw) {
        var qaParsed = self._parseAgentJSON(qaRaw.text);
        if (!qaParsed || qaParsed.action !== 'execute' || !String(qaParsed.jsxScript || '').trim()) {
          return {
            performed: true,
            status: 'passed',
            summary: (qaParsed && qaParsed.reply) ? String(qaParsed.reply) : 'Passed stock asset quality check.'
          };
        }

        notify('Fixing stock asset issues...');
        var fixAssets = self._writeAssetsToTemp(session.id, qaParsed.assets);
        var fixScript = self._sanitizeES3Basic(qaParsed.jsxScript);
        var fixName = qaParsed.scriptName || 'stock_qa_fix';
        var fixSavedInfo = self.storage.saveScriptFile(session.id, fixName, fixScript, {
          hostApp: hostInfo.label,
          prompt: originalPrompt,
          status: 'stock_recheck_fix'
        });

        function runFixAttempt(attempt, curCode, curSavedInfo, curAssets) {
          return self.bridge.evalScriptSafe(curCode).then(function (fixExec) {
            if (fixExec && fixExec.ok) {
              return {
                performed: true,
                status: 'fixed',
                summary: qaParsed.reply || 'Auto-fixed for commercial stock quality.',
                execResult: fixExec,
                scriptCode: curCode,
                savedInfo: curSavedInfo,
                assets: curAssets
              };
            }
            if (attempt >= 2) {
              return {
                performed: true,
                status: 'fix_failed',
                summary: (fixExec && (fixExec.error || fixExec.description)) || 'Stock QA fix script failed.'
              };
            }
            var errText = (fixExec && (fixExec.error || fixExec.description)) || 'Unknown ExtendScript error';
            var fixRepairMsgs = qaMessages.concat([
              { role: 'assistant', content: JSON.stringify(qaParsed) },
              {
                role: 'user',
                content: 'Your stock QA fix ExtendScript (ES3) failed with: ' + errText + (fixExec && fixExec.line ? ' (Line ' + fixExec.line + ')' : '') + '. Return corrected JSON with action="execute" and strict ES3 jsxScript.'
              }
            ]);
            return self.api.sendAgentChat(fixRepairMsgs, systemPrompt, 0, { expectJson: true }).then(function (repRaw) {
              var repParsed = self._parseAgentJSON(repRaw.text);
              if (!repParsed || !String(repParsed.jsxScript || '').trim()) {
                return { performed: true, status: 'fix_failed', summary: errText };
              }
              var nextAssets = curAssets;
              if (Array.isArray(repParsed.assets) && repParsed.assets.length > 0) {
                var written = self._writeAssetsToTemp(session.id, repParsed.assets);
                if (written.length > 0) nextAssets = written;
              }
              var nextCode = self._sanitizeES3Basic(repParsed.jsxScript);
              var nextSaved = self.storage.saveScriptFile(session.id, fixName + '_r' + attempt, nextCode, {
                hostApp: hostInfo.label,
                prompt: originalPrompt,
                status: 'stock_recheck_fix_repair_' + attempt
              });
              return runFixAttempt(attempt + 1, nextCode, nextSaved, nextAssets);
            });
          });
        }

        return runFixAttempt(1, fixScript, fixSavedInfo, fixAssets);
      });
    })['catch'](function (err) {
      if (self.api.stopRequested || (err && err.message === 'Stopped by user')) {
        throw err;
      }
      return {
        performed: true,
        status: 'skipped',
        summary: 'Recheck skipped: ' + ((err && err.message) ? err.message : String(err))
      };
    });
  };

  AgentEngine.prototype.runTurn = function (session, userMessageObj, onProgress, options) {
    var self = this;
    var opts = options || {};
    var notify = typeof onProgress === 'function' ? onProgress : function () {};

    var hostInfo = this.bridge.detectHost();
    var paths = this.storage.getStoragePaths(session.id);

    notify('Preparing workspace...');

    return this.bridge.getDocumentContext().then(function (docContext) {
      if (Array.isArray(userMessageObj.images)) {
        for (var i = 0; i < userMessageObj.images.length; i++) {
          var img = userMessageObj.images[i];
          if (!img.isAutoCanvas && !img.diskPath && img.dataUrl) {
            img.diskPath = self.storage.saveUploadedImage(session.id, img.dataUrl, img.name);
          }
        }
      }

      var systemPrompt = self._buildSystemPrompt(hostInfo, docContext, paths, userMessageObj.images || []);
      var apiMessages = self._buildApiConversation(session.messages);

      notify('Designing your request...');
      return self.api.sendAgentChat(apiMessages, systemPrompt, 0, { expectJson: true }).then(function (aiRaw) {
        var parsed = self._parseAgentJSON(aiRaw.text);

        var retryPromise;
        if (!parsed._parseOk || (parsed.action === 'execute' && !String(parsed.jsxScript || '').trim())) {
          notify('Refining result...');
          var exclude = aiRaw.modelUsed ? [aiRaw.modelUsed] : [];
          var retryMessages = apiMessages.concat([
            { role: 'user', content: 'Return ONLY a complete, valid JSON object matching the required schema (if executing, include non-empty jsxScript).' }
          ]);
          retryPromise = self.api.sendAgentChat(retryMessages, systemPrompt, 0, { expectJson: true, excludeModels: exclude })
            .then(function (retryRaw) {
              return { aiRaw: retryRaw, parsed: self._parseAgentJSON(retryRaw.text) };
            });
        } else {
          retryPromise = Promise.resolve({ aiRaw: aiRaw, parsed: parsed });
        }

        return retryPromise.then(function (bundle) {
          aiRaw = bundle.aiRaw;
          parsed = bundle.parsed;

          if (!parsed._parseOk && parsed._looksLikeJson) {
            throw new Error('Could not process your request. Please try again.');
          }
          if (parsed.action === 'execute' && !String(parsed.jsxScript || '').trim()) {
            throw new Error('Could not complete that action. Please try again.');
          }

          var assistantRecord = {
            id: 'msg_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            role: 'assistant',
            timestamp: Date.now(),
            modelUsed: aiRaw.modelUsed,
            action: parsed.action || 'chat',
            content: parsed.reply || '',
            questions: Array.isArray(parsed.questions) ? parsed.questions : [],
            planSummary: parsed.planSummary || '',
            exportMode: parsed.exportMode || 'single',
            exportCount: parsed.exportCount || 1,
            execution: null
          };

          if (parsed.action !== 'execute' || !parsed.jsxScript) {
            return assistantRecord;
          }

          var savedAssets = self._writeAssetsToTemp(session.id, parsed.assets);
          var currentScript = self._sanitizeES3Basic(parsed.jsxScript);
          var scriptName = parsed.scriptName || 'ai_command';

          var savedScriptInfo = self.storage.saveScriptFile(session.id, scriptName, currentScript, {
            hostApp: hostInfo.label,
            prompt: userMessageObj.content,
            status: hostInfo.isAdobe ? 'pending_execution' : 'preview_saved'
          });

          if (!hostInfo.isAdobe) {
            assistantRecord.execution = {
              ok: true,
              previewOnly: true,
              hostApp: hostInfo.app,
              hostLabel: hostInfo.label,
              scriptName: scriptName,
              scriptFile: savedScriptInfo.fileName,
              scriptPath: savedScriptInfo.fullPath,
              jsxScript: currentScript,
              assets: savedAssets,
              exportedFiles: [],
              message: 'Open inside Photoshop or Illustrator to apply this directly.'
            };
            return assistantRecord;
          }

          var maxAttempts = 3;

          function runAttempt(attempt) {
            notify(attempt === 1 ? ('Applying in ' + hostInfo.shortLabel + '...') : ('Finalizing in ' + hostInfo.shortLabel + '...'));
            return self.bridge.evalScriptSafe(currentScript).then(function (lastExecResult) {
              if (lastExecResult && lastExecResult.ok) {
                return lastExecResult;
              }
              if (attempt >= maxAttempts) {
                return lastExecResult;
              }

              var errText = (lastExecResult && (lastExecResult.error || lastExecResult.description)) || 'Unknown ExtendScript error';
              var repairPrompt = [
                'The ExtendScript (ES3) you generated failed inside ' + hostInfo.label + ' with this error:',
                'ERROR: ' + errText + (lastExecResult && lastExecResult.line ? ' (Line ' + lastExecResult.line + ')' : ''),
                '',
                'Fix ONLY the broken ExtendScript (strict ES3: var, function(){}, no let/const/arrow/backticks) and return the same JSON format with action="execute" and the corrected jsxScript.'
              ].join('\n');

              var repairMessages = apiMessages.concat([
                { role: 'assistant', content: JSON.stringify(parsed) },
                { role: 'user', content: repairPrompt }
              ]);

              return self.api.sendAgentChat(repairMessages, systemPrompt, 0, { expectJson: true }).then(function (repairRaw) {
                var repairParsed = self._parseAgentJSON(repairRaw.text);
                if (repairParsed && repairParsed.jsxScript) {
                  if (Array.isArray(repairParsed.assets) && repairParsed.assets.length > 0) {
                    var repairedAssets = self._writeAssetsToTemp(session.id, repairParsed.assets);
                    if (repairedAssets.length > 0) savedAssets = repairedAssets;
                  }
                  currentScript = self._sanitizeES3Basic(repairParsed.jsxScript);
                  if (repairParsed.reply) assistantRecord.content = repairParsed.reply;
                  savedScriptInfo = self.storage.saveScriptFile(session.id, scriptName + '_fix' + attempt, currentScript, {
                    hostApp: hostInfo.label,
                    prompt: userMessageObj.content,
                    status: 'auto_repaired_attempt_' + attempt
                  });
                } else {
                  return lastExecResult;
                }
                return runAttempt(attempt + 1);
              });
            });
          }

          return runAttempt(1).then(function (lastExecResult) {
            var postPromise = Promise.resolve(null);
            if (opts.recheckStock && lastExecResult && lastExecResult.ok) {
              postPromise = self._runStockRecheckOnce(
                session,
                hostInfo,
                paths,
                systemPrompt,
                userMessageObj.content,
                parsed.planSummary,
                lastExecResult,
                notify,
                opts.normalizePreviewFn
              );
            }

            return postPromise.then(function (recheckInfo) {
              var finalExec = lastExecResult;
              if (recheckInfo && recheckInfo.status === 'fixed' && recheckInfo.execResult) {
                finalExec = recheckInfo.execResult;
                if (recheckInfo.scriptCode) currentScript = recheckInfo.scriptCode;
                if (recheckInfo.savedInfo) savedScriptInfo = recheckInfo.savedInfo;
                if (Array.isArray(recheckInfo.assets) && recheckInfo.assets.length > 0) {
                  savedAssets = recheckInfo.assets;
                }
              }

              var resultData = (finalExec && finalExec.result) || {};
              var exportedFiles = [];
              if (Array.isArray(resultData.exportedFiles)) {
                exportedFiles = resultData.exportedFiles;
              } else if (resultData.files && Array.isArray(resultData.files)) {
                exportedFiles = resultData.files;
              } else {
                var initResData = (lastExecResult && lastExecResult.result) || {};
                if (Array.isArray(initResData.exportedFiles)) exportedFiles = initResData.exportedFiles;
                else if (initResData.files && Array.isArray(initResData.files)) exportedFiles = initResData.files;
              }

              assistantRecord.execution = {
                ok: !!(finalExec && finalExec.ok),
                previewOnly: false,
                hostApp: hostInfo.app,
                hostLabel: hostInfo.label,
                scriptName: scriptName,
                scriptFile: savedScriptInfo.fileName,
                scriptPath: savedScriptInfo.fullPath,
                jsxScript: currentScript,
                assets: savedAssets,
                exportedFiles: exportedFiles,
                exportsDir: paths.exportsDir,
                details: resultData,
                error: (finalExec && !finalExec.ok) ? (finalExec.error || 'Execution failed') : '',
                recheck: recheckInfo ? {
                  performed: !!recheckInfo.performed,
                  status: recheckInfo.status || 'passed',
                  summary: recheckInfo.summary || ''
                } : null
              };

              return assistantRecord;
            });
          });
        });
      });
    });
  };

  NS.AgentEngine = AgentEngine;
})(window);
