(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  function getNodeRequire() {
    try {
      if (global.cep_node && typeof global.cep_node.require === 'function') {
        return global.cep_node.require;
      }
      if (typeof global.require === 'function') {
        return global.require;
      }
    } catch (e) {}
    return null;
  }

  var nodeRequire = getNodeRequire();
  var fs = nodeRequire ? safeRequire('fs') : null;
  var path = nodeRequire ? safeRequire('path') : null;
  var os = nodeRequire ? safeRequire('os') : null;
  var http = nodeRequire ? safeRequire('http') : null;
  var https = nodeRequire ? safeRequire('https') : null;
  var urlMod = nodeRequire ? safeRequire('url') : null;
  var childProcess = nodeRequire ? safeRequire('child_process') : null;

  function safeRequire(mod) {
    try {
      return nodeRequire(mod);
    } catch (e) {
      return null;
    }
  }

  function hasCEP() {
    return typeof global.__adobe_cep__ !== 'undefined' && global.__adobe_cep__ !== null;
  }

  function getHostEnvironment() {
    if (!hasCEP()) return null;
    try {
      var raw = global.__adobe_cep__.getHostEnvironment();
      return typeof raw === 'string' ? JSON.parse(raw) : raw;
    } catch (e) {
      return null;
    }
  }

  function mapPhotoshopYear(major, ver) {
    var map = {
      16: 'CC 2015',
      17: 'CC 2015.5',
      18: 'CC 2017',
      19: 'CC 2018',
      20: 'CC 2019',
      21: '2020',
      22: '2021',
      23: '2022',
      24: '2023',
      25: '2024',
      26: '2025',
      27: '2026'
    };
    if (major >= 27) return String(2026 + (major - 27));
    return map[major] || ver || 'CC';
  }

  function mapIllustratorYear(major, ver) {
    var map = {
      19: 'CC 2015',
      20: 'CC 2015.3',
      21: 'CC 2017',
      22: 'CC 2018',
      23: 'CC 2019',
      24: '2020',
      25: '2021',
      26: '2022',
      27: '2023',
      28: '2024',
      29: '2025',
      30: '2026'
    };
    if (major >= 30) return String(2026 + (major - 30));
    return map[major] || ver || 'CC';
  }

  function detectHost() {
    var env = getHostEnvironment();
    if (!env || !env.appId) {
      return {
        isAdobe: false,
        app: 'browser',
        appId: 'BROWSER',
        appVersion: '',
        label: 'Browser Preview',
        shortLabel: 'Preview'
      };
    }

    var id = String(env.appId).toUpperCase();
    var ver = String(env.appVersion || '');
    var major = parseInt(ver.split('.')[0], 10) || 0;

    if (id === 'PHXS' || id === 'PHSP') {
      var psYear = mapPhotoshopYear(major, ver);
      return {
        isAdobe: true,
        app: 'photoshop',
        appId: id,
        appVersion: ver,
        label: 'Photoshop ' + psYear,
        shortLabel: 'Photoshop'
      };
    }

    if (id === 'ILST') {
      var aiYear = mapIllustratorYear(major, ver);
      return {
        isAdobe: true,
        app: 'illustrator',
        appId: id,
        appVersion: ver,
        label: 'Illustrator ' + aiYear,
        shortLabel: 'Illustrator'
      };
    }

    if (id === 'AEFT') {
      return {
        isAdobe: true,
        app: 'aftereffects',
        appId: id,
        appVersion: ver,
        label: 'After Effects ' + ver,
        shortLabel: 'After Effects'
      };
    }

    return {
      isAdobe: true,
      app: 'unknown',
      appId: id,
      appVersion: ver,
      label: id + ' ' + ver,
      shortLabel: id
    };
  }

  function getExtensionRoot() {
    if (hasCEP()) {
      try {
        var sysPath = decodeURI(global.__adobe_cep__.getSystemPath('extension'));
        if (navigator.appVersion.toLowerCase().indexOf('windows') >= 0) {
          sysPath = sysPath.replace(/^file:\/\/\//i, '');
        } else {
          sysPath = sysPath.replace(/^file:\/\//i, '');
        }
        if (fs && fs.existsSync(sysPath)) {
          return sysPath;
        }
      } catch (e) {}
    }
    if (typeof __dirname !== 'undefined' && path) {
      return path.resolve(__dirname, '..');
    }
    return '';
  }

  function evalRaw(script) {
    return new Promise(function (resolve, reject) {
      if (!hasCEP()) {
        reject(new Error('Not running inside Adobe Photoshop or Illustrator.'));
        return;
      }
      try {
        global.__adobe_cep__.evalScript(script, function (res) {
          if (res === 'EvalScript error.') {
            reject(new Error('ExtendScript evaluation failed (EvalScript error).'));
          } else {
            resolve(res);
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  function xhrReadText(url) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
          if ((xhr.status >= 200 && xhr.status < 300) || (xhr.status === 0 && xhr.responseText)) {
            resolve(xhr.responseText);
          } else {
            reject(new Error('Failed to load ' + url + ' (' + xhr.status + ')'));
          }
        }
      };
      xhr.onerror = function () {
        reject(new Error('Network error loading ' + url));
      };
      xhr.send();
    });
  }

  function ensureHostHelpersLoaded() {
    if (!hasCEP()) return Promise.resolve(false);
    return evalRaw('(typeof __AI_HELPERS_LOADED !== "undefined" && typeof __AI_HELPERS_VERSION !== "undefined" && __AI_HELPERS_VERSION >= 5) ? "yes" : "no"')
      .catch(function () { return 'no'; })
      .then(function (check) {
        if (check === 'yes') return true;

        var hostScriptText = '';
        var root = getExtensionRoot();
        if (fs && path && root) {
          var jsxPath = path.join(root, 'jsx', 'hostscript.jsx');
          if (fs.existsSync(jsxPath)) {
            hostScriptText = fs.readFileSync(jsxPath, 'utf8');
          }
        }

        if (hostScriptText) {
          return evalRaw(hostScriptText).then(function () { return true; });
        }

        return xhrReadText('./jsx/hostscript.jsx').then(function (txt) {
          return evalRaw(txt).then(function () { return true; });
        });
      });
  }

  function evalScriptSafe(jsxCode) {
    return ensureHostHelpersLoaded().then(function () {
      var wrapped = '__AI_AGENT_SAFE_EVAL(' + JSON.stringify(String(jsxCode || '')) + ')';
      return evalRaw(wrapped).then(function (raw) {
        try {
          return JSON.parse(raw);
        } catch (e) {
          return {
            ok: true,
            raw: raw,
            result: { message: raw }
          };
        }
      });
    });
  }

  function getDocumentContext() {
    if (!hasCEP()) {
      return Promise.resolve({
        ok: true,
        hostApp: 'browser',
        hasOpenDoc: false,
        docsCount: 0,
        note: 'Standalone Browser Preview (open inside Photoshop or Illustrator CC 2015–2026 for live execution).'
      });
    }
    return ensureHostHelpersLoaded().then(function () {
      return evalRaw('__AI_AGENT_GET_CONTEXT()').then(function (raw) {
        try {
          return JSON.parse(raw);
        } catch (e) {
          return { ok: false, error: 'Failed to parse document context', raw: raw };
        }
      });
    });
  }

  function ensureDirRecursive(dirPath) {
    if (!fs || !path || !dirPath) return;
    if (fs.existsSync(dirPath)) return;
    var parent = path.dirname(dirPath);
    if (parent && parent !== dirPath) {
      ensureDirRecursive(parent);
    }
    try {
      fs.mkdirSync(dirPath);
    } catch (e) {}
  }

  function captureActivePreview(tempDir) {
    if (!hasCEP() || !fs || !path) {
      return Promise.resolve(null);
    }
    var host = detectHost();
    if (host.app !== 'photoshop' && host.app !== 'illustrator') {
      return Promise.resolve(null);
    }

    var baseDir = tempDir || (os && typeof os.tmpdir === 'function' ? os.tmpdir() : '');
    if (!baseDir) return Promise.resolve(null);
    ensureDirRecursive(baseDir);

    var ext = host.app === 'photoshop' ? '.jpg' : '.png';
    var outPath = path.join(baseDir, 'live_canvas_' + Date.now() + ext).replace(/\\/g, '/');

    return ensureHostHelpersLoaded().then(function () {
      return evalRaw('__AI_AGENT_CAPTURE_PREVIEW(' + JSON.stringify(outPath) + ')');
    }).then(function (raw) {
      var parsed = null;
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        return null;
      }
      if (!parsed || !parsed.ok || !parsed.filePath) {
        return null;
      }

      var actualPath = parsed.filePath;
      var dataUrl = '';
      try {
        var buf = fs.readFileSync(actualPath);
        var mime = parsed.mimeType || (ext === '.png' ? 'image/png' : 'image/jpeg');
        dataUrl = 'data:' + mime + ';base64,' + buf.toString('base64');
      } catch (eRead) {
        dataUrl = '';
      } finally {
        try {
          if (fs.existsSync(actualPath)) fs.unlinkSync(actualPath);
        } catch (eDel) {}
      }

      if (!dataUrl) return null;
      return {
        name: 'Canvas: ' + (parsed.docName || 'Open Project'),
        docName: parsed.docName || 'Open Project',
        dataUrl: dataUrl,
        width: parsed.width || 0,
        height: parsed.height || 0,
        hostApp: parsed.hostApp || host.app,
        isAutoCanvas: true
      };
    })['catch'](function () {
      try {
        if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
      } catch (eDel2) {}
      return null;
    });
  }

  function openURL(url) {
    if (childProcess) {
      try {
        var isWin = navigator.platform.toLowerCase().indexOf('win') >= 0;
        var cmd = isWin ? 'start "" "' + url + '"' : 'open "' + url + '"';
        childProcess.exec(cmd);
        return;
      } catch (e) {}
    }
    if (hasCEP() && global.cep && global.cep.util && typeof global.cep.util.openURLInDefaultBrowser === 'function') {
      try {
        global.cep.util.openURLInDefaultBrowser(url);
        return;
      } catch (e2) {}
    }
    global.open(url, '_blank');
  }

  function openFolderInExplorer(targetPath) {
    if (!targetPath) return false;
    if (childProcess) {
      try {
        var clean = String(targetPath).replace(/\//g, '\\');
        var isWin = navigator.platform.toLowerCase().indexOf('win') >= 0;
        if (isWin) {
          if (fs && fs.existsSync(clean) && fs.statSync(clean).isFile()) {
            childProcess.exec('explorer.exe /select,"' + clean + '"');
          } else {
            childProcess.exec('explorer.exe "' + clean + '"');
          }
        } else {
          childProcess.exec('open "' + targetPath + '"');
        }
        return true;
      } catch (e) {}
    }
    return false;
  }

  function nodeHttpsRequest(url, options, bodyStr) {
    return new Promise(function (resolve, reject) {
      if (!https && !http) {
        reject(new Error('Node http/https module not available'));
        return;
      }
      try {
        var parsed = urlMod ? urlMod.parse(url) : null;
        var isHttps = parsed ? (parsed.protocol === 'https:') : /^https:/i.test(url);
        var transport = isHttps ? https : http;
        if (!transport) {
          reject(new Error('Transport unavailable for URL: ' + url));
          return;
        }

        var reqOpts = parsed ? {
          protocol: parsed.protocol,
          hostname: parsed.hostname,
          port: parsed.port || (isHttps ? 443 : 80),
          path: parsed.path,
          method: (options && options.method) || 'GET',
          headers: (options && options.headers) || {}
        } : url;

        var req = transport.request(reqOpts, function (res) {
          var chunks = [];
          res.on('data', function (chunk) { chunks.push(chunk); });
          res.on('end', function () {
            var text = Buffer.concat(chunks).toString('utf8');
            resolve({
              ok: res.statusCode >= 200 && res.statusCode < 300,
              status: res.statusCode,
              text: function () { return Promise.resolve(text); },
              json: function () { return Promise.resolve(JSON.parse(text)); }
            });
          });
        });

        req.on('error', function (err) {
          reject(err);
        });

        if (options && options.signal) {
          if (options.signal.aborted) {
            if (typeof req.destroy === 'function') req.destroy(new Error('Aborted'));
            else req.abort();
            return;
          }
          options.signal.addEventListener('abort', function () {
            if (typeof req.destroy === 'function') req.destroy(new Error('Aborted'));
            else req.abort();
          });
        }

        if (bodyStr) {
          req.write(bodyStr);
        }
        req.end();
      } catch (err) {
        reject(err);
      }
    });
  }

  function fitPanelToScreen(force) {
    if (!hasCEP()) return false;
    try {
      var cep = global.__adobe_cep__;
      if (!cep || typeof cep.resizeContent !== 'function') return false;

      var scr = global.screen || {};
      var availW = Number(scr.availWidth || global.innerWidth || 1280);
      var availH = Number(scr.availHeight || global.innerHeight || 720);
      var availTop = Number(scr.availTop || 0);
      var curW = Number(global.innerWidth || 400);
      var curH = Number(global.innerHeight || 540);
      var outH = Number(global.outerHeight || curH);
      var winTop = Number(typeof global.screenY === 'number' ? global.screenY : (global.screenTop || 0));

      var overflowsBottom = (winTop + outH) > (availTop + availH - 8);
      var tooTall = outH > (availH - 36);
      var tooWide = curW > Math.floor(availW * 0.85);

      if (!force && !overflowsBottom && !tooTall && !tooWide) {
        return false;
      }

      var maxFitH = Math.max(320, Math.floor(availH * 0.78));
      var maxFitW = Math.max(300, Math.min(440, Math.floor(availW * 0.42)));
      var targetH = force ? Math.min(540, maxFitH) : Math.min(curH, maxFitH);
      var targetW = force ? Math.min(400, maxFitW) : Math.min(curW, maxFitW);

      targetW = Math.max(280, Math.round(targetW));
      targetH = Math.max(300, Math.round(targetH));

      if (force || targetH < curH || targetW < curW) {
        cep.resizeContent(targetW, targetH);
        return true;
      }
    } catch (e) {}
    return false;
  }

  function showDesktopNotification(title, body, isError) {
    var cleanTitle = String(title || 'Adobe AI Agent').replace(/[\r\n]+/g, ' ').trim().slice(0, 64);
    var cleanBody = String(body || 'Your task is complete.').replace(/[\r\n]+/g, ' ').trim().slice(0, 220);

    if (hasCEP() && childProcess && typeof childProcess.execFile === 'function') {
      try {
        var plat = String(navigator.platform || '').toLowerCase();
        if (plat.indexOf('win') >= 0) {
          var baseEnv = (typeof process !== 'undefined' && process && process.env) ? process.env : {};
          var env = Object.assign({}, baseEnv, {
            AI_NOTIFY_TITLE: cleanTitle,
            AI_NOTIFY_BODY: cleanBody,
            AI_NOTIFY_ICON: isError ? 'Warning' : 'Info'
          });
          var psCmd = [
            'Add-Type -AssemblyName System.Windows.Forms;',
            'Add-Type -AssemblyName System.Drawing;',
            '$n = New-Object System.Windows.Forms.NotifyIcon;',
            '$n.Icon = [System.Drawing.SystemIcons]::Information;',
            'if ($env:AI_NOTIFY_ICON -eq "Warning") { $n.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Warning } else { $n.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info };',
            '$n.BalloonTipTitle = $env:AI_NOTIFY_TITLE;',
            '$n.BalloonTipText = $env:AI_NOTIFY_BODY;',
            '$n.Visible = $true;',
            '$n.ShowBalloonTip(5000);',
            'Start-Sleep -Seconds 6;',
            '$n.Dispose()'
          ].join(' ');
          childProcess.execFile(
            'powershell.exe',
            ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psCmd],
            { env: env, windowsHide: true },
            function () {}
          );
          return true;
        }
        if (plat.indexOf('mac') >= 0) {
          childProcess.execFile(
            'osascript',
            ['-e', 'on run argv\ndisplay notification (item 2 of argv) with title (item 1 of argv)\nend run', cleanTitle, cleanBody],
            function () {}
          );
          return true;
        }
      } catch (e) {}
    }

    if (typeof global.Notification === 'function') {
      try {
        if (global.Notification.permission === 'granted') {
          new global.Notification(cleanTitle, { body: cleanBody });
          return true;
        }
      } catch (e2) {}
    }
    return false;
  }

  function naturalSortNames(a, b) {
    var sa = String(a || '').toLowerCase();
    var sb = String(b || '').toLowerCase();
    var pa = sa.match(/(\d+|\D+)/g) || [sa];
    var pb = sb.match(/(\d+|\D+)/g) || [sb];
    var len = Math.min(pa.length, pb.length);
    for (var i = 0; i < len; i++) {
      var xa = pa[i];
      var xb = pb[i];
      var na = /^\d+$/.test(xa) ? parseInt(xa, 10) : NaN;
      var nb = /^\d+$/.test(xb) ? parseInt(xb, 10) : NaN;
      if (!isNaN(na) && !isNaN(nb)) {
        if (na !== nb) return na - nb;
      } else if (xa !== xb) {
        return xa < xb ? -1 : 1;
      }
    }
    return pa.length - pb.length;
  }

  function listSvgFilesInFolder(folderPath) {
    if (!fs || !path) {
      return { ok: false, error: 'Local filesystem access requires running inside Adobe CEP.', files: [] };
    }
    var raw = String(folderPath || '').trim().replace(/^["']+|["']+$/g, '');
    if (!raw) {
      return { ok: false, error: 'Please enter or select a folder path.', files: [] };
    }
    try {
      if (!fs.existsSync(raw) || !fs.statSync(raw).isDirectory()) {
        return { ok: false, error: 'Folder not found: ' + raw, files: [] };
      }
      var entries = fs.readdirSync(raw);
      var svgs = [];
      for (var i = 0; i < entries.length; i++) {
        var name = entries[i];
        if (!/\.svg$/i.test(name)) continue;
        var full = path.join(raw, name);
        try {
          if (fs.statSync(full).isFile()) {
            svgs.push({
              name: name,
              path: full.replace(/\\/g, '/')
            });
          }
        } catch (eStat) {}
      }
      svgs.sort(function (a, b) { return naturalSortNames(a.name, b.name); });
      return {
        ok: true,
        folderPath: raw.replace(/\\/g, '/'),
        files: svgs
      };
    } catch (err) {
      return { ok: false, error: (err && err.message) ? err.message : 'Failed to scan folder.', files: [] };
    }
  }

  function browseFolderDialog(title, initialDir) {
    return new Promise(function (resolve) {
      var promptTitle = String(title || 'Select Folder');
      if (hasCEP() && global.cep && global.cep.fs && typeof global.cep.fs.showOpenDialog === 'function') {
        try {
          var res = global.cep.fs.showOpenDialog(false, true, promptTitle, initialDir || '', []);
          if (res && res.err === 0 && Array.isArray(res.data) && res.data.length > 0 && res.data[0]) {
            resolve(String(res.data[0]).replace(/\\/g, '/'));
            return;
          }
          if (res && res.err === 0) {
            resolve('');
            return;
          }
        } catch (eCep) {}
      }

      if (childProcess && typeof childProcess.execFile === 'function') {
        var plat = String(navigator.platform || '').toLowerCase();
        if (plat.indexOf('win') >= 0) {
          var psScript = [
            'Add-Type -AssemblyName System.Windows.Forms;',
            '$d = New-Object System.Windows.Forms.FolderBrowserDialog;',
            '$d.Description = $env:AI_FOLDER_TITLE;',
            'if ($env:AI_FOLDER_INIT -and (Test-Path -LiteralPath $env:AI_FOLDER_INIT)) { $d.SelectedPath = $env:AI_FOLDER_INIT };',
            '$r = $d.ShowDialog();',
            'if ($r -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }'
          ].join(' ');
          var baseEnv = (typeof process !== 'undefined' && process && process.env) ? process.env : {};
          var env = Object.assign({}, baseEnv, {
            AI_FOLDER_TITLE: promptTitle,
            AI_FOLDER_INIT: String(initialDir || '').replace(/\//g, '\\')
          });
          childProcess.execFile(
            'powershell.exe',
            ['-NoProfile', '-STA', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psScript],
            { env: env, windowsHide: true },
            function (err, stdout) {
              var picked = (!err && stdout) ? String(stdout).trim() : '';
              resolve(picked ? picked.replace(/\\/g, '/') : '');
            }
          );
          return;
        }
        if (plat.indexOf('mac') >= 0) {
          childProcess.execFile(
            'osascript',
            ['-e', 'POSIX path of (choose folder with prompt "' + promptTitle.replace(/"/g, '\\"') + '")'],
            function (err, stdout) {
              var picked = (!err && stdout) ? String(stdout).trim() : '';
              resolve(picked);
            }
          );
          return;
        }
      }

      resolve('');
    });
  }

  NS.CepBridge = {
    hasCEP: hasCEP,
    hasNodeFS: function () { return !!(fs && path); },
    fs: fs,
    path: path,
    os: os,
    detectHost: detectHost,
    fitPanelToScreen: fitPanelToScreen,
    showDesktopNotification: showDesktopNotification,
    getExtensionRoot: getExtensionRoot,
    evalRaw: evalRaw,
    ensureHostHelpersLoaded: ensureHostHelpersLoaded,
    evalScriptSafe: evalScriptSafe,
    getDocumentContext: getDocumentContext,
    captureActivePreview: captureActivePreview,
    openURL: openURL,
    openFolderInExplorer: openFolderInExplorer,
    listSvgFilesInFolder: listSvgFilesInFolder,
    browseFolderDialog: browseFolderDialog,
    nodeHttpsRequest: nodeHttpsRequest
  };
})(window);
