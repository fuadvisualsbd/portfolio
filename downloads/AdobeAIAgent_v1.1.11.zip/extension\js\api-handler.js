(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  var DEFAULT_GEMINI_MODELS = [
    { id: 'antigravity-preview-09-2026', name: 'Antigravity Agent (Interactions API)', rpm: 60, rpd: 100, enabled: true, kind: 'agent' },
    { id: 'gemini-4-hydrogen', name: 'Gemini 4 Hydrogen', rpm: 5, rpd: 20, enabled: true, kind: 'model' },
    { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash Lite', rpm: 15, rpd: 500, enabled: true, kind: 'model' },
    { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', rpm: 5, rpd: 20, enabled: true, kind: 'model' },
    { id: 'gemini-3.6-flash', name: 'Gemini 3.6 Flash', rpm: 5, rpd: 20, enabled: true, kind: 'model' },
    { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', rpm: 15, rpd: 500, enabled: true, kind: 'model' },
    { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', rpm: 5, rpd: 20, enabled: false, kind: 'model' },
    { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash', rpm: 5, rpd: 20, enabled: false, kind: 'model' },
    { id: 'gemini-2.5-flash-lite-preview-09-2025', name: 'Gemini 2.5 Flash Lite', rpm: 10, rpd: 20, enabled: false, kind: 'model' }
  ];

  var MODEL_FALLBACK_CANDIDATES = {
    'gemini-4-hydrogen': ['gemini-4-hydrogen', 'gemini-4-hydrogen-preview'],
    'gemini-3-flash': ['gemini-3-flash-preview', 'gemini-3-flash', 'gemini-3.0-flash-preview'],
    'gemini-3-flash-preview': ['gemini-3-flash-preview', 'gemini-3-flash', 'gemini-3.0-flash-preview'],
    'gemini-2.5-flash-lite': ['gemini-2.5-flash-lite-preview-09-2025', 'gemini-2.5-flash-lite-preview', 'gemini-2.5-flash-lite'],
    'gemini-2.5-flash-lite-preview-09-2025': ['gemini-2.5-flash-lite-preview-09-2025', 'gemini-2.5-flash-lite-preview', 'gemini-2.5-flash-lite'],
    'gemini-3.8-flash': ['gemini-3.8-flash', 'gemini-3.8-flash-preview'],
    'gemini-3.6-flash': ['gemini-3.6-flash', 'gemini-3.6-flash-preview'],
    'gemini-3.5-flash-lite': ['gemini-3.5-flash-lite', 'gemini-3.5-flash-lite-preview'],
    'gemini-3.1-flash-lite': ['gemini-3.1-flash-lite', 'gemini-3.1-flash-lite-preview'],
    'gemini-2.5-flash': ['gemini-2.5-flash'],
    'antigravity-preview-09-2026': ['antigravity-preview-09-2026', 'antigravity'],
    'antigravity': ['antigravity-preview-09-2026', 'antigravity']
  };

  function findInList(arr, predicate) {
    if (!Array.isArray(arr)) return null;
    for (var i = 0; i < arr.length; i++) {
      if (predicate(arr[i], i)) return arr[i];
    }
    return null;
  }

  function ApiHandler(storageManager, authClient) {
    this.storage = storageManager;
    this.auth = authClient || null;
    this.bridge = NS.CepBridge;
    this.stopRequested = false;
    this._activeXhr = null;
    this._activeAbortFn = null;
    this.userGrade = 3;
    this.currentTurnToken = '';

    this.keys = [];
    this.activeKeyIndex = 0;
    this.mode = 'auto'; // 'auto' | 'manual'
    this.selectedKeyIndex = 0;
    this.geminiModels = JSON.parse(JSON.stringify(DEFAULT_GEMINI_MODELS));
    this.modelMode = 'auto'; // 'auto' | 'single'
    this.selectedModel = 'antigravity-preview-09-2026';
    this.antigravityDefaultPromoted = false;
    this.modelUsage = {};
    this.usageStats = { callsMade: 0, errorsCount: 0, activeKeyIndex: 0 };

    this._loadState();
  }

  ApiHandler.prototype.setAuthClient = function (authClient) {
    this.auth = authClient;
  };

  ApiHandler.prototype.setUserGrade = function (grade) {
    this.userGrade = Number(grade || 3);
  };

  ApiHandler.prototype.setTurnToken = function (token) {
    this.currentTurnToken = token || '';
  };

  ApiHandler.prototype._promoteAntigravityFirst = function () {
    var idx = -1;
    for (var i = 0; i < this.geminiModels.length; i++) {
      if (this.geminiModels[i] && this.geminiModels[i].id === 'antigravity-preview-09-2026') {
        idx = i;
        break;
      }
    }
    var item;
    if (idx >= 0) {
      item = this.geminiModels.splice(idx, 1)[0];
      item.enabled = true;
    } else {
      item = JSON.parse(JSON.stringify(DEFAULT_GEMINI_MODELS[0]));
      item.enabled = true;
    }
    this.geminiModels.unshift(item);
  };

  ApiHandler.prototype._loadState = function () {
    var cfg = this.storage ? this.storage.loadConfig() : null;
    if (cfg && typeof cfg === 'object') {
      if (Array.isArray(cfg.keys)) this.keys = this._sanitizeKeys(cfg.keys);
      this.mode = cfg.mode === 'manual' ? 'manual' : 'auto';
      this.selectedKeyIndex = parseInt(cfg.selectedKeyIndex || 0, 10) || 0;
      this.modelMode = cfg.modelMode === 'single' ? 'single' : 'auto';
      this.selectedModel = cfg.selectedModel || 'antigravity-preview-09-2026';
      this.antigravityDefaultPromoted = !!cfg.antigravityDefaultPromoted;
      if (Array.isArray(cfg.geminiModels) && cfg.geminiModels.length > 0) {
        this.geminiModels = this._mergeModels(cfg.geminiModels);
      }
      if (cfg.modelUsage && typeof cfg.modelUsage === 'object') {
        this.modelUsage = cfg.modelUsage;
      }
      if (!this.antigravityDefaultPromoted) {
        this._promoteAntigravityFirst();
        this.antigravityDefaultPromoted = true;
        this._saveState();
      }
      return;
    }

    try {
      var rawKeys = global.localStorage.getItem('gemini_api_keys');
      if (rawKeys) {
        this.keys = this._sanitizeKeys(JSON.parse(rawKeys));
      }
      this.mode = global.localStorage.getItem('gemini_api_mode') || 'auto';
      this.selectedKeyIndex = parseInt(global.localStorage.getItem('gemini_api_selected_index') || '0', 10) || 0;
      this.modelMode = global.localStorage.getItem('gemini_model_mode') || 'auto';
      this.selectedModel = global.localStorage.getItem('gemini_selected_model') || 'antigravity-preview-09-2026';
      var savedModels = global.localStorage.getItem('gemini_model_config');
      if (savedModels) {
        this.geminiModels = this._mergeModels(JSON.parse(savedModels));
      }
      if (!this.antigravityDefaultPromoted) {
        this._promoteAntigravityFirst();
        this.antigravityDefaultPromoted = true;
      }
    } catch (e) {}
  };

  ApiHandler.prototype._saveState = function () {
    var cfg = {
      keys: this.keys,
      mode: this.mode,
      selectedKeyIndex: this.selectedKeyIndex,
      modelMode: this.modelMode,
      selectedModel: this.selectedModel,
      antigravityDefaultPromoted: true,
      geminiModels: this.geminiModels,
      modelUsage: this.modelUsage
    };
    if (this.storage) {
      this.storage.saveConfig(cfg);
    }
  };

  ApiHandler.prototype._sanitizeKeys = function (list) {
    var out = [];
    if (!Array.isArray(list)) return out;
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      var key = typeof item === 'string' ? item : (item && item.key);
      var provider = (typeof item === 'object' && item && item.provider) ? item.provider : 'gemini';
      if (typeof key === 'string') {
        key = key.trim().replace(/^['"`]+|['"`]+$/g, '');
        if (key.length >= 10 && !/\s/.test(key)) {
          if (!out.some(function (k) { return k.key === key; })) {
            out.push({ key: key, provider: provider });
          }
        }
      }
    }
    return out;
  };

  ApiHandler.prototype._mergeModels = function (savedList) {
    var merged = [];
    var idMap = {
      'gemini-3-flash': 'gemini-3-flash-preview',
      'gemini-2.5-flash-lite': 'gemini-2.5-flash-lite-preview-09-2025'
    };
    for (var i = 0; i < savedList.length; i++) {
      var item = savedList[i];
      var mappedId = idMap[item.id] || item.id;
      var def = findInList(DEFAULT_GEMINI_MODELS, function (d) { return d.id === mappedId; });
      if (def) {
        merged.push({
          id: def.id,
          name: def.name,
          rpm: def.rpm,
          rpd: def.rpd,
          enabled: item.enabled !== undefined ? !!item.enabled : def.enabled,
          kind: def.kind || 'model'
        });
      }
    }
    for (var j = 0; j < DEFAULT_GEMINI_MODELS.length; j++) {
      var d2 = DEFAULT_GEMINI_MODELS[j];
      if (!merged.some(function (m) { return m.id === d2.id; })) {
        if (d2.id === 'antigravity-preview-09-2026') {
          merged.unshift(JSON.parse(JSON.stringify(d2)));
        } else {
          merged.push(JSON.parse(JSON.stringify(d2)));
        }
      }
    }
    return merged;
  };

  ApiHandler.prototype._resolveModelEndpoint = function (modelId) {
    var map = {
      'gemini-3-flash': 'gemini-3-flash-preview',
      'gemini-2.5-flash-lite': 'gemini-2.5-flash-lite-preview-09-2025'
    };
    return map[modelId] || modelId;
  };

  ApiHandler.prototype._isAgentModel = function (modelId) {
    var found = findInList(this.geminiModels, function (m) { return m.id === modelId; });
    if (found && found.kind === 'agent') return true;
    return String(modelId || '').indexOf('antigravity') === 0;
  };

  // ───────── Key & Model Management ─────────

  ApiHandler.prototype.addKey = function (keyStr, provider) {
    if (!keyStr) return 0;
    var wasEmpty = this.keys.length === 0;
    var parts = String(keyStr).split(/[\n,;]+/);
    var added = 0;
    var prov = provider || 'gemini';
    for (var i = 0; i < parts.length; i++) {
      var trimmed = parts[i].trim().replace(/^['"`]+|['"`]+$/g, '');
      if (trimmed.length >= 10 && !/\s/.test(trimmed)) {
        var exists = this.keys.some(function (k) { return k.key === trimmed; });
        if (!exists) {
          this.keys.push({ key: trimmed, provider: prov });
          added++;
        }
      }
    }
    if (added > 0) {
      if (wasEmpty && prov === 'gemini') {
        this._promoteAntigravityFirst();
        this.antigravityDefaultPromoted = true;
      }
      this._saveState();
    }
    return added;
  };

  ApiHandler.prototype.removeKey = function (index) {
    if (index >= 0 && index < this.keys.length) {
      this.keys.splice(index, 1);
      if (this.activeKeyIndex >= this.keys.length) this.activeKeyIndex = 0;
      if (this.selectedKeyIndex >= this.keys.length) {
        this.selectedKeyIndex = Math.max(0, this.keys.length - 1);
      }
      this._saveState();
    }
  };

  ApiHandler.prototype.setMode = function (mode) {
    this.mode = mode === 'manual' ? 'manual' : 'auto';
    this._saveState();
  };

  ApiHandler.prototype.selectKey = function (index) {
    if (index >= 0 && index < this.keys.length) {
      this.selectedKeyIndex = index;
      this.mode = 'manual';
      this._saveState();
    }
  };

  ApiHandler.prototype.getActiveKeyObj = function () {
    if (this.keys.length === 0) return null;
    if (this.mode === 'manual') {
      if (this.selectedKeyIndex >= 0 && this.selectedKeyIndex < this.keys.length) {
        return this.keys[this.selectedKeyIndex];
      }
      this.selectedKeyIndex = 0;
      return this.keys[0];
    }
    if (this.activeKeyIndex >= this.keys.length) this.activeKeyIndex = 0;
    return this.keys[this.activeKeyIndex];
  };

  ApiHandler.prototype.rotateKey = function () {
    if (this.keys.length > 0) {
      this.activeKeyIndex = (this.activeKeyIndex + 1) % this.keys.length;
      this.usageStats.activeKeyIndex = this.activeKeyIndex;
    }
  };

  ApiHandler.prototype.setModelMode = function (mode) {
    this.modelMode = mode === 'single' ? 'single' : 'auto';
    this._saveState();
  };

  ApiHandler.prototype.setSelectedModel = function (modelId) {
    this.selectedModel = modelId;
    this.modelMode = 'single';
    this._saveState();
  };

  ApiHandler.prototype.reorderGeminiModels = function (fromIndex, toIndex) {
    if (
      fromIndex >= 0 && fromIndex < this.geminiModels.length &&
      toIndex >= 0 && toIndex < this.geminiModels.length
    ) {
      var moved = this.geminiModels.splice(fromIndex, 1)[0];
      this.geminiModels.splice(toIndex, 0, moved);
      this._saveState();
    }
  };

  ApiHandler.prototype.toggleModelEnabled = function (modelId, enabled) {
    var m = findInList(this.geminiModels, function (x) { return x.id === modelId; });
    if (m) {
      m.enabled = !!enabled;
      this._saveState();
    }
  };

  ApiHandler.prototype.resetGeminiModels = function () {
    this.geminiModels = JSON.parse(JSON.stringify(DEFAULT_GEMINI_MODELS));
    this.modelMode = 'auto';
    this.selectedModel = 'antigravity-preview-09-2026';
    this.antigravityDefaultPromoted = true;
    this._saveState();
  };

  ApiHandler.prototype.getActiveGeminiModels = function () {
    var self = this;
    // 3rd Grade users do not have model selection or priority order customization
    if (Number(this.userGrade) === 3) {
      return DEFAULT_GEMINI_MODELS
        .filter(function (m) { return m.enabled !== false; })
        .map(function (m) { return m.id; });
    }
    if (this.modelMode === 'single') {
      var m =
        findInList(this.geminiModels, function (x) { return x.id === self.selectedModel && x.enabled; }) ||
        findInList(this.geminiModels, function (x) { return x.id === self.selectedModel; }) ||
        this.geminiModels[0];
      return [m.id];
    }
    var enabled = this.geminiModels.filter(function (m) { return m.enabled !== false; }).map(function (m) { return m.id; });
    return enabled.length > 0 ? enabled : this.geminiModels.map(function (m) { return m.id; });
  };

  // ───────── HTTP Transport (ES5 XHR + Node HTTPS fallback for Adobe CC 2015-2026) ─────────

  ApiHandler.prototype._httpRequest = function (method, url, headers, bodyStr, timeoutMs) {
    var self = this;
    var waitMs = timeoutMs || 90000;

    return new Promise(function (resolve, reject) {
      if (self.stopRequested) {
        var abortErr = new Error('Stopped by user');
        abortErr.name = 'AbortError';
        reject(abortErr);
        return;
      }

      var xhr = new XMLHttpRequest();
      self._activeXhr = xhr;
      var settled = false;

      self._activeAbortFn = function () {
        if (!settled) {
          settled = true;
          try { xhr.abort(); } catch (e) {}
          var eAb = new Error('Stopped by user');
          eAb.name = 'AbortError';
          reject(eAb);
        }
      };

      xhr.open(method, url, true);
      if (headers) {
        for (var h in headers) {
          if (Object.prototype.hasOwnProperty.call(headers, h)) {
            xhr.setRequestHeader(h, headers[h]);
          }
        }
      }
      xhr.timeout = waitMs;

      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && !settled) {
          if (xhr.status === 0) return; // handled by onerror/ontimeout
          settled = true;
          self._activeXhr = null;
          self._activeAbortFn = null;
          var txt = xhr.responseText || '';
          resolve({
            ok: xhr.status >= 200 && xhr.status < 300,
            status: xhr.status,
            text: function () { return Promise.resolve(txt); },
            json: function () {
              return new Promise(function (resJ, rejJ) {
                try { resJ(JSON.parse(txt)); } catch (e) { rejJ(e); }
              });
            }
          });
        }
      };

      xhr.onerror = function () {
        if (settled) return;
        if (self.bridge && self.bridge.hasNodeFS()) {
          self.bridge.nodeHttpsRequest(url, { method: method, headers: headers || {} }, bodyStr)
            .then(function (nRes) {
              if (!settled) {
                settled = true;
                self._activeXhr = null;
                self._activeAbortFn = null;
                resolve(nRes);
              }
            })
            .catch(function (err) {
              if (!settled) {
                settled = true;
                self._activeXhr = null;
                self._activeAbortFn = null;
                reject(err);
              }
            });
          return;
        }
        settled = true;
        self._activeXhr = null;
        self._activeAbortFn = null;
        reject(new Error('Network error'));
      };

      xhr.ontimeout = function () {
        if (!settled) {
          settled = true;
          self._activeXhr = null;
          self._activeAbortFn = null;
          var tErr = new Error('Request timed out');
          tErr.name = 'TimeoutError';
          reject(tErr);
        }
      };

      xhr.send(bodyStr || null);
    });
  };

  ApiHandler.prototype._httpPostJson = function (url, headers, payloadObj, timeoutMs) {
    return this._httpRequest('POST', url, headers, JSON.stringify(payloadObj), timeoutMs);
  };

  ApiHandler.prototype._httpGet = function (url, headers, timeoutMs) {
    return this._httpRequest('GET', url, headers, null, timeoutMs);
  };

  // ───────── Connection & Model Testing ─────────

  ApiHandler.prototype.testConnection = function (keyStr, provider) {
    var active = this.getActiveKeyObj();
    var rawKey = keyStr || (active ? active.key : null);
    var prov = provider || (active ? active.provider : 'gemini');
    if (!rawKey) return Promise.resolve({ success: false, message: 'No API key provided' });

    var cleanKey = String(rawKey).trim().replace(/^['"`]+|['"`]+$/g, '');
    var startTime = Date.now();

    if (prov === 'gemini') {
      var url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(cleanKey);
      return this._httpPostJson(url, { 'Content-Type': 'application/json' }, {
        contents: [{ parts: [{ text: 'ping' }] }],
        generationConfig: { maxOutputTokens: 5 }
      }, 15000).then(function (res) {
        var latency = Date.now() - startTime;
        if (res.ok) {
          return { success: true, status: 200, latency: latency, message: 'Connected & Working (' + latency + 'ms)' };
        }
        return res.json().catch(function () { return {}; }).then(function (errJson) {
          var detail = (errJson.error && errJson.error.message) ? errJson.error.message : ('HTTP ' + res.status);
          if (res.status === 400) return { success: false, status: 400, latency: latency, message: 'Invalid API Key: ' + detail };
          if (res.status === 403) return { success: false, status: 403, latency: latency, message: 'Forbidden / API Disabled: ' + detail };
          if (res.status === 429) return { success: false, status: 429, latency: latency, message: 'Rate Limited / Quota Exceeded' };
          return { success: false, status: res.status, latency: latency, message: 'API Error ' + res.status + ': ' + detail };
        });
      }).catch(function (e) {
        return { success: false, latency: Date.now() - startTime, message: 'Network error: ' + e.message };
      });
    }

    var endpoint = prov === 'mistral'
      ? 'https://api.mistral.ai/v1/models'
      : (prov === 'grok' ? 'https://api.x.ai/v1/models' : (prov === 'openai' ? 'https://api.openai.com/v1/models' : ''));

    if (!endpoint) {
      return Promise.resolve({ success: false, message: 'Unsupported provider: ' + prov });
    }

    return this._httpGet(endpoint, { Authorization: 'Bearer ' + cleanKey }, 15000).then(function (res) {
      var lat = Date.now() - startTime;
      var label = prov.charAt(0).toUpperCase() + prov.slice(1);
      return res.ok
        ? { success: true, status: 200, latency: lat, message: 'Connected (' + lat + 'ms)' }
        : { success: false, status: res.status, latency: lat, message: label + ' Error ' + res.status };
    }).catch(function (e) {
      return { success: false, latency: Date.now() - startTime, message: 'Network error: ' + e.message };
    });
  };

  ApiHandler.prototype.testGeminiModel = function (modelId, keyStr) {
    var self = this;
    var geminiKeyObj = findInList(this.keys, function (k) { return k.provider === 'gemini'; });
    var active = this.getActiveKeyObj();
    var rawKey = keyStr || (geminiKeyObj ? geminiKeyObj.key : (active ? active.key : null));
    if (!rawKey) return Promise.resolve({ success: false, message: 'No Gemini API key available' });

    var cleanKey = String(rawKey).trim().replace(/^['"`]+|['"`]+$/g, '');
    var candidates = MODEL_FALLBACK_CANDIDATES[modelId] || [modelId];
    var lastRes = null;

    function tryCandidate(idx) {
      if (idx >= candidates.length) {
        if (lastRes && lastRes.status === 404) {
          var target = findInList(self.geminiModels, function (m) { return m.id === modelId; });
          if (target && target.enabled) {
            target.enabled = false;
            self._saveState();
          }
        }
        return Promise.resolve(lastRes || { success: false, message: 'Test failed' });
      }

      var candidate = candidates[idx];
      var isAgent = self._isAgentModel(candidate);
      var isGem4 = String(candidate || '').indexOf('gemini-4') === 0;
      var startTime = Date.now();
      var url = isAgent
        ? 'https://generativelanguage.googleapis.com/v1beta/interactions'
        : ('https://generativelanguage.googleapis.com/v1beta/models/' + candidate + ':generateContent?key=' + encodeURIComponent(cleanKey));
      var headers = isAgent
        ? { 'Content-Type': 'application/json', 'x-goog-api-key': cleanKey }
        : { 'Content-Type': 'application/json' };
      var payload = isAgent
        ? { agent: candidate, environment: 'remote', input: 'Reply with OK.' }
        : {
            contents: [{ parts: [{ text: 'ping' }] }],
            generationConfig: isGem4
              ? { maxOutputTokens: 64, thinkingConfig: { thinkingLevel: 'low' } }
              : { maxOutputTokens: 5 }
          };

      return self._httpPostJson(
        url,
        headers,
        payload,
        isAgent ? 25000 : (isGem4 ? 15000 : 10000)
      ).then(function (res) {
        var latency = Date.now() - startTime;
        if (res.ok) {
          if (candidate !== modelId) {
            var m = findInList(self.geminiModels, function (x) { return x.id === modelId; });
            if (m) {
              m.id = candidate;
              self._saveState();
            }
          }
          return { success: true, status: 200, latency: latency, message: 'Active & Working (' + latency + 'ms)' };
        }

        return res.json().catch(function () { return {}; }).then(function (errData) {
          var detail = (errData.error && errData.error.message) ? errData.error.message : ('HTTP ' + res.status);
          lastRes = {
            success: false,
            status: res.status,
            latency: latency,
            message: res.status === 404 ? 'Model not available on this key/tier (404)' : (res.status === 429 ? 'Rate limited / Quota exhausted' : detail)
          };
          if (res.status !== 404) return lastRes;
          return tryCandidate(idx + 1);
        });
      }).catch(function (e2) {
        lastRes = {
          success: false,
          latency: Date.now() - startTime,
          message: e2.name === 'TimeoutError' ? ('Request timed out (' + (isAgent ? '25s' : (isGem4 ? '15s' : '10s')) + ')') : ('Network error: ' + e2.message)
        };
        return tryCandidate(idx + 1);
      });
    }

    return tryCandidate(0);
  };

  // ───────── Quota Tracking ─────────

  ApiHandler.prototype._getModelLimits = function (modelName) {
    var found = findInList(this.geminiModels, function (m) { return m.id === modelName; });
    if (found) {
      return { rpm: Math.max(1, found.rpm - 1), rpd: found.rpd };
    }
    if (String(modelName).indexOf('lite') >= 0) return { rpm: 14, rpd: 500 };
    return { rpm: 4, rpd: 20 };
  };

  ApiHandler.prototype._isModelAvailable = function (key, model) {
    if (!this.modelUsage[key]) this.modelUsage[key] = {};
    if (!this.modelUsage[key][model]) {
      this.modelUsage[key][model] = { rpmCount: 0, rpmReset: 0, rpdCount: 0, rpdReset: 0 };
    }
    var usage = this.modelUsage[key][model];
    var limits = this._getModelLimits(model);
    var now = Date.now();
    if (now > usage.rpmReset) {
      usage.rpmCount = 0;
      usage.rpmReset = now + 60000;
    }
    if (now > usage.rpdReset) {
      usage.rpdCount = 0;
      usage.rpdReset = now + 86400000;
    }
    return usage.rpdCount < limits.rpd && usage.rpmCount < limits.rpm;
  };

  ApiHandler.prototype._recordModelUsage = function (key, model) {
    if (!this.modelUsage[key]) this.modelUsage[key] = {};
    if (!this.modelUsage[key][model]) {
      this.modelUsage[key][model] = {
        rpmCount: 0,
        rpmReset: Date.now() + 60000,
        rpdCount: 0,
        rpdReset: Date.now() + 86400000
      };
    }
    var usage = this.modelUsage[key][model];
    var now = Date.now();
    if (now > usage.rpmReset) {
      usage.rpmCount = 0;
      usage.rpmReset = now + 60000;
    }
    if (now > usage.rpdReset) {
      usage.rpdCount = 0;
      usage.rpdReset = now + 86400000;
    }
    usage.rpmCount++;
    usage.rpdCount++;
    this._saveState();
  };

  // ───────── Multi-Turn Multimodal Chat Call ─────────

  ApiHandler.prototype.requestStop = function () {
    this.stopRequested = true;
    if (typeof this._activeAbortFn === 'function') {
      try { this._activeAbortFn(); } catch (e) {}
    } else if (this._activeXhr) {
      try { this._activeXhr.abort(); } catch (e2) {}
    }
  };

  ApiHandler.prototype._extractBase64Parts = function (dataUrl) {
    var m = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (m) {
      return { mimeType: m[1], data: m[2] };
    }
    return { mimeType: 'image/jpeg', data: String(dataUrl || '').split(',')[1] || String(dataUrl || '') };
  };

  ApiHandler.prototype._extractGeminiText = function (data) {
    var cand = data && data.candidates && data.candidates[0];
    if (!cand) {
      var blockReason = data && data.promptFeedback && data.promptFeedback.blockReason;
      return { text: '', finishReason: blockReason || 'NO_CANDIDATE' };
    }
    var parts = (cand.content && Array.isArray(cand.content.parts)) ? cand.content.parts : [];
    var chunks = [];
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (p && !p.thought && typeof p.text === 'string') {
        chunks.push(p.text);
      }
    }
    var text = chunks.join('');
    if (!text && parts.length > 0 && typeof parts[0].text === 'string') {
      text = parts[0].text;
    }
    return { text: text, finishReason: cand.finishReason || '' };
  };

  ApiHandler.prototype._buildInteractionsInput = function (messages) {
    var parts = [];
    var textChunks = [];
    var imageParts = [];
    var list = Array.isArray(messages) ? messages : [];

    for (var i = 0; i < list.length; i++) {
      var msg = list[i];
      if (!msg) continue;
      var isLast = (i === list.length - 1);
      var roleLabel = (msg.role === 'assistant' || msg.role === 'model') ? 'Assistant' : 'User';
      var contentStr = String(msg.content || '').trim();
      if (contentStr) {
        if (list.length === 1) {
          textChunks.push(contentStr);
        } else if (isLast) {
          textChunks.push('[Current Request]\n' + contentStr);
        } else {
          textChunks.push(roleLabel + ': ' + contentStr);
        }
      }
      if (Array.isArray(msg.images)) {
        for (var im = 0; im < msg.images.length; im++) {
          var imgItem = msg.images[im];
          var dataUrl = typeof imgItem === 'string' ? imgItem : (imgItem && imgItem.dataUrl);
          if (dataUrl) {
            var extracted = this._extractBase64Parts(dataUrl);
            imageParts.push({
              type: 'image',
              data: extracted.data,
              mime_type: extracted.mimeType
            });
          }
        }
      }
    }

    var combinedText = textChunks.join('\n\n').trim() || 'Hello';
    parts.push({ type: 'text', text: combinedText });
    for (var j = 0; j < imageParts.length; j++) {
      parts.push(imageParts[j]);
    }
    return parts;
  };

  ApiHandler.prototype._extractInteractionText = function (data) {
    if (!data || typeof data !== 'object') {
      return { text: '', finishReason: 'NO_OUTPUT' };
    }
    var status = data.status || '';
    if (typeof data.output_text === 'string' && data.output_text.trim()) {
      return { text: data.output_text, finishReason: status };
    }

    var text = '';
    if (Array.isArray(data.steps) && data.steps.length > 0) {
      var modelOutputs = [];
      for (var i = 0; i < data.steps.length; i++) {
        var step = data.steps[i];
        if (!step || step.type === 'thought') continue;
        if (step.type === 'model_output' && Array.isArray(step.content)) {
          var stepChunks = [];
          for (var c = 0; c < step.content.length; c++) {
            var block = step.content[c];
            if (block && block.type === 'text' && typeof block.text === 'string') {
              stepChunks.push(block.text);
            }
          }
          if (stepChunks.length > 0) {
            modelOutputs.push(stepChunks.join(''));
          }
        } else if (step.type === 'text' && typeof step.text === 'string') {
          modelOutputs.push(step.text);
        }
      }
      if (modelOutputs.length > 0) {
        text = modelOutputs[modelOutputs.length - 1];
      }
    }

    if (!text && Array.isArray(data.outputs) && data.outputs.length > 0) {
      var outChunks = [];
      for (var k = 0; k < data.outputs.length; k++) {
        var outItem = data.outputs[k];
        if (outItem && typeof outItem.text === 'string' && (!outItem.type || outItem.type === 'text')) {
          outChunks.push(outItem.text);
        }
      }
      if (outChunks.length > 0) {
        text = outChunks[outChunks.length - 1];
      }
    }

    return { text: text, finishReason: status };
  };

  ApiHandler.prototype._pollInteraction = function (interactionId, apiKey, maxWaitMs) {
    var self = this;
    var deadline = Date.now() + (maxWaitMs || 120000);
    var url = 'https://generativelanguage.googleapis.com/v1beta/interactions/' + encodeURIComponent(interactionId);
    var headers = { 'x-goog-api-key': apiKey };

    function waitMs(ms) {
      return new Promise(function (resolve, reject) {
        var elapsed = 0;
        var timer = setInterval(function () {
          if (self.stopRequested) {
            clearInterval(timer);
            reject(new Error('Stopped by user'));
            return;
          }
          elapsed += 100;
          if (elapsed >= ms) {
            clearInterval(timer);
            resolve();
          }
        }, 100);
      });
    }

    function pollStep() {
      if (self.stopRequested) return Promise.reject(new Error('Stopped by user'));
      if (Date.now() > deadline) {
        return Promise.reject(new Error('Agent interaction timed out while polling'));
      }
      return waitMs(2000).then(function () {
        return self._httpGet(url, headers, 30000);
      }).then(function (res) {
        if (!res.ok) {
          return res.json().catch(function () { return {}; }).then(function (eJson) {
            var msg = (eJson.error && eJson.error.message) ? (eJson.error.message + ' (' + res.status + ')') : ('Interaction poll error: ' + res.status);
            throw new Error(msg);
          });
        }
        return res.json();
      }).then(function (data) {
        var st = data && data.status;
        if (st === 'in_progress' || st === 'queued') {
          return pollStep();
        }
        return data;
      });
    }

    return pollStep();
  };

  ApiHandler.prototype._isValidJsonPayload = function (rawText) {
    var txt = String(rawText || '').trim();
    if (!txt) return false;
    var fenced = txt.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
    if (fenced && fenced[1]) {
      try { JSON.parse(fenced[1]); return true; } catch (e1) {}
    }
    try { JSON.parse(txt); return true; } catch (e2) {}
    var firstBrace = txt.indexOf('{');
    var lastBrace = txt.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      try { JSON.parse(txt.slice(firstBrace, lastBrace + 1)); return true; } catch (e3) {}
    }
    return false;
  };

  ApiHandler.prototype.sendAgentChat = function (messages, systemInstruction, retries, options) {
    var self = this;
    retries = retries || 0;
    options = options || {};
    var expectJson = !!options.expectJson;
    var excludeModels = Array.isArray(options.excludeModels) ? options.excludeModels : [];
    if (this.stopRequested) return Promise.reject(new Error('Stopped by user'));

    var keyObj = this.getActiveKeyObj();

    // If no personal API key is configured, route securely through Admin Shared API proxy
    if (!keyObj) {
      if (this.auth && this.currentTurnToken) {
        return this.auth.adminChat({
          turnToken: this.currentTurnToken,
          messages: messages,
          systemInstruction: systemInstruction,
          expectJson: expectJson,
          excludeModels: excludeModels
        });
      }
      return Promise.reject(new Error('No API key configured and no active Admin AI session.'));
    }

    var isGemini = keyObj.provider === 'gemini';
    var isMistral = keyObj.provider === 'mistral';
    var isGrok = keyObj.provider === 'grok';

    var availableModels = ['default'];
    if (isGemini) {
      var activeList = this.getActiveGeminiModels();
      availableModels = activeList.filter(function (m) { return self._isModelAvailable(keyObj.key, m); });
      if (availableModels.length === 0) {
        return this._handleRateLimit(messages, systemInstruction, retries, options);
      }
      var nonExcluded = availableModels.filter(function (m) { return excludeModels.indexOf(m) < 0; });
      if (nonExcluded.length > 0) {
        availableModels = nonExcluded;
      }
    }

    var lastError = null;

    function buildRequestForModel(model) {
      var url, body, headers;
      var isAgent = isGemini && self._isAgentModel(model);
      if (isAgent) {
        url = 'https://generativelanguage.googleapis.com/v1beta/interactions';
        body = {
          agent: self._resolveModelEndpoint(model),
          input: self._buildInteractionsInput(messages),
          environment: 'remote'
        };
        if (systemInstruction) {
          body.system_instruction = String(systemInstruction);
        }
        headers = {
          'Content-Type': 'application/json',
          'x-goog-api-key': keyObj.key
        };
      } else if (isGemini) {
        url = 'https://generativelanguage.googleapis.com/v1beta/models/' + self._resolveModelEndpoint(model) + ':generateContent?key=' + encodeURIComponent(keyObj.key);
        var contents = [];
        for (var i = 0; i < messages.length; i++) {
          var msg = messages[i];
          var role = (msg.role === 'assistant' || msg.role === 'model') ? 'model' : 'user';
          var parts = [];
          if (msg.content) parts.push({ text: String(msg.content) });
          if (Array.isArray(msg.images)) {
            for (var im = 0; im < msg.images.length; im++) {
              var imgItem = msg.images[im];
              var dataUrl = typeof imgItem === 'string' ? imgItem : (imgItem && imgItem.dataUrl);
              if (dataUrl) {
                var extracted = self._extractBase64Parts(dataUrl);
                parts.push({ inline_data: { mime_type: extracted.mimeType, data: extracted.data } });
              }
            }
          }
          if (parts.length === 0) parts.push({ text: ' ' });

          if (contents.length > 0 && contents[contents.length - 1].role === role) {
            for (var pIdx = 0; pIdx < parts.length; pIdx++) {
              contents[contents.length - 1].parts.push(parts[pIdx]);
            }
          } else {
            contents.push({ role: role, parts: parts });
          }
        }
        if (contents.length > 0 && contents[0].role !== 'user') {
          contents.unshift({ role: 'user', parts: [{ text: 'Hello' }] });
        }

        var genConfig = {
          temperature: 0.35,
          maxOutputTokens: 32768
        };
        if (expectJson) {
          genConfig.responseMimeType = 'application/json';
        }
        body = {
          contents: contents,
          generationConfig: genConfig
        };
        if (systemInstruction) {
          body.systemInstruction = { parts: [{ text: systemInstruction }] };
        }
        headers = { 'Content-Type': 'application/json' };
      } else {
        url = isMistral
          ? 'https://api.mistral.ai/v1/chat/completions'
          : (isGrok ? 'https://api.x.ai/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions');

        var hasAnyImage = messages.some(function (m) { return Array.isArray(m.images) && m.images.length > 0; });
        var modelName = isMistral
          ? (hasAnyImage ? 'pixtral-12b-2409' : 'mistral-small-latest')
          : (isGrok ? (hasAnyImage ? 'grok-2-vision-1212' : 'grok-2-latest') : 'gpt-4o');

        var formatted = [];
        if (systemInstruction) formatted.push({ role: 'system', content: systemInstruction });
        for (var j = 0; j < messages.length; j++) {
          var mItem = messages[j];
          var mRole = (mItem.role === 'assistant' || mItem.role === 'model') ? 'assistant' : 'user';
          if (mRole === 'user' && Array.isArray(mItem.images) && mItem.images.length > 0) {
            var contentArr = [{ type: 'text', text: String(mItem.content || '') }];
            for (var k = 0; k < mItem.images.length; k++) {
              var dUrl = typeof mItem.images[k] === 'string' ? mItem.images[k] : (mItem.images[k] && mItem.images[k].dataUrl);
              if (dUrl) {
                contentArr.push({ type: 'image_url', image_url: { url: dUrl } });
              }
            }
            formatted.push({ role: 'user', content: contentArr });
          } else {
            formatted.push({ role: mRole, content: String(mItem.content || '') });
          }
        }
        body = { model: modelName, messages: formatted, temperature: 0.35 };
        headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + keyObj.key };
      }
      return { url: url, body: body, headers: headers, isAgent: isAgent };
    }

    function attemptModel(idx) {
      if (self.stopRequested) return Promise.reject(new Error('Stopped by user'));
      if (idx >= availableModels.length) {
        if (isGemini) {
          var stillAvailable = self.getActiveGeminiModels().filter(function (m) { return self._isModelAvailable(keyObj.key, m); });
          if (stillAvailable.length === 0) {
            return self._handleRateLimit(messages, systemInstruction, retries, options);
          }
        }
        self.usageStats.errorsCount++;
        return Promise.reject(lastError || new Error('API request failed'));
      }

      var model = availableModels[idx];
      var req = buildRequestForModel(model);
      var reqTimeout = (req.isAgent || String(model || '').indexOf('gemini-4') === 0) ? 120000 : 90000;
      self.usageStats.callsMade++;
      if (isGemini) self._recordModelUsage(keyObj.key, model);

      return self._httpPostJson(req.url, req.headers, req.body, reqTimeout)
        .then(function (response) {
          if (req.isAgent && response.status === 400 && req.body.environment) {
            return response.text().catch(function () { return ''; }).then(function (errTxtAgent) {
              if (/environment/i.test(errTxtAgent)) {
                delete req.body.environment;
                return self._httpPostJson(req.url, req.headers, req.body, reqTimeout);
              }
              throw new Error((errTxtAgent || 'Bad Request') + ' (400)');
            });
          }
          if (isGemini && !req.isAgent && response.status === 400 && req.body.generationConfig && req.body.generationConfig.responseMimeType) {
            return response.text().catch(function () { return ''; }).then(function (errTxt400) {
              if (/mime|json/i.test(errTxt400)) {
                delete req.body.generationConfig.responseMimeType;
                return self._httpPostJson(req.url, req.headers, req.body, reqTimeout);
              }
              throw new Error((errTxt400 || 'Bad Request') + ' (400)');
            });
          }
          return response;
        })
        .then(function (response) {
          if (response.status === 429) {
            if (isGemini) {
              if (self.modelUsage[keyObj.key] && self.modelUsage[keyObj.key][model]) {
                var lim = self._getModelLimits(model);
                self.modelUsage[keyObj.key][model].rpmCount = lim.rpm;
                self._saveState();
              }
              return attemptModel(idx + 1);
            }
            return self._handleRateLimit(messages, systemInstruction, retries, options);
          }

          if (!response.ok) {
            return response.json().catch(function () { return {}; }).then(function (eJson) {
              var errMsg = (eJson.error && eJson.error.message)
                ? (eJson.error.message + ' (' + response.status + ')')
                : ('API error: ' + response.status);
              throw new Error(errMsg);
            });
          }

          return response.json().then(function (data) {
            if (req.isAgent && data && (data.status === 'in_progress' || data.status === 'queued') && data.id) {
              return self._pollInteraction(data.id, keyObj.key, 120000);
            }
            return data;
          }).then(function (data) {
            var text = '';
            var finishReason = '';
            if (req.isAgent) {
              if (data && (data.status === 'failed' || data.status === 'cancelled')) {
                var failMsg = (data.error && data.error.message) ? data.error.message : ('Agent interaction ' + data.status);
                throw new Error(failMsg + ' (500)');
              }
              var extractedAgent = self._extractInteractionText(data);
              text = extractedAgent.text;
              finishReason = extractedAgent.finishReason;
            } else if (isGemini) {
              var extractedGem = self._extractGeminiText(data);
              text = extractedGem.text;
              finishReason = extractedGem.finishReason;
            } else {
              text = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
              finishReason = (data.choices && data.choices[0] && data.choices[0].finish_reason) || '';
            }

            if (!String(text || '').trim()) {
              throw new Error('Empty response from ' + (isGemini ? model : keyObj.provider) + (finishReason ? ' (' + finishReason + ')' : ''));
            }
            if (expectJson && (!self._isValidJsonPayload(text) || finishReason === 'MAX_TOKENS')) {
              throw new Error('Incomplete JSON from ' + (isGemini ? model : keyObj.provider) + (finishReason ? ' (' + finishReason + ')' : ''));
            }

            return { text: text, finishReason: finishReason, modelUsed: isGemini ? model : keyObj.provider };
          });
        })
        .catch(function (error) {
          if (self.stopRequested) {
            throw new Error('Stopped by user');
          }
          if (error && (error.name === 'AbortError' || error.name === 'TimeoutError')) {
            error = new Error('Request timed out after ' + Math.round(reqTimeout / 1000) + 's on ' + (isGemini ? model : keyObj.provider));
          }
          lastError = error;
          if (
            isGemini &&
            error &&
            error.message &&
            (
              error.message.indexOf('404') >= 0 ||
              error.message.indexOf('400') >= 0 ||
              (req.isAgent && error.message.indexOf('403') >= 0) ||
              error.message.indexOf('50') >= 0 ||
              error.message.indexOf('Incomplete JSON') >= 0 ||
              error.message.indexOf('Empty response') >= 0 ||
              error.message.indexOf('timed out') >= 0
            )
          ) {
            return attemptModel(idx + 1);
          }
          self.usageStats.errorsCount++;
          throw error;
        });
    }

    return attemptModel(0);
  };

  ApiHandler.prototype._handleRateLimit = function (messages, systemInstruction, retries, options) {
    var self = this;
    if (this.stopRequested) return Promise.reject(new Error('Stopped by user'));
    if (retries >= Math.max(2, this.keys.length * 2)) {
      return Promise.reject(new Error('Rate limit exceeded on all available API keys.'));
    }
    if (this.mode === 'manual' && retries >= 2 && this.keys.length > 1) {
      this.rotateKey();
    } else if (this.mode !== 'manual') {
      this.rotateKey();
    }
    var waitSec = (this.keys.length <= 1 || retries >= this.keys.length) ? 15 : 3;

    return new Promise(function (resolve, reject) {
      var ticks = 0;
      var maxTicks = waitSec * 10;
      var timer = setInterval(function () {
        if (self.stopRequested) {
          clearInterval(timer);
          reject(new Error('Stopped by user'));
          return;
        }
        ticks++;
        if (ticks >= maxTicks) {
          clearInterval(timer);
          self.sendAgentChat(messages, systemInstruction, retries + 1, options).then(resolve, reject);
        }
      }, 100);
    });
  };

  NS.ApiHandler = ApiHandler;
  NS.DEFAULT_GEMINI_MODELS = DEFAULT_GEMINI_MODELS;
})(window);
