(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  // ES5 Polyfills for Adobe CC 2015 - 2017 (CEP 6 / 7, Chromium 41 - 50)
  if (typeof Object.assign !== 'function') {
    Object.assign = function (target) {
      if (target === null || target === undefined) {
        throw new TypeError('Cannot convert undefined or null to object');
      }
      var to = Object(target);
      for (var i = 1; i < arguments.length; i++) {
        var nextSource = arguments[i];
        if (nextSource !== null && nextSource !== undefined) {
          for (var key in nextSource) {
            if (Object.prototype.hasOwnProperty.call(nextSource, key)) {
              to[key] = nextSource[key];
            }
          }
        }
      }
      return to;
    };
  }

  if (!Array.prototype.find) {
    Array.prototype.find = function (predicate, thisArg) {
      if (this === null || this === undefined) throw new TypeError('Array.prototype.find called on null or undefined');
      if (typeof predicate !== 'function') throw new TypeError('predicate must be a function');
      var list = Object(this);
      var len = list.length >>> 0;
      for (var i = 0; i < len; i++) {
        if (i in list) {
          var val = list[i];
          if (predicate.call(thisArg, val, i, list)) return val;
        }
      }
      return undefined;
    };
  }

  if (!Array.prototype.includes) {
    Array.prototype.includes = function (searchElement, fromIndex) {
      var list = Object(this);
      var len = list.length >>> 0;
      if (len === 0) return false;
      var n = parseInt(fromIndex, 10) || 0;
      var k = n >= 0 ? n : Math.max(len + n, 0);
      while (k < len) {
        if (list[k] === searchElement || (searchElement !== searchElement && list[k] !== list[k])) {
          return true;
        }
        k++;
      }
      return false;
    };
  }

  var DEFAULT_BACKEND_URL = 'https://adobe-ai-agent.vercel.app';

  function getQueryParam(search, name) {
    if (!search) return '';
    var s = search.charAt(0) === '?' ? search.slice(1) : search;
    var pairs = s.split('&');
    for (var i = 0; i < pairs.length; i++) {
      var kv = pairs[i].split('=');
      if (decodeURIComponent(kv[0] || '') === name) {
        return decodeURIComponent((kv[1] || '').replace(/\+/g, ' '));
      }
    }
    return '';
  }

  function resolveBackendUrl() {
    try {
      if (global.location && global.location.search) {
        var q = getQueryParam(global.location.search, 'backend');
        if (q) {
          var cleanQ = q.replace(/\/+$/, '');
          global.localStorage.setItem('adobe_ai_agent_backend_url', cleanQ);
          return cleanQ;
        }
      }
      var saved = global.localStorage.getItem('adobe_ai_agent_backend_url');
      if (saved && /^https?:\/\//i.test(saved)) {
        return saved.replace(/\/+$/, '');
      }
    } catch (e) {}
    return DEFAULT_BACKEND_URL;
  }

  NS.AppConfig = {
    APP_VERSION: '1.1.11',
    BACKEND_URL: resolveBackendUrl()
  };
})(window);
