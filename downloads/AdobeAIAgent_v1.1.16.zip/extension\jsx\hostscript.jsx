/**
 * Adobe AI Agent — Unified ExtendScript Host Engine (ES3)
 * Compatible with Adobe Photoshop CC 2015–2026 & Adobe Illustrator CC 2015–2026
 */

var __AI_HELPERS_LOADED = true;
var __AI_HELPERS_VERSION = 7;

// ============================================================================
// 1. ES3 UTILITIES & JSON SERIALIZATION
// ============================================================================

function __trim(str) {
    if (str === null || typeof str === "undefined") return "";
    return String(str).replace(/^\s+|\s+$/g, "");
}

function __isArray(v) {
    return v && typeof v === "object" && (v instanceof Array || Object.prototype.toString.call(v) === "[object Array]");
}

function __jsonEscape(str) {
    var s = String(str);
    s = s.replace(/\\/g, "\\\\");
    s = s.replace(/"/g, '\\"');
    s = s.replace(/\r/g, "\\r");
    s = s.replace(/\n/g, "\\n");
    s = s.replace(/\t/g, "\\t");
    s = s.replace(/\f/g, "\\f");
    return '"' + s + '"';
}

function __jsonStringify(val) {
    if (val === null || typeof val === "undefined") return "null";
    var t = typeof val;
    if (t === "number") {
        return isFinite(val) ? String(val) : "null";
    }
    if (t === "boolean") {
        return val ? "true" : "false";
    }
    if (t === "string") {
        return __jsonEscape(val);
    }
    if (__isArray(val)) {
        var arrOut = [];
        for (var i = 0; i < val.length; i++) {
            arrOut.push(__jsonStringify(val[i]));
        }
        return "[" + arrOut.join(",") + "]";
    }
    if (t === "object") {
        var keysOut = [];
        for (var k in val) {
            if (val.hasOwnProperty(k)) {
                var v = val[k];
                if (typeof v !== "function" && typeof v !== "undefined") {
                    keysOut.push(__jsonEscape(k) + ":" + __jsonStringify(v));
                }
            }
        }
        return "{" + keysOut.join(",") + "}";
    }
    return "null";
}

function __detectHostApp() {
    var bt = "";
    try { bt = String(BridgeTalk.appName || "").toLowerCase(); } catch (e) {}
    var appName = "";
    try { appName = String(app.name || "").toLowerCase(); } catch (e2) {}

    if (bt.indexOf("photoshop") >= 0 || appName.indexOf("photoshop") >= 0) return "photoshop";
    if (bt.indexOf("illustrator") >= 0 || appName.indexOf("illustrator") >= 0) return "illustrator";
    if (bt.indexOf("aftereffects") >= 0 || appName.indexOf("after effects") >= 0) return "aftereffects";
    return "unknown";
}

function __ensureFolder(folderPath) {
    var f = new Folder(folderPath);
    if (!f.exists) {
        if (f.parent && !f.parent.exists) {
            __ensureFolder(f.parent.fsName);
        }
        f.create();
    }
    return f;
}

function __sanitizeFileName(name) {
    var s = String(name || "design").replace(/[^a-zA-Z0-9_\-\.]/g, "_");
    s = s.replace(/_+/g, "_").replace(/^_+|_+$/g, "");
    return s.length > 0 ? s : "design";
}

// ============================================================================
// 2. HOST CONTEXT INSPECTOR & SAFE SCRIPT RUNNER
// ============================================================================

function __AI_AGENT_GET_CONTEXT() {
    var host = __detectHostApp();
    var info = {
        ok: true,
        hostApp: host,
        appName: "",
        appVersion: "",
        hasOpenDoc: false,
        docsCount: 0
    };

    try { info.appName = String(app.name || ""); } catch (e1) {}
    try { info.appVersion = String(app.version || ""); } catch (e2) {}

    try {
        if (host === "photoshop") {
            info.docsCount = app.documents.length;
            if (app.documents.length > 0) {
                var doc = app.activeDocument;
                info.hasOpenDoc = true;
                info.docName = String(doc.name);
                try { info.docPath = doc.fullName ? String(doc.fullName.fsName) : ""; } catch (ep) { info.docPath = ""; }
                var origUnits = app.preferences.rulerUnits;
                app.preferences.rulerUnits = Units.PIXELS;
                info.widthPx = Math.round(doc.width.as("px"));
                info.heightPx = Math.round(doc.height.as("px"));
                info.resolution = doc.resolution;
                app.preferences.rulerUnits = origUnits;
                try { info.colorMode = String(doc.mode); } catch (ec) {}

                var layersSummary = [];
                var maxL = Math.min(doc.layers.length, 30);
                for (var i = 0; i < maxL; i++) {
                    var lyr = doc.layers[i];
                    layersSummary.push({
                        name: String(lyr.name),
                        typename: String(lyr.typename),
                        visible: !!lyr.visible
                    });
                }
                info.layerCount = doc.layers.length;
                info.layers = layersSummary;
            }
        } else if (host === "illustrator") {
            info.docsCount = app.documents.length;
            if (app.documents.length > 0) {
                var aiDoc = app.activeDocument;
                info.hasOpenDoc = true;
                info.docName = String(aiDoc.name);
                try { info.docPath = aiDoc.fullName ? String(aiDoc.fullName.fsName) : ""; } catch (eap) { info.docPath = ""; }
                try { info.colorSpace = String(aiDoc.documentColorSpace); } catch (ecs) {}

                var abIdx = aiDoc.artboards.getActiveArtboardIndex();
                info.activeArtboardIndex = abIdx;
                info.artboardCount = aiDoc.artboards.length;

                var abs = [];
                for (var a = 0; a < aiDoc.artboards.length; a++) {
                    var r = aiDoc.artboards[a].artboardRect;
                    abs.push({
                        index: a,
                        name: String(aiDoc.artboards[a].name),
                        width: Math.round((r[2] - r[0]) * 100) / 100,
                        height: Math.round((r[1] - r[3]) * 100) / 100,
                        rect: [r[0], r[1], r[2], r[3]]
                    });
                }
                info.artboards = abs;
                if (abs[abIdx]) {
                    info.activeArtboardWidthPt = abs[abIdx].width;
                    info.activeArtboardHeightPt = abs[abIdx].height;
                }

                var aiLayers = [];
                var maxAiL = Math.min(aiDoc.layers.length, 30);
                for (var li = 0; li < maxAiL; li++) {
                    var aLyr = aiDoc.layers[li];
                    aiLayers.push({
                        name: String(aLyr.name),
                        visible: !!aLyr.visible,
                        locked: !!aLyr.locked,
                        itemsCount: aLyr.pageItems.length
                    });
                }
                info.layerCount = aiDoc.layers.length;
                info.layers = aiLayers;
                info.pageItemCount = aiDoc.pageItems.length;
            }
        }
    } catch (err) {
        info.contextWarning = String(err.message || err);
    }

    return __jsonStringify(info);
}

function __AI_AGENT_SAFE_EVAL(codeStr) {
    var host = __detectHostApp();
    var prevPSDialogs = null;
    var prevAIAlert = null;

    if (host === "photoshop") {
        try {
            prevPSDialogs = app.displayDialogs;
            app.displayDialogs = DialogModes.NO;
        } catch (e1) {}
    } else if (host === "illustrator") {
        try {
            prevAIAlert = app.userInteractionLevel;
            app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        } catch (e2) {}
    }

    var out;
    try {
        var runner = new Function(codeStr);
        var res = runner();
        if (typeof res === "undefined") {
            out = { ok: true, result: { message: "Script executed successfully." } };
        } else if (res && typeof res === "object" && typeof res.ok !== "undefined") {
            out = res;
        } else {
            out = { ok: true, result: res };
        }
    } catch (err) {
        out = {
            ok: false,
            error: String(err.message || err),
            line: err.line || 0,
            description: String(err.description || "")
        };
    }

    if (host === "photoshop" && prevPSDialogs !== null) {
        try { app.displayDialogs = prevPSDialogs; } catch (e3) {}
    } else if (host === "illustrator" && prevAIAlert !== null) {
        try { app.userInteractionLevel = prevAIAlert; } catch (e4) {}
    }

    return __jsonStringify(out);
}

function __AI_AGENT_CAPTURE_PREVIEW(outputPath) {
    var host = __detectHostApp();
    if (!outputPath) {
        return __jsonStringify({ ok: false, error: "Missing outputPath" });
    }

    try {
        if (typeof app.documents === "undefined" || app.documents.length === 0) {
            return __jsonStringify({ ok: false, noDoc: true });
        }
    } catch (eDocs) {
        return __jsonStringify({ ok: false, noDoc: true });
    }

    var outFile = new File(outputPath);
    if (outFile.parent && !outFile.parent.exists) {
        __ensureFolder(outFile.parent.fsName);
    }

    if (host === "photoshop") {
        var doc = app.activeDocument;
        var docName = String(doc.name || "Untitled");
        var prevPSDialogs = null;
        var origUnits = null;
        var wPx = 0;
        var hPx = 0;

        try {
            prevPSDialogs = app.displayDialogs;
            app.displayDialogs = DialogModes.NO;
            origUnits = app.preferences.rulerUnits;
            app.preferences.rulerUnits = Units.PIXELS;
            wPx = Math.round(doc.width.as("px"));
            hPx = Math.round(doc.height.as("px"));

            var jpgOpts = new JPEGSaveOptions();
            jpgOpts.quality = 8;
            jpgOpts.embedColorProfile = false;
            jpgOpts.formatOptions = FormatOptions.STANDARDBASELINE;

            var savedDirectly = false;
            if (wPx <= 1600 && hPx <= 1600 && doc.mode === DocumentMode.RGB && doc.bitsPerChannel === BitsPerChannelType.EIGHT) {
                try {
                    doc.saveAs(outFile, jpgOpts, true, Extension.LOWERCASE);
                    savedDirectly = outFile.exists;
                } catch (eDirect) {
                    savedDirectly = false;
                }
            }

            if (!savedDirectly) {
                var tmpDoc = null;
                try {
                    try {
                        tmpDoc = doc.duplicate("__ai_agent_preview__", true);
                    } catch (eDup1) {
                        tmpDoc = doc.duplicate("__ai_agent_preview__");
                    }
                    app.activeDocument = tmpDoc;
                    try {
                        if (tmpDoc.bitsPerChannel !== BitsPerChannelType.EIGHT) {
                            tmpDoc.bitsPerChannel = BitsPerChannelType.EIGHT;
                        }
                    } catch (eb) {}
                    try {
                        if (tmpDoc.mode !== DocumentMode.RGB) {
                            tmpDoc.changeMode(ChangeMode.RGB);
                        }
                    } catch (em) {}
                    try { tmpDoc.flatten(); } catch (ef) {}

                    var maxSide = Math.max(wPx, hPx);
                    if (maxSide > 1280) {
                        var scale = 1280 / maxSide;
                        tmpDoc.resizeImage(
                            UnitValue(Math.max(1, Math.round(wPx * scale)), "px"),
                            UnitValue(Math.max(1, Math.round(hPx * scale)), "px"),
                            null,
                            ResampleMethod.BICUBIC
                        );
                    }
                    tmpDoc.saveAs(outFile, jpgOpts, true, Extension.LOWERCASE);
                } finally {
                    if (tmpDoc) {
                        try { tmpDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (ec) {}
                    }
                    try { app.activeDocument = doc; } catch (ea) {}
                }
            }

            if (!outFile.exists) {
                return __jsonStringify({ ok: false, error: "Preview JPEG not created" });
            }
            return __jsonStringify({
                ok: true,
                hostApp: "photoshop",
                docName: docName,
                filePath: outFile.fsName,
                mimeType: "image/jpeg",
                width: wPx,
                height: hPx
            });
        } catch (errPs) {
            return __jsonStringify({ ok: false, error: String(errPs.message || errPs) });
        } finally {
            if (origUnits !== null) {
                try { app.preferences.rulerUnits = origUnits; } catch (eu) {}
            }
            if (prevPSDialogs !== null) {
                try { app.displayDialogs = prevPSDialogs; } catch (ed) {}
            }
        }
    } else if (host === "illustrator") {
        var aiDoc = app.activeDocument;
        var aiDocName = String(aiDoc.name || "Untitled");
        var prevAIAlert = null;

        try {
            prevAIAlert = app.userInteractionLevel;
            app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;

            var abIdx = aiDoc.artboards.getActiveArtboardIndex();
            var r = aiDoc.artboards[abIdx].artboardRect;
            var abW = Math.abs(r[2] - r[0]);
            var abH = Math.abs(r[1] - r[3]);
            var maxDim = Math.max(abW, abH, 1);

            var scalePct = 100;
            if (maxDim > 1200) {
                scalePct = Math.max(5, Math.min(100, (1200 / maxDim) * 100));
            } else if (maxDim < 600) {
                scalePct = Math.min(200, (900 / maxDim) * 100);
            }

            var pngOpts = new ExportOptionsPNG24();
            pngOpts.artBoardClipping = true;
            pngOpts.transparency = false;
            pngOpts.antiAliasing = true;
            pngOpts.horizontalScale = scalePct;
            pngOpts.verticalScale = scalePct;
            try {
                pngOpts.matte = true;
                var whiteMatte = new RGBColor();
                whiteMatte.red = 255;
                whiteMatte.green = 255;
                whiteMatte.blue = 255;
                pngOpts.matteColor = whiteMatte;
            } catch (emat) {}

            aiDoc.exportFile(outFile, ExportType.PNG24, pngOpts);

            if (!outFile.exists) {
                return __jsonStringify({ ok: false, error: "Preview PNG not created" });
            }
            return __jsonStringify({
                ok: true,
                hostApp: "illustrator",
                docName: aiDocName,
                filePath: outFile.fsName,
                mimeType: "image/png",
                width: Math.round(abW),
                height: Math.round(abH)
            });
        } catch (errAi) {
            return __jsonStringify({ ok: false, error: String(errAi.message || errAi) });
        } finally {
            if (prevAIAlert !== null) {
                try { app.userInteractionLevel = prevAIAlert; } catch (eai) {}
            }
        }
    }

    return __jsonStringify({ ok: false, error: "Unsupported host app for preview capture" });
}

// ============================================================================
// 3. PHOTOSHOP 2026 HELPERS (Min 4K, Default 16:9 = 3840x2160)
// ============================================================================

var PS_MIN_4K_PIXELS = 3840 * 2160; // 8,294,400 px

function PS_parseRatio(ratioStr) {
    if (!ratioStr) return { rw: 16, rh: 9 };
    var clean = String(ratioStr).replace(/\s+/g, "");
    var parts = clean.split(":");
    if (parts.length === 2) {
        var rw = parseFloat(parts[0]);
        var rh = parseFloat(parts[1]);
        if (rw > 0 && rh > 0) return { rw: rw, rh: rh };
    }
    return { rw: 16, rh: 9 };
}

function PS_ensure4KDims(widthPx, heightPx, ratioStr) {
    var w = parseFloat(widthPx);
    var h = parseFloat(heightPx);

    if (w > 0 && h > 0) {
        var area = w * h;
        if (area < PS_MIN_4K_PIXELS) {
            var scale = Math.sqrt(PS_MIN_4K_PIXELS / area);
            w = Math.ceil(w * scale);
            h = Math.ceil(h * scale);
        }
        return { width: Math.round(w), height: Math.round(h) };
    }

    var r = PS_parseRatio(ratioStr || "16:9");
    if (r.rw === 16 && r.rh === 9) {
        return { width: 3840, height: 2160 };
    }
    if (r.rw === 9 && r.rh === 16) {
        return { width: 2160, height: 3840 };
    }

    var k = Math.sqrt(PS_MIN_4K_PIXELS / (r.rw * r.rh));
    var outW = Math.round(r.rw * k);
    var outH = Math.round(r.rh * k);
    // Ensure at least 3840 on major edge if landscape/square
    if (r.rw >= r.rh && outW < 3840) {
        outW = 3840;
        outH = Math.round((3840 * r.rh) / r.rw);
    } else if (r.rh > r.rw && outH < 3840) {
        outH = 3840;
        outW = Math.round((3840 * r.rw) / r.rh);
    }
    return { width: outW, height: outH };
}

function PS_rgb(r, g, b) {
    var c = new SolidColor();
    c.rgb.red = Math.max(0, Math.min(255, Number(r) || 0));
    c.rgb.green = Math.max(0, Math.min(255, Number(g) || 0));
    c.rgb.blue = Math.max(0, Math.min(255, Number(b) || 0));
    return c;
}

function PS_createDoc(name, widthPx, heightPx, ratioStr, bgRGB, resolutionPpi) {
    app.preferences.rulerUnits = Units.PIXELS;
    app.displayDialogs = DialogModes.NO;

    var dims = PS_ensure4KDims(widthPx, heightPx, ratioStr || "16:9");
    var res = resolutionPpi || 72;
    var docName = name || "AI_Design_4K";

    var doc = app.documents.add(
        UnitValue(dims.width, "px"),
        UnitValue(dims.height, "px"),
        res,
        docName,
        NewDocumentMode.RGB,
        DocumentFill.WHITE
    );

    if (bgRGB && bgRGB.length >= 3) {
        PS_fillBackground(bgRGB[0], bgRGB[1], bgRGB[2]);
    }
    return doc;
}

function PS_fillBackground(r, g, b) {
    var doc = app.activeDocument;
    app.preferences.rulerUnits = Units.PIXELS;
    var targetLayer = doc.layers[doc.layers.length - 1];
    doc.activeLayer = targetLayer;
    if (targetLayer.isBackgroundLayer) {
        targetLayer.isBackgroundLayer = false;
        targetLayer.name = "Background";
    }
    doc.selection.selectAll();
    doc.selection.fill(PS_rgb(r, g, b), ColorBlendMode.NORMAL, 100, false);
    doc.selection.deselect();
    return targetLayer;
}

function PS_addSolidRect(name, x, y, w, h, r, g, b, opacity, cornerRadius) {
    var doc = app.activeDocument;
    app.preferences.rulerUnits = Units.PIXELS;
    var op = (typeof opacity === "number") ? opacity : 100;
    var rad = Number(cornerRadius) || 0;

    try {
        var idMk = charIDToTypeID("Mk  ");
        var desc = new ActionDescriptor();
        var ref = new ActionReference();
        ref.putClass(stringIDToTypeID("contentLayer"));
        desc.putReference(charIDToTypeID("null"), ref);

        var descType = new ActionDescriptor();
        var descColor = new ActionDescriptor();
        var descRGB = new ActionDescriptor();
        descRGB.putDouble(charIDToTypeID("Rd  "), Number(r) || 0);
        descRGB.putDouble(charIDToTypeID("Grn "), Number(g) || 0);
        descRGB.putDouble(charIDToTypeID("Bl  "), Number(b) || 0);
        descColor.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), descRGB);
        descType.putObject(charIDToTypeID("Type"), stringIDToTypeID("solidColorLayer"), descColor);

        var descShape = new ActionDescriptor();
        descShape.putUnitDouble(charIDToTypeID("Top "), charIDToTypeID("#Pxl"), Number(y) || 0);
        descShape.putUnitDouble(charIDToTypeID("Left"), charIDToTypeID("#Pxl"), Number(x) || 0);
        descShape.putUnitDouble(charIDToTypeID("Btom"), charIDToTypeID("#Pxl"), (Number(y) || 0) + (Number(h) || 100));
        descShape.putUnitDouble(charIDToTypeID("Rght"), charIDToTypeID("#Pxl"), (Number(x) || 0) + (Number(w) || 100));
        if (rad > 0) {
            descShape.putUnitDouble(stringIDToTypeID("topRight"), charIDToTypeID("#Pxl"), rad);
            descShape.putUnitDouble(stringIDToTypeID("topLeft"), charIDToTypeID("#Pxl"), rad);
            descShape.putUnitDouble(stringIDToTypeID("bottomLeft"), charIDToTypeID("#Pxl"), rad);
            descShape.putUnitDouble(stringIDToTypeID("bottomRight"), charIDToTypeID("#Pxl"), rad);
        }
        descType.putObject(charIDToTypeID("Shp "), charIDToTypeID("Rctn"), descShape);
        desc.putObject(charIDToTypeID("Usng"), stringIDToTypeID("contentLayer"), descType);
        executeAction(idMk, desc, DialogModes.NO);

        var lyr = doc.activeLayer;
        if (name) lyr.name = String(name);
        lyr.opacity = op;
        return lyr;
    } catch (e) {
        // Fallback: pixel selection fill
        var lyrFallback = doc.artLayers.add();
        lyrFallback.name = name || "Rectangle";
        var x1 = Number(x) || 0;
        var y1 = Number(y) || 0;
        var x2 = x1 + (Number(w) || 100);
        var y2 = y1 + (Number(h) || 100);
        doc.selection.select([[x1, y1], [x2, y1], [x2, y2], [x1, y2]]);
        doc.selection.fill(PS_rgb(r, g, b), ColorBlendMode.NORMAL, 100, false);
        doc.selection.deselect();
        lyrFallback.opacity = op;
        return lyrFallback;
    }
}

function PS_addEllipse(name, x, y, w, h, r, g, b, opacity) {
    var doc = app.activeDocument;
    app.preferences.rulerUnits = Units.PIXELS;
    var op = (typeof opacity === "number") ? opacity : 100;

    try {
        var idMk = charIDToTypeID("Mk  ");
        var desc = new ActionDescriptor();
        var ref = new ActionReference();
        ref.putClass(stringIDToTypeID("contentLayer"));
        desc.putReference(charIDToTypeID("null"), ref);

        var descType = new ActionDescriptor();
        var descColor = new ActionDescriptor();
        var descRGB = new ActionDescriptor();
        descRGB.putDouble(charIDToTypeID("Rd  "), Number(r) || 0);
        descRGB.putDouble(charIDToTypeID("Grn "), Number(g) || 0);
        descRGB.putDouble(charIDToTypeID("Bl  "), Number(b) || 0);
        descColor.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), descRGB);
        descType.putObject(charIDToTypeID("Type"), stringIDToTypeID("solidColorLayer"), descColor);

        var descShape = new ActionDescriptor();
        descShape.putUnitDouble(charIDToTypeID("Top "), charIDToTypeID("#Pxl"), Number(y) || 0);
        descShape.putUnitDouble(charIDToTypeID("Left"), charIDToTypeID("#Pxl"), Number(x) || 0);
        descShape.putUnitDouble(charIDToTypeID("Btom"), charIDToTypeID("#Pxl"), (Number(y) || 0) + (Number(h) || 100));
        descShape.putUnitDouble(charIDToTypeID("Rght"), charIDToTypeID("#Pxl"), (Number(x) || 0) + (Number(w) || 100));
        descType.putObject(charIDToTypeID("Shp "), charIDToTypeID("Elps"), descShape);
        desc.putObject(charIDToTypeID("Usng"), stringIDToTypeID("contentLayer"), descType);
        executeAction(idMk, desc, DialogModes.NO);

        var lyr = doc.activeLayer;
        if (name) lyr.name = String(name);
        lyr.opacity = op;
        return lyr;
    } catch (e) {
        var lyrFallback = doc.artLayers.add();
        lyrFallback.name = name || "Ellipse";
        var docW = doc.width.as("px");
        var docH = doc.height.as("px");
        var leftPct = (x / docW) * 100;
        var topPct = (y / docH) * 100;
        var rightPct = ((x + w) / docW) * 100;
        var botPct = ((y + h) / docH) * 100;
        var d = new ActionDescriptor();
        var r1 = new ActionReference();
        r1.putProperty(charIDToTypeID("Chnl"), charIDToTypeID("fsel"));
        d.putReference(charIDToTypeID("null"), r1);
        var d2 = new ActionDescriptor();
        d2.putUnitDouble(charIDToTypeID("Top "), charIDToTypeID("#Prc"), topPct);
        d2.putUnitDouble(charIDToTypeID("Left"), charIDToTypeID("#Prc"), leftPct);
        d2.putUnitDouble(charIDToTypeID("Btom"), charIDToTypeID("#Prc"), botPct);
        d2.putUnitDouble(charIDToTypeID("Rght"), charIDToTypeID("#Prc"), rightPct);
        d.putObject(charIDToTypeID("T   "), charIDToTypeID("Elps"), d2);
        executeAction(charIDToTypeID("setd"), d, DialogModes.NO);
        doc.selection.fill(PS_rgb(r, g, b), ColorBlendMode.NORMAL, 100, false);
        doc.selection.deselect();
        lyrFallback.opacity = op;
        return lyrFallback;
    }
}

function PS_addGradientLayer(name, r1, g1, b1, r2, g2, b2, angleDeg, opacity) {
    var doc = app.activeDocument;
    var op = (typeof opacity === "number") ? opacity : 100;
    try {
        var desc = new ActionDescriptor();
        var ref = new ActionReference();
        ref.putClass(stringIDToTypeID("contentLayer"));
        desc.putReference(charIDToTypeID("null"), ref);

        var descType = new ActionDescriptor();
        var descGradLayer = new ActionDescriptor();
        descGradLayer.putUnitDouble(charIDToTypeID("Angl"), charIDToTypeID("#Ang"), Number(angleDeg) || 135);
        descGradLayer.putEnumerated(charIDToTypeID("Type"), charIDToTypeID("GrdT"), charIDToTypeID("Lnr "));

        var descGrad = new ActionDescriptor();
        descGrad.putString(charIDToTypeID("Nm  "), "Custom AI Gradient");
        descGrad.putEnumerated(charIDToTypeID("GrdF"), charIDToTypeID("GrdF"), charIDToTypeID("CstS"));
        descGrad.putDouble(charIDToTypeID("Intr"), 4096);

        var clrList = new ActionList();

        var stop1 = new ActionDescriptor();
        var c1 = new ActionDescriptor();
        c1.putDouble(charIDToTypeID("Rd  "), Number(r1) || 0);
        c1.putDouble(charIDToTypeID("Grn "), Number(g1) || 0);
        c1.putDouble(charIDToTypeID("Bl  "), Number(b1) || 0);
        stop1.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), c1);
        stop1.putEnumerated(charIDToTypeID("Type"), charIDToTypeID("Clry"), charIDToTypeID("UsrS"));
        stop1.putInteger(charIDToTypeID("Lctn"), 0);
        stop1.putInteger(charIDToTypeID("Mdpn"), 50);
        clrList.putObject(charIDToTypeID("Clrt"), stop1);

        var stop2 = new ActionDescriptor();
        var c2 = new ActionDescriptor();
        c2.putDouble(charIDToTypeID("Rd  "), Number(r2) || 0);
        c2.putDouble(charIDToTypeID("Grn "), Number(g2) || 0);
        c2.putDouble(charIDToTypeID("Bl  "), Number(b2) || 0);
        stop2.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), c2);
        stop2.putEnumerated(charIDToTypeID("Type"), charIDToTypeID("Clry"), charIDToTypeID("UsrS"));
        stop2.putInteger(charIDToTypeID("Lctn"), 4096);
        stop2.putInteger(charIDToTypeID("Mdpn"), 50);
        clrList.putObject(charIDToTypeID("Clrt"), stop2);

        descGrad.putList(charIDToTypeID("Clrs"), clrList);

        var trnList = new ActionList();
        var t1 = new ActionDescriptor();
        t1.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), 100);
        t1.putInteger(charIDToTypeID("Lctn"), 0);
        t1.putInteger(charIDToTypeID("Mdpn"), 50);
        trnList.putObject(charIDToTypeID("TrnS"), t1);
        var t2 = new ActionDescriptor();
        t2.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), 100);
        t2.putInteger(charIDToTypeID("Lctn"), 4096);
        t2.putInteger(charIDToTypeID("Mdpn"), 50);
        trnList.putObject(charIDToTypeID("TrnS"), t2);
        descGrad.putList(charIDToTypeID("Trns"), trnList);

        descGradLayer.putObject(charIDToTypeID("Grad"), charIDToTypeID("Grdn"), descGrad);
        descType.putObject(charIDToTypeID("Type"), stringIDToTypeID("gradientLayer"), descGradLayer);
        desc.putObject(charIDToTypeID("Usng"), stringIDToTypeID("contentLayer"), descType);
        executeAction(charIDToTypeID("Mk  "), desc, DialogModes.NO);

        var lyr = doc.activeLayer;
        if (name) lyr.name = String(name);
        lyr.opacity = op;
        return lyr;
    } catch (e) {
        return PS_addSolidRect(name || "Gradient Fallback", 0, 0, doc.width.as("px"), doc.height.as("px"), r1, g1, b1, op, 0);
    }
}

function PS_findFont(preferredName) {
    var candidates = [];
    if (preferredName) candidates.push(String(preferredName));
    candidates.push("Arial-BoldMT", "ArialMT", "SegoeUI-Bold", "SegoeUI", "Helvetica-Bold", "Helvetica", "MyriadPro-Regular");

    for (var i = 0; i < candidates.length; i++) {
        try {
            var f = app.fonts.getByName(candidates[i]);
            if (f) return f.postScriptName;
        } catch (e) {}
    }
    if (app.fonts.length > 0) return app.fonts[0].postScriptName;
    return null;
}

function PS_addText(name, textStr, x, y, fontSizePx, r, g, b, fontName, alignStr, tracking) {
    var doc = app.activeDocument;
    app.preferences.rulerUnits = Units.PIXELS;

    var lyr = doc.artLayers.add();
    lyr.kind = LayerKind.TEXT;
    lyr.name = name || String(textStr).substring(0, 28);

    var ti = lyr.textItem;
    ti.kind = TextType.POINTTEXT;
    ti.contents = String(textStr || "");
    ti.size = UnitValue(Number(fontSizePx) || 72, "px");
    ti.color = PS_rgb(r, g, b);

    var psFont = PS_findFont(fontName);
    if (psFont) {
        try { ti.font = psFont; } catch (ef) {}
    }

    var align = String(alignStr || "left").toLowerCase();
    if (align === "center") {
        ti.justification = Justification.CENTER;
    } else if (align === "right") {
        ti.justification = Justification.RIGHT;
    } else {
        ti.justification = Justification.LEFT;
    }

    if (typeof tracking === "number") {
        try { ti.tracking = tracking; } catch (et) {}
    }

    ti.position = [UnitValue(Number(x) || 0, "px"), UnitValue(Number(y) || 100, "px")];
    return lyr;
}

function PS_placeImage(filePath, layerName, x, y, targetW, targetH) {
    var doc = app.activeDocument;
    app.preferences.rulerUnits = Units.PIXELS;
    var f = new File(filePath);
    if (!f.exists) {
        throw new Error("Image file not found: " + filePath);
    }

    var desc = new ActionDescriptor();
    desc.putPath(charIDToTypeID("null"), f);
    desc.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));
    executeAction(charIDToTypeID("Plc "), desc, DialogModes.NO);

    var lyr = doc.activeLayer;
    if (layerName) lyr.name = String(layerName);

    if (typeof targetW === "number" && targetW > 0 && typeof targetH === "number" && targetH > 0) {
        var b = lyr.bounds;
        var curW = b[2].as("px") - b[0].as("px");
        var curH = b[3].as("px") - b[1].as("px");
        if (curW > 0 && curH > 0) {
            var scaleX = (targetW / curW) * 100;
            var scaleY = (targetH / curH) * 100;
            var scale = Math.min(scaleX, scaleY);
            lyr.resize(scale, scale, AnchorPosition.MIDDLECENTER);
        }
    }

    if (typeof x === "number" && typeof y === "number") {
        var b2 = lyr.bounds;
        var dx = x - b2[0].as("px");
        var dy = y - b2[1].as("px");
        lyr.translate(UnitValue(dx, "px"), UnitValue(dy, "px"));
    }

    return lyr;
}

function PS_export(doc, outputDir, baseName, formatsArray) {
    var targetDoc = doc || app.activeDocument;
    app.activeDocument = targetDoc;
    app.displayDialogs = DialogModes.NO;

    var folder = __ensureFolder(outputDir);
    var safeName = __sanitizeFileName(baseName || targetDoc.name.replace(/\.[^\.]+$/, ""));
    var formats = formatsArray && formatsArray.length > 0 ? formatsArray : ["psd", "png"];
    var exported = [];

    for (var i = 0; i < formats.length; i++) {
        var fmt = String(formats[i]).toLowerCase();
        if (fmt === "psd") {
            var psdFile = new File(folder.fsName + "/" + safeName + ".psd");
            var psdOpts = new PhotoshopSaveOptions();
            psdOpts.layers = true;
            psdOpts.embedColorProfile = true;
            targetDoc.saveAs(psdFile, psdOpts, true, Extension.LOWERCASE);
            exported.push(psdFile.fsName);
        } else if (fmt === "png") {
            var pngFile = new File(folder.fsName + "/" + safeName + ".png");
            var pngOpts = new PNGSaveOptions();
            pngOpts.compression = 6;
            pngOpts.interlaced = false;
            targetDoc.saveAs(pngFile, pngOpts, true, Extension.LOWERCASE);
            exported.push(pngFile.fsName);
        } else if (fmt === "jpg" || fmt === "jpeg") {
            var jpgFile = new File(folder.fsName + "/" + safeName + ".jpg");
            var jpgOpts = new JPEGSaveOptions();
            jpgOpts.quality = 12;
            jpgOpts.embedColorProfile = true;
            jpgOpts.formatOptions = FormatOptions.STANDARDBASELINE;
            targetDoc.saveAs(jpgFile, jpgOpts, true, Extension.LOWERCASE);
            exported.push(jpgFile.fsName);
        }
    }

    return exported;
}

// ============================================================================
// 4. ILLUSTRATOR 2026 HELPERS (20 MP, Default 4:3 = 5164x3873, Bounds Guard)
// ============================================================================

var AI_TARGET_20MP = 20000000; // 20 Megapixels

function AI_parseRatio(ratioStr) {
    if (!ratioStr) return { rw: 4, rh: 3 };
    var clean = String(ratioStr).replace(/\s+/g, "");
    var parts = clean.split(":");
    if (parts.length === 2) {
        var rw = parseFloat(parts[0]);
        var rh = parseFloat(parts[1]);
        if (rw > 0 && rh > 0) return { rw: rw, rh: rh };
    }
    return { rw: 4, rh: 3 };
}

function AI_compute20MPDims(ratioStr, customW, customH) {
    var w = parseFloat(customW);
    var h = parseFloat(customH);

    if (w > 0 && h > 0) {
        var area = w * h;
        if (area < AI_TARGET_20MP) {
            var scale = Math.sqrt(AI_TARGET_20MP / area);
            w = Math.ceil(w * scale);
            h = Math.ceil(h * scale);
        }
        return { width: Math.round(w), height: Math.round(h) };
    }

    var r = AI_parseRatio(ratioStr || "4:3");
    if (r.rw === 4 && r.rh === 3) {
        return { width: 5164, height: 3873 }; // Exact 4:3 and 20,000,172 px (20.00 MP)
    }
    if (r.rw === 3 && r.rh === 4) {
        return { width: 3873, height: 5164 };
    }
    var k = Math.sqrt(AI_TARGET_20MP / (r.rw * r.rh));
    return {
        width: Math.ceil(r.rw * k),
        height: Math.ceil(r.rh * k)
    };
}

function AI_rgb(r, g, b) {
    var c = new RGBColor();
    c.red = Math.max(0, Math.min(255, Math.round(Number(r) || 0)));
    c.green = Math.max(0, Math.min(255, Math.round(Number(g) || 0)));
    c.blue = Math.max(0, Math.min(255, Math.round(Number(b) || 0)));
    return c;
}

function AI_createDoc(name, ratioStr, customW, customH, colorSpaceStr) {
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    var dims = AI_compute20MPDims(ratioStr || "4:3", customW, customH);
    var preset = new DocumentPreset();
    preset.title = name || "AI_Vector_20MP";
    preset.width = dims.width;
    preset.height = dims.height;
    try { preset.units = RulerUnits.Pixels; } catch (eu) {}
    if (String(colorSpaceStr || "").toUpperCase() === "CMYK") {
        preset.colorMode = DocumentColorSpace.CMYK;
    } else {
        preset.colorMode = DocumentColorSpace.RGB;
    }
    var doc = app.documents.addDocument(preset.colorMode, preset);
    doc.artboards[0].artboardRect = [0, dims.height, dims.width, 0];
    return doc;
}

function AI_abBounds(doc, abIndex) {
    var d = doc || app.activeDocument;
    var idx = (typeof abIndex === "number") ? abIndex : d.artboards.getActiveArtboardIndex();
    var r = d.artboards[idx].artboardRect;
    return {
        index: idx,
        left: r[0],
        top: r[1],
        right: r[2],
        bottom: r[3],
        width: r[2] - r[0],
        height: r[1] - r[3]
    };
}

function AI_applyStyle(item, fillColor, strokeColor, strokeWidth) {
    if (fillColor) {
        item.filled = true;
        item.fillColor = fillColor;
    } else if (fillColor === null) {
        item.filled = false;
    }
    if (strokeColor) {
        item.stroked = true;
        item.strokeColor = strokeColor;
        item.strokeWidth = (typeof strokeWidth === "number") ? strokeWidth : 2;
    } else {
        item.stroked = false;
    }
    return item;
}

// Top-left artboard coordinate helpers (x right, y down from top-left = 0,0)
function AI_rect(parent, x, y, w, h, fillColor, strokeColor, strokeWidth) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;
    var rect = container.pathItems.rectangle(ab.top - y, ab.left + x, w, h);
    return AI_applyStyle(rect, fillColor, strokeColor, strokeWidth);
}

function AI_roundedRect(parent, x, y, w, h, rx, ry, fillColor, strokeColor, strokeWidth) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;
    var rect = container.pathItems.roundedRectangle(ab.top - y, ab.left + x, w, h, rx || 24, ry || rx || 24);
    return AI_applyStyle(rect, fillColor, strokeColor, strokeWidth);
}

function AI_ellipse(parent, x, y, w, h, fillColor, strokeColor, strokeWidth) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;
    var el = container.pathItems.ellipse(ab.top - y, ab.left + x, w, h);
    return AI_applyStyle(el, fillColor, strokeColor, strokeWidth);
}

function AI_polygon(parent, cx, cy, radius, sides, fillColor, strokeColor, strokeWidth) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;
    var poly = container.pathItems.polygon(ab.left + cx, ab.top - cy, radius, sides || 6);
    return AI_applyStyle(poly, fillColor, strokeColor, strokeWidth);
}

function AI_path(parent, ptsArray, closed, fillColor, strokeColor, strokeWidth) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;
    var p = container.pathItems.add();
    p.closed = (closed !== false);

    for (var i = 0; i < ptsArray.length; i++) {
        var spec = ptsArray[i];
        var pp = p.pathPoints.add();
        if (__isArray(spec)) {
            var ax = ab.left + spec[0];
            var ay = ab.top - spec[1];
            pp.anchor = [ax, ay];
            pp.leftDirection = [ax, ay];
            pp.rightDirection = [ax, ay];
            pp.pointType = PointType.CORNER;
        } else {
            var aPt = [ab.left + spec.anchor[0], ab.top - spec.anchor[1]];
            var lPt = spec.left ? [ab.left + spec.left[0], ab.top - spec.left[1]] : aPt;
            var rPt = spec.right ? [ab.left + spec.right[0], ab.top - spec.right[1]] : aPt;
            pp.anchor = aPt;
            pp.leftDirection = lPt;
            pp.rightDirection = rPt;
            pp.pointType = (spec.left || spec.right) ? PointType.SMOOTH : PointType.CORNER;
        }
    }
    return AI_applyStyle(p, fillColor, strokeColor, strokeWidth);
}

function AI_linearGradient(doc, name, stopsArray, angleDeg) {
    var d = doc || app.activeDocument;
    var grad = d.gradients.add();
    grad.name = name || ("AI_Grad_" + Math.floor(Math.random() * 100000));
    grad.type = GradientType.LINEAR;

    // Remove extra default stops if more than needed, or edit first two
    while (grad.gradientStops.length < stopsArray.length) {
        grad.gradientStops.add();
    }
    for (var i = 0; i < stopsArray.length; i++) {
        var st = grad.gradientStops[i];
        var def = stopsArray[i];
        st.rampPoint = def.offset; // 0..100
        st.color = AI_rgb(def.r, def.g, def.b);
        st.opacity = 100; // Always 100% opaque for EPS-10 pure vector safety
    }

    var gc = new GradientColor();
    gc.gradient = grad;
    gc.angle = (typeof angleDeg === "number") ? angleDeg : 0;
    return gc;
}

function AI_findFont(preferredName) {
    var candidates = [];
    if (preferredName) candidates.push(String(preferredName));
    candidates.push("Arial-BoldMT", "ArialMT", "MyriadPro-Regular", "SegoeUI-Bold", "SegoeUI");

    for (var i = 0; i < candidates.length; i++) {
        try {
            var tf = app.textFonts.getByName(candidates[i]);
            if (tf) return tf;
        } catch (e) {}
    }
    if (app.textFonts.length > 0) return app.textFonts[0];
    return null;
}

function AI_text(parent, textStr, x, y, fontSize, fillColor, fontName, outlineBool) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;

    var tf = container.textFrames.add();
    tf.contents = String(textStr || "");
    tf.position = [ab.left + (Number(x) || 0), ab.top - (Number(y) || 0)];

    var attr = tf.textRange.characterAttributes;
    attr.size = Number(fontSize) || 120;
    if (fillColor) attr.fillColor = fillColor;
    var fnt = AI_findFont(fontName);
    if (fnt) {
        try { attr.textFont = fnt; } catch (ef) {}
    }

    if (outlineBool === true) {
        return tf.createOutline();
    }
    return tf;
}

function AI_importSVG(svgFilePath, targetDoc, fitMarginPt) {
    var svgFile = new File(svgFilePath);
    if (!svgFile.exists) {
        throw new Error("SVG file does not exist: " + svgFilePath);
    }

    var destDoc = targetDoc || app.activeDocument;
    var ab = AI_abBounds(destDoc);
    var margin = (typeof fitMarginPt === "number") ? fitMarginPt : 0;

    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    var svgDoc = app.open(svgFile);
    var svgAb = AI_abBounds(svgDoc, 0);

    if (svgDoc.layers.length > 0) {
        svgDoc.layers[0].locked = false;
        svgDoc.layers[0].visible = true;
    }
    // Group everything in svgDoc + add temporary artboard registration frame to preserve exact SVG margins
    var tempGroup = svgDoc.layers[0].groupItems.add();
    var allItems = [];
    for (var l = 0; l < svgDoc.layers.length; l++) {
        var lyr = svgDoc.layers[l];
        lyr.locked = false;
        lyr.visible = true;
        for (var p = lyr.pageItems.length - 1; p >= 0; p--) {
            var itm = lyr.pageItems[p];
            if (itm !== tempGroup) {
                try { itm.locked = false; } catch (elck) {}
                allItems.push(itm);
            }
        }
    }
    for (var i = allItems.length - 1; i >= 0; i--) {
        try {
            allItems[i].move(tempGroup, ElementPlacement.PLACEATEND);
        } catch (em) {}
    }

    var frameMarker = tempGroup.pathItems.rectangle(svgAb.top, svgAb.left, svgAb.width, svgAb.height);
    frameMarker.name = "__AI_AGENT_SVG_FRAME__";
    frameMarker.filled = false;
    frameMarker.stroked = false;

    var duplicated = tempGroup.duplicate(destDoc.activeLayer, ElementPlacement.PLACEATEND);
    svgDoc.close(SaveOptions.DONOTSAVECHANGES);
    app.activeDocument = destDoc;

    // Fit & center using the preserved artboard frame marker
    var vb = duplicated.visibleBounds; // [left, top, right, bottom]
    var curW = vb[2] - vb[0];
    var curH = vb[1] - vb[3];

    var maxW = ab.width - (margin * 2);
    var maxH = ab.height - (margin * 2);

    if (curW > 0 && curH > 0 && maxW > 0 && maxH > 0) {
        var scaleRatio = Math.min(maxW / curW, maxH / curH) * 100;
        if (Math.abs(scaleRatio - 100) > 0.01) {
            duplicated.resize(scaleRatio, scaleRatio, true, true, true, true, scaleRatio, Transformation.CENTER);
        }

        var vbAfter = duplicated.visibleBounds;
        var afterW = vbAfter[2] - vbAfter[0];
        var afterH = vbAfter[1] - vbAfter[3];
        var targetLeft = ab.left + (ab.width - afterW) / 2;
        var targetTop = ab.top - (ab.height - afterH) / 2;
        duplicated.translate(targetLeft - vbAfter[0], targetTop - vbAfter[1]);
    }

    // Remove the temporary frame marker so only actual artwork remains
    for (var k = duplicated.pathItems.length - 1; k >= 0; k--) {
        if (duplicated.pathItems[k].name === "__AI_AGENT_SVG_FRAME__") {
            duplicated.pathItems[k].remove();
        }
    }

    return duplicated;
}

function __AI_rectsOverlap(b, ab) {
    // Illustrator bounds: [left, top, right, bottom] (top > bottom)
    if (b[2] < ab.left - 1) return false;
    if (b[0] > ab.right + 1) return false;
    if (b[1] < ab.bottom - 1) return false;
    if (b[3] > ab.top + 1) return false;
    return true;
}

function __AI_isInsideBounds(b, ab, tol) {
    var t = (typeof tol === "number") ? tol : 0.75;
    return (
        b[0] >= ab.left - t &&
        b[2] <= ab.right + t &&
        b[1] <= ab.top + t &&
        b[3] >= ab.bottom - t
    );
}

function AI_enforceArtboardBounds(doc, abIndex) {
    var d = doc || app.activeDocument;
    var ab = AI_abBounds(d, abIndex);
    var removedCount = 0;
    var adjustedCount = 0;

    // 1. Clean empty paths / stray points & items completely outside active artboard
    for (var li = d.layers.length - 1; li >= 0; li--) {
        var lyr = d.layers[li];
        if (!lyr.visible || lyr.locked) continue;

        for (var pi = lyr.pageItems.length - 1; pi >= 0; pi--) {
            var item = lyr.pageItems[pi];
            if (item.guides) continue;

            if (item.typename === "PathItem" && item.pathPoints.length === 0) {
                try { item.remove(); removedCount++; } catch (er1) {}
                continue;
            }
            if (item.typename === "GroupItem" && item.pageItems.length === 0) {
                try { item.remove(); removedCount++; } catch (er2) {}
                continue;
            }

            var b = item.visibleBounds;
            if (!__AI_rectsOverlap(b, ab)) {
                try { item.remove(); removedCount++; } catch (er3) {}
            }
        }
    }

    // 2. Clamp oversized simple rectangles (backgrounds) & fit any overflowing items strictly inside artboard
    for (var li2 = 0; li2 < d.layers.length; li2++) {
        var lyr2 = d.layers[li2];
        if (!lyr2.visible || lyr2.locked) continue;

        for (var pi2 = 0; pi2 < lyr2.pageItems.length; pi2++) {
            var itm = lyr2.pageItems[pi2];
            if (itm.guides) continue;
            var vb = itm.visibleBounds;

            if (!__AI_isInsideBounds(vb, ab, 0.75)) {
                // If it's a rectangular background covering the whole artboard and slightly bleeding over:
                var isCoveringBg = (
                    itm.typename === "PathItem" &&
                    itm.pathPoints.length === 4 &&
                    vb[0] <= ab.left + 2 && vb[2] >= ab.right - 2 &&
                    vb[1] >= ab.top - 2 && vb[3] <= ab.bottom + 2
                );

                if (isCoveringBg) {
                    itm.left = ab.left;
                    itm.top = ab.top;
                    itm.width = ab.width;
                    itm.height = ab.height;
                    adjustedCount++;
                } else {
                    // Proportionally scale & translate item inside artboard
                    var curW = vb[2] - vb[0];
                    var curH = vb[1] - vb[3];
                    if (curW > 0 && curH > 0) {
                        if (curW > ab.width || curH > ab.height) {
                            var s = Math.min(ab.width / curW, ab.height / curH) * 99.8;
                            itm.resize(s, s, true, true, true, true, s, Transformation.CENTER);
                            vb = itm.visibleBounds;
                        }
                        var dx = 0;
                        var dy = 0;
                        if (vb[0] < ab.left) dx = ab.left - vb[0];
                        else if (vb[2] > ab.right) dx = ab.right - vb[2];
                        if (vb[1] > ab.top) dy = ab.top - vb[1];
                        else if (vb[3] < ab.bottom) dy = ab.bottom - vb[3];
                        if (dx !== 0 || dy !== 0) {
                            itm.translate(dx, dy);
                        }
                        adjustedCount++;
                    }
                }
            }
        }
    }

    // 3. Final strict verification audit
    var outOfBounds = [];
    for (var li3 = 0; li3 < d.layers.length; li3++) {
        var lyr3 = d.layers[li3];
        if (!lyr3.visible) continue;
        for (var pi3 = 0; pi3 < lyr3.pageItems.length; pi3++) {
            var checkItem = lyr3.pageItems[pi3];
            if (checkItem.guides || checkItem.hidden) continue;
            var checkB = checkItem.visibleBounds;
            if (!__AI_isInsideBounds(checkB, ab, 1.0)) {
                outOfBounds.push({
                    name: String(checkItem.name || checkItem.typename),
                    layer: String(lyr3.name),
                    bounds: [checkB[0], checkB[1], checkB[2], checkB[3]]
                });
            }
        }
    }

    return {
        ok: outOfBounds.length === 0,
        artboardWidth: ab.width,
        artboardHeight: ab.height,
        removedCount: removedCount,
        adjustedCount: adjustedCount,
        outOfBoundsCount: outOfBounds.length,
        outOfBounds: outOfBounds
    };
}

function AI_saveAndExport(doc, outputDir, baseName, formatsArray) {
    var targetDoc = doc || app.activeDocument;
    app.activeDocument = targetDoc;
    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;

    // Mandatory pre-save bounds enforcement!
    var audit = AI_enforceArtboardBounds(targetDoc);
    if (!audit.ok) {
        throw new Error("Artboard bounds guard blocked save: " + audit.outOfBoundsCount + " item(s) still extend outside the artboard.");
    }

    var folder = __ensureFolder(outputDir);
    var safeName = __sanitizeFileName(baseName || targetDoc.name.replace(/\.[^\.]+$/, ""));
    var formats = formatsArray && formatsArray.length > 0 ? formatsArray : ["eps"];
    var exported = [];

    for (var i = 0; i < formats.length; i++) {
        var fmt = String(formats[i]).toLowerCase();
        if (fmt === "ai") {
            var aiFile = new File(folder.fsName + "/" + safeName + ".ai");
            var aiOpts = new IllustratorSaveOptions();
            aiOpts.compressed = true;
            aiOpts.pdfCompatible = true;
            try { aiOpts.embedICCProfile = true; } catch (eicc) {}
            targetDoc.saveAs(aiFile, aiOpts);
            exported.push(aiFile.fsName);
        } else if (fmt === "eps") {
            var epsFile = new File(folder.fsName + "/" + safeName + ".eps");
            var epsOpts = new EPSSaveOptions();
            try { epsOpts.compatibility = Compatibility.ILLUSTRATOR10; } catch (ec) {}
            epsOpts.preview = EPSPreview.COLORTIFF;
            epsOpts.embedAllFonts = false;
            epsOpts.cmykPostScript = (targetDoc.documentColorSpace === DocumentColorSpace.CMYK);
            targetDoc.saveAs(epsFile, epsOpts);
            exported.push(epsFile.fsName);
        } else if (fmt === "svg") {
            var svgFile = new File(folder.fsName + "/" + safeName + ".svg");
            var svgOpts = new ExportOptionsSVG();
            svgOpts.embedRasterImages = false;
            svgOpts.coordinatePrecision = 3;
            svgOpts.saveMultipleArtboards = (targetDoc.artboards.length > 1);
            targetDoc.exportFile(svgFile, ExportType.SVG, svgOpts);
            exported.push(svgFile.fsName);
        } else if (fmt === "png") {
            var pngFile = new File(folder.fsName + "/" + safeName + ".png");
            var pngOpts = new ExportOptionsPNG24();
            pngOpts.artBoardClipping = true;
            pngOpts.transparency = true;
            pngOpts.antiAliasing = true;
            pngOpts.horizontalScale = 100;
            pngOpts.verticalScale = 100;
            targetDoc.exportFile(pngFile, ExportType.PNG24, pngOpts);
            exported.push(pngFile.fsName);
        } else if (fmt === "jpg" || fmt === "jpeg") {
            var jpgFile = new File(folder.fsName + "/" + safeName + ".jpg");
            var jpgOpts = new ExportOptionsJPEG();
            jpgOpts.artBoardClipping = true;
            jpgOpts.antiAliasing = true;
            jpgOpts.qualitySetting = 100;
            jpgOpts.horizontalScale = 100;
            jpgOpts.verticalScale = 100;
            try { jpgOpts.optimization = true; } catch (ejopt) {}
            try {
                jpgOpts.matte = true;
                jpgOpts.matteColor = AI_rgb(255, 255, 255);
            } catch (ejmat) {}
            targetDoc.exportFile(jpgFile, ExportType.JPEG, jpgOpts);
            exported.push(jpgFile.fsName);
        }
    }

    return {
        audit: audit,
        files: exported
    };
}

// ============================================================================
// 5. ICON SET BUILDER WITH SIDE PANEL (ES3 Pure Vector, 20MP+ Stock Ready)
// ============================================================================

function AI_hexToRgb(hexStr, fallbackRgb) {
    var s = String(hexStr || "").replace(/^#/, "").replace(/[^0-9a-fA-F]/g, "");
    if (s.length === 3) {
        s = s.charAt(0) + s.charAt(0) + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2);
    }
    if (s.length !== 6) {
        if (fallbackRgb) return fallbackRgb;
        return AI_rgb(24, 53, 102);
    }
    var r = parseInt(s.substring(0, 2), 16);
    var g = parseInt(s.substring(2, 4), 16);
    var b = parseInt(s.substring(4, 6), 16);
    if (isNaN(r) || isNaN(g) || isNaN(b)) {
        return fallbackRgb || AI_rgb(24, 53, 102);
    }
    return AI_rgb(r, g, b);
}

function AI_hexToObj(hexStr, fallback) {
    var rgb = AI_hexToRgb(hexStr, fallback ? AI_rgb(fallback.r, fallback.g, fallback.b) : null);
    return { r: rgb.red, g: rgb.green, b: rgb.blue };
}

function __AI_colorIsWhite(col) {
    if (!col) return false;
    try {
        if (col.typename === "NoColor") return false;
        if (col.typename === "RGBColor") {
            return col.red >= 245 && col.green >= 245 && col.blue >= 245;
        }
        if (col.typename === "GrayColor") {
            return col.gray <= 4;
        }
        if (col.typename === "CMYKColor") {
            return col.cyan <= 3 && col.magenta <= 3 && col.yellow <= 3 && col.black <= 3;
        }
    } catch (e) {}
    return false;
}

function __AI_itemBoundsInside(innerB, outerB, tol) {
    var t = (typeof tol === "number") ? tol : 1;
    return (
        innerB[0] >= outerB[0] - t &&
        innerB[2] <= outerB[2] + t &&
        innerB[1] <= outerB[1] + t &&
        innerB[3] >= outerB[3] - t
    );
}

function __AI_collectLeafItems(item, outNonWhite, outWhite, outEmpty) {
    if (!item) return;
    try {
        if (item.typename === "GroupItem") {
            for (var i = item.pageItems.length - 1; i >= 0; i--) {
                __AI_collectLeafItems(item.pageItems[i], outNonWhite, outWhite, outEmpty);
            }
            return;
        }
        if (item.typename === "CompoundPathItem") {
            if (item.pathItems.length === 0) {
                outEmpty.push(item);
                return;
            }
            var sample = item.pathItems[0];
            var hasFill = sample.filled && sample.fillColor && sample.fillColor.typename !== "NoColor";
            var hasStroke = sample.stroked && sample.strokeColor && sample.strokeColor.typename !== "NoColor";
            if (!hasFill && !hasStroke) {
                outEmpty.push(item);
            } else if (hasFill && !hasStroke && __AI_colorIsWhite(sample.fillColor)) {
                outWhite.push(item);
            } else {
                outNonWhite.push(item);
            }
            return;
        }
        if (item.typename === "PathItem") {
            var pFill = item.filled && item.fillColor && item.fillColor.typename !== "NoColor";
            var pStroke = item.stroked && item.strokeColor && item.strokeColor.typename !== "NoColor";
            if (!pFill && !pStroke) {
                outEmpty.push(item);
            } else if (pFill && !pStroke && __AI_colorIsWhite(item.fillColor)) {
                outWhite.push(item);
            } else {
                outNonWhite.push(item);
            }
        }
    } catch (e) {}
}

function AI_cleanImportedSvgArtwork(rootGroup, removeAllWhite) {
    if (!rootGroup) return;
    var nonWhite = [];
    var whiteItems = [];
    var emptyItems = [];
    __AI_collectLeafItems(rootGroup, nonWhite, whiteItems, emptyItems);

    for (var ei = 0; ei < emptyItems.length; ei++) {
        try { emptyItems[ei].remove(); } catch (e0) {}
    }

    // Never wipe out an entire icon if the icon itself is purely white artwork
    if (nonWhite.length === 0) {
        return;
    }

    var gb = rootGroup.visibleBounds;
    var gW = Math.max(1, gb[2] - gb[0]);
    var gH = Math.max(1, gb[1] - gb[3]);
    var gArea = gW * gH;

    for (var wi = 0; wi < whiteItems.length; wi++) {
        var wItem = whiteItems[wi];
        var wb;
        try { wb = wItem.visibleBounds; } catch (eb) { continue; }
        var wW = Math.max(0, wb[2] - wb[0]);
        var wH = Math.max(0, wb[1] - wb[3]);
        var wArea = wW * wH;

        var isLargeBg = (wArea >= gArea * 0.42) || (wW >= gW * 0.82 && wH >= gH * 0.82);
        var touchesOuterEdge = (
            Math.abs(wb[0] - gb[0]) <= gW * 0.03 ||
            Math.abs(wb[2] - gb[2]) <= gW * 0.03 ||
            Math.abs(wb[1] - gb[1]) <= gH * 0.03 ||
            Math.abs(wb[3] - gb[3]) <= gH * 0.03
        );

        var enclosedInsideDark = false;
        if (!isLargeBg) {
            for (var ni = 0; ni < nonWhite.length; ni++) {
                try {
                    var nb = nonWhite[ni].visibleBounds;
                    if (__AI_itemBoundsInside(wb, nb, 0.5) && ((nb[2] - nb[0]) * (nb[1] - nb[3])) > wArea * 1.15) {
                        enclosedInsideDark = true;
                        break;
                    }
                } catch (en) {}
            }
        }

        if (removeAllWhite === true || isLargeBg || !enclosedInsideDark || touchesOuterEdge) {
            try { wItem.remove(); } catch (er) {}
        }
    }
}

function AI_importSVGToBox(svgFilePath, targetParent, x, y, boxW, boxH, itemName, removeWhiteBg) {
    var svgFile = new File(svgFilePath);
    if (!svgFile.exists) {
        throw new Error("SVG file not found: " + svgFilePath);
    }

    var destDoc = app.activeDocument;
    var ab = AI_abBounds(destDoc);
    var container = targetParent || destDoc.activeLayer;

    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    var svgDoc = app.open(svgFile);

    if (svgDoc.layers.length > 0) {
        svgDoc.layers[0].locked = false;
        svgDoc.layers[0].visible = true;
    }

    var tempGroup = svgDoc.layers[0].groupItems.add();
    var allItems = [];
    for (var l = 0; l < svgDoc.layers.length; l++) {
        var lyr = svgDoc.layers[l];
        lyr.locked = false;
        lyr.visible = true;
        for (var p = lyr.pageItems.length - 1; p >= 0; p--) {
            var itm = lyr.pageItems[p];
            if (itm !== tempGroup) {
                try { itm.locked = false; } catch (elck) {}
                allItems.push(itm);
            }
        }
    }
    for (var i = allItems.length - 1; i >= 0; i--) {
        try {
            allItems[i].move(tempGroup, ElementPlacement.PLACEATEND);
        } catch (em) {}
    }

    // PLACEATBEGINNING puts the icon ON TOP (front) of layer backgrounds/frames, never behind them!
    var duplicated = tempGroup.duplicate(container, ElementPlacement.PLACEATBEGINNING);
    svgDoc.close(SaveOptions.DONOTSAVECHANGES);
    app.activeDocument = destDoc;

    try { duplicated.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (ez) {}
    if (itemName) {
        try { duplicated.name = String(itemName); } catch (en) {}
    }

    if (removeWhiteBg !== false) {
        AI_cleanImportedSvgArtwork(duplicated, false);
    }

    var vb = duplicated.visibleBounds;
    var curW = vb[2] - vb[0];
    var curH = vb[1] - vb[3];

    if (curW > 0 && curH > 0 && boxW > 0 && boxH > 0) {
        var scalePct = Math.min(boxW / curW, boxH / curH) * 100;
        if (Math.abs(scalePct - 100) > 0.05) {
            duplicated.resize(scalePct, scalePct, true, true, true, true, scalePct, Transformation.CENTER);
        }
        var vb2 = duplicated.visibleBounds;
        var afterW = vb2[2] - vb2[0];
        var afterH = vb2[1] - vb2[3];
        var targetLeft = ab.left + x + (boxW - afterW) / 2;
        var targetTop = ab.top - (y + (boxH - afterH) / 2);
        duplicated.translate(targetLeft - vb2[0], targetTop - vb2[1]);
    }

    return duplicated;
}

function __AI_colorBrightness(col) {
    if (!col) return 0;
    try {
        if (col.typename === "RGBColor") {
            return 0.299 * col.red + 0.587 * col.green + 0.114 * col.blue;
        }
        if (col.typename === "GrayColor") {
            return 255 * (1 - (col.gray / 100));
        }
        if (col.typename === "CMYKColor") {
            var r = 255 * (1 - col.cyan / 100) * (1 - col.black / 100);
            var g = 255 * (1 - col.magenta / 100) * (1 - col.black / 100);
            var b = 255 * (1 - col.yellow / 100) * (1 - col.black / 100);
            return 0.299 * r + 0.587 * g + 0.114 * b;
        }
    } catch (e) {}
    return 0;
}

function AI_recolorGroupSmart(item, primaryRgb, cutoutRgb) {
    if (!item) return;
    try {
        if (item.typename === "GroupItem") {
            for (var i = 0; i < item.pageItems.length; i++) {
                AI_recolorGroupSmart(item.pageItems[i], primaryRgb, cutoutRgb);
            }
            return;
        }
        if (item.typename === "CompoundPathItem") {
            for (var j = 0; j < item.pathItems.length; j++) {
                AI_recolorGroupSmart(item.pathItems[j], primaryRgb, cutoutRgb);
            }
            return;
        }
        if (item.typename === "PathItem") {
            if (item.filled && item.fillColor && item.fillColor.typename !== "NoColor") {
                var br = __AI_colorBrightness(item.fillColor);
                item.fillColor = (br >= 235 && cutoutRgb) ? cutoutRgb : primaryRgb;
            }
            if (item.stroked && item.strokeColor && item.strokeColor.typename !== "NoColor") {
                var sbr = __AI_colorBrightness(item.strokeColor);
                item.strokeColor = (sbr >= 235 && cutoutRgb) ? cutoutRgb : primaryRgb;
            }
        }
    } catch (e) {}
}

function AI_drawSidePanelRect(parent, x, y, w, h, radius, side, fillColor, strokeColor, strokeWidth) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;
    var r = Math.max(0, Math.min(Number(radius) || 0, Math.min(w, h) / 2));
    var k = 0.55228475 * r;

    var roundTL = (side === "left" || side === "top" || side === "all" || side === "top_left");
    var roundBL = (side === "left" || side === "bottom" || side === "all" || side === "bottom_left");
    var roundTR = (side === "right" || side === "top" || side === "all" || side === "top_right");
    var roundBR = (side === "right" || side === "bottom" || side === "all" || side === "bottom_right");

    var x0 = ab.left + x;
    var x1 = x0 + w;
    var y0 = ab.top - y;      // top in AI coords (larger Y)
    var y1 = y0 - h;          // bottom in AI coords (smaller Y)

    var p = container.pathItems.add();
    p.closed = true;

    function addPt(ax, ay, lx, ly, rx, ry, isSmooth) {
        var pp = p.pathPoints.add();
        pp.anchor = [ax, ay];
        pp.leftDirection = [lx, ly];
        pp.rightDirection = [rx, ry];
        pp.pointType = isSmooth ? PointType.SMOOTH : PointType.CORNER;
    }

    // Clockwise from top-left edge
    if (roundTL && r > 0) {
        addPt(x0 + r, y0, x0 + r - k, y0, x0 + r, y0, true);
    } else {
        addPt(x0, y0, x0, y0, x0, y0, false);
    }

    if (roundTR && r > 0) {
        addPt(x1 - r, y0, x1 - r, y0, x1 - r + k, y0, true);
        addPt(x1, y0 - r, x1, y0 - r + k, x1, y0 - r, true);
    } else {
        addPt(x1, y0, x1, y0, x1, y0, false);
    }

    if (roundBR && r > 0) {
        addPt(x1, y1 + r, x1, y1 + r, x1, y1 + r - k, true);
        addPt(x1 - r, y1, x1 - r + k, y1, x1 - r, y1, true);
    } else {
        addPt(x1, y1, x1, y1, x1, y1, false);
    }

    if (roundBL && r > 0) {
        addPt(x0 + r, y1, x0 + r, y1, x0 + r - k, y1, true);
        addPt(x0, y1 + r, x0, y1 + r - k, x0, y1 + r, true);
    } else {
        addPt(x0, y1, x0, y1, x0, y1, false);
    }

    if (roundTL && r > 0) {
        addPt(x0, y0 - r, x0, y0 - r, x0, y0 - r + k, true);
    }

    return AI_applyStyle(p, fillColor, strokeColor, strokeWidth);
}

function AI_wrapLabelText(textStr, maxCharsPerLine) {
    var clean = __trim(String(textStr || "")).replace(/\s+/g, " ");
    var limit = maxCharsPerLine || 14;
    if (clean.length <= limit) return clean;
    var words = clean.split(" ");
    if (words.length <= 1) return clean;

    var bestSplit = -1;
    var bestDiff = 9999;
    for (var i = 1; i < words.length; i++) {
        var l1 = words.slice(0, i).join(" ");
        var l2 = words.slice(i).join(" ");
        var diff = Math.abs(l1.length - l2.length);
        if (diff < bestDiff) {
            bestDiff = diff;
            bestSplit = i;
        }
    }
    if (bestSplit > 0) {
        return words.slice(0, bestSplit).join(" ") + "\r" + words.slice(bestSplit).join(" ");
    }
    return clean;
}

function AI_centeredText(parent, textStr, cx, yTop, fontSize, fillColor, fontName, alignStr, leadingRatio, maxWidth, outlineBool) {
    var doc = app.activeDocument;
    var ab = AI_abBounds(doc);
    var container = parent || doc.activeLayer;

    var tf = container.textFrames.add();
    tf.contents = String(textStr || "").replace(/\r?\n/g, "\r");

    var align = String(alignStr || "center").toLowerCase();
    var just = Justification.CENTER;
    if (align === "left") just = Justification.LEFT;
    else if (align === "right") just = Justification.RIGHT;

    var attr = tf.textRange.characterAttributes;
    attr.size = Number(fontSize) || 40;
    if (fillColor) attr.fillColor = fillColor;
    var fnt = AI_findFont(fontName);
    if (fnt) {
        try { attr.textFont = fnt; } catch (ef) {}
    }
    try {
        attr.autoLeading = false;
        attr.leading = attr.size * (leadingRatio || 1.15);
    } catch (el) {}

    try {
        for (var p = 0; p < tf.paragraphs.length; p++) {
            tf.paragraphs[p].paragraphAttributes.justification = just;
        }
    } catch (ep) {}

    if (typeof maxWidth === "number" && maxWidth > 0) {
        var vbW = tf.visibleBounds;
        var curW = vbW[2] - vbW[0];
        if (curW > maxWidth && curW > 0) {
            var shrinkRatio = (maxWidth / curW) * 100;
            tf.resize(shrinkRatio, shrinkRatio, true, true, true, true, shrinkRatio, Transformation.CENTER);
        }
    }

    var vb = tf.visibleBounds;
    var curCenterX = (vb[0] + vb[2]) / 2;
    var targetX = ab.left + cx;
    var dx = targetX - curCenterX;
    if (align === "left") dx = (ab.left + cx) - vb[0];
    else if (align === "right") dx = (ab.left + cx) - vb[2];

    var targetTop = ab.top - yTop;
    var dy = targetTop - vb[1];
    tf.translate(dx, dy);

    if (outlineBool === true) {
        try {
            return tf.createOutline();
        } catch (eOut) {}
    }
    return tf;
}

function AI_buildIconSetSheet(cfg) {
    if (!cfg || !__isArray(cfg.icons) || cfg.icons.length === 0) {
        throw new Error("No icons provided to AI_buildIconSetSheet.");
    }

    app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
    var icons = cfg.icons;
    var count = icons.length;
    var sp = cfg.sidePanel || {};
    var gr = cfg.grid || {};
    var doOutline = (cfg.outlineText !== false);
    var doRemoveWhite = (cfg.removeWhiteBg !== false);

    var cols = parseInt(gr.cols, 10) || 0;
    var rows = parseInt(gr.rows, 10) || 0;
    if (cols <= 0 && rows <= 0) {
        if (count <= 12) cols = 4;
        else if (count <= 20) cols = 5;
        else if (count <= 24) cols = 8;
        else if (count <= 30) cols = 6;
        else if (count <= 40) cols = 8;
        else cols = Math.ceil(Math.sqrt(count * 1.4));
    }
    if (cols <= 0) cols = Math.ceil(count / rows);
    if (rows <= 0) rows = Math.ceil(count / cols);

    var spPos = String(sp.position || "left").toLowerCase();
    if (spPos !== "left" && spPos !== "right" && spPos !== "top") spPos = "left";

    var ratioStr = cfg.aspectRatio || "";
    if (!ratioStr) {
        var estW = (spPos === "top") ? (cols * 1.15) : (cols * 1.15 + 2.4);
        var estH = (spPos === "top") ? (rows * 1.2 + 1.8) : Math.max(2.6, rows * 1.25);
        ratioStr = String(Math.round(estW * 100) / 100) + ":" + String(Math.round(estH * 100) / 100);
    }

    var doc = AI_createDoc(cfg.setName || "Icon_Set", ratioStr, cfg.customWidth || null, cfg.customHeight || null, "RGB");
    var ab = AI_abBounds(doc, 0);
    var W = ab.width;
    var H = ab.height;

    var outerPadX = Math.round(W * 0.025);
    var outerPadY = Math.round(H * 0.04);
    var cardX = outerPadX;
    var cardY = outerPadY;
    var cardW = W - outerPadX * 2;
    var cardH = H - outerPadY * 2;
    var cornerR = (typeof sp.cornerRadius === "number") ? sp.cornerRadius : Math.round(Math.min(cardW, cardH) * 0.045);

    var rawCardBg = __trim(String(sp.cardBgColor || "")).toLowerCase();
    var wantsCardBg = (rawCardBg !== "" && rawCardBg !== "none" && rawCardBg !== "transparent" && rawCardBg !== "null");
    var cardBgRgb = wantsCardBg ? AI_hexToRgb(rawCardBg) : null;
    if (wantsCardBg && doRemoveWhite && __AI_colorIsWhite(cardBgRgb) && sp.drawCardBg !== true) {
        wantsCardBg = false;
        cardBgRgb = null;
    }

    var rawCardBorder = __trim(String(sp.cardBorderColor || "none")).toLowerCase();
    var wantsCardBorder = (rawCardBorder !== "" && rawCardBorder !== "none" && rawCardBorder !== "transparent" && rawCardBorder !== "null");
    var cardBorderRgb = wantsCardBorder ? AI_hexToRgb(rawCardBorder) : null;

    // Layers (omit Background_Card completely for clean transparent isolated stock output)
    var bgLayer = null;
    var spLayer;
    if (wantsCardBg || wantsCardBorder) {
        bgLayer = doc.layers[0];
        bgLayer.name = "Background_Card";
        spLayer = doc.layers.add();
        spLayer.name = "Side_Panel";
    } else {
        spLayer = doc.layers[0];
        spLayer.name = "Side_Panel";
    }
    var gridLayer = doc.layers.add();
    gridLayer.name = "Icons_Grid";

    var bg1Hex = sp.bgColor || "#183566";
    var bg2Hex = sp.bgColor2 || "";
    var accentRgb = AI_hexToRgb(sp.accentColor || "#29ABE2");
    var titleRgb = AI_hexToRgb(sp.titleColor || "#FFFFFF");
    var subtitleRgb = AI_hexToRgb(sp.subtitleColor || sp.accentColor || "#38BDF8");
    var featureRgb = AI_hexToRgb(sp.featureColor || "#CBD5E1");
    var labelRgb = AI_hexToRgb(gr.labelColor || "#1E293B");

    var layoutStyle = String(sp.layoutStyle || "classic_split").toLowerCase();
    var heroFrameStyle = String(sp.heroFrameStyle || "none").toLowerCase();
    var showDivider = (sp.showDivider !== false);
    var hasFooterBlock = !!sp.footerBlock;
    var topBadgeTxt = __trim(String(sp.topBadgeText || "").replace(/\{COUNT\}/gi, String(count)));

    // 1. Optional Card Background (only when explicitly non-transparent & requested)
    if (bgLayer && wantsCardBg && cardBgRgb) {
        doc.activeLayer = bgLayer;
        AI_drawSidePanelRect(bgLayer, cardX, cardY, cardW, cardH, cornerR, "all", cardBgRgb, null, 0);
    }

    // 2. Side Panel Box Calculation
    var spX = cardX;
    var spY = cardY;
    var spW = 0;
    var spH = 0;
    var gridX = cardX;
    var gridY = cardY;
    var gridW = cardW;
    var gridH = cardH;

    if (spPos === "left") {
        var wrL = (typeof sp.widthRatio === "number" && sp.widthRatio > 0.12 && sp.widthRatio < 0.45) ? sp.widthRatio : 0.235;
        spW = Math.round(cardW * wrL);
        spH = cardH;
        gridX = cardX + spW;
        gridW = cardW - spW;
    } else if (spPos === "right") {
        var wrR = (typeof sp.widthRatio === "number" && sp.widthRatio > 0.12 && sp.widthRatio < 0.45) ? sp.widthRatio : 0.235;
        spW = Math.round(cardW * wrR);
        spH = cardH;
        spX = cardX + cardW - spW;
        gridX = cardX;
        gridW = cardW - spW;
    } else {
        var hrT = (typeof sp.heightRatio === "number" && sp.heightRatio > 0.12 && sp.heightRatio < 0.45) ? sp.heightRatio : 0.24;
        spW = cardW;
        spH = Math.round(cardH * hrT);
        gridY = cardY + spH;
        gridH = cardH - spH;
    }

    doc.activeLayer = spLayer;
    var spFill = bg1Hex
        ? (bg2Hex ? AI_linearGradient(doc, "SidePanelGrad", [
            { offset: 0, r: AI_hexToObj(bg1Hex).r, g: AI_hexToObj(bg1Hex).g, b: AI_hexToObj(bg1Hex).b },
            { offset: 100, r: AI_hexToObj(bg2Hex).r, g: AI_hexToObj(bg2Hex).g, b: AI_hexToObj(bg2Hex).b }
        ], 135) : AI_hexToRgb(bg1Hex))
        : AI_rgb(24, 53, 102);

    AI_drawSidePanelRect(spLayer, spX, spY, spW, spH, cornerR, spPos, spFill, null, 0);

    // Side Panel Contents
    var spPad = Math.round(Math.min(spW, spH) * 0.085);
    var heroIdx = parseInt(sp.heroIconIndex, 10);
    if (isNaN(heroIdx) || heroIdx < 1 || heroIdx > count) heroIdx = 1;
    var heroStyle = String(sp.heroStyle || "monochrome_white").toLowerCase();

    var titleLine1 = String(sp.seoTitleLine1 || sp.seoTitle || "VECTOR");
    var titleLine2 = String(sp.seoTitleLine2 || "ICONS");
    var features = __isArray(sp.featureLines) ? sp.featureLines : [];

    if (spPos === "left" || spPos === "right") {
        var spCx = spX + spW / 2;
        var cursorY = spY + Math.round(spH * 0.055);

        // Optional Top Count Pill/Badge (e.g. "24 ICONS" as in badge_footer_card reference)
        if (topBadgeTxt) {
            var badgeBgRgb = AI_hexToRgb(sp.topBadgeBgColor || sp.accentColor || "#0F2447");
            var badgeTxtRgb = AI_hexToRgb(sp.topBadgeTextColor || "#FFFFFF");
            var bW = Math.round(spW * 0.56);
            var bH = Math.round(Math.max(46, spH * 0.068));
            AI_roundedRect(spLayer, spCx - bW / 2, cursorY, bW, bH, bH / 2, bH / 2, badgeBgRgb, null, 0);
            AI_centeredText(spLayer, topBadgeTxt.toUpperCase(), spCx, cursorY + bH * 0.24, Math.round(bH * 0.46), badgeTxtRgb, "Arial-BoldMT", "center", 1.0, bW * 0.84, doOutline);
            cursorY += bH + Math.round(spH * 0.045);
        } else {
            cursorY = spY + Math.round(spH * 0.09);
        }

        // Hero Icon + Optional Geometric Frame (circle_tint, circle_white, arch_curve, rounded_box)
        var heroAreaH = Math.round(spH * (hasFooterBlock ? 0.27 : 0.31));
        var heroBoxSize = Math.round(Math.min(spW * 0.54, heroAreaH));
        var heroTop = cursorY;
        var heroFrameCenterY = heroTop + heroBoxSize / 2;
        var heroCutoutRgb = AI_hexToRgb(bg1Hex);
        var frameColHex = sp.heroFrameColor || sp.accentColor || "#29ABE2";

        if (heroFrameStyle === "circle_white" || heroStyle === "white_badge") {
            var cwSize = Math.round(heroBoxSize * 1.24);
            AI_ellipse(spLayer, spCx - cwSize / 2, heroFrameCenterY - cwSize / 2, cwSize, cwSize, AI_rgb(255, 255, 255), null, 0);
            heroCutoutRgb = AI_rgb(255, 255, 255);
        } else if (heroFrameStyle === "circle_tint" || heroFrameStyle === "arch_curve") {
            var ctSize = Math.round(heroBoxSize * 1.26);
            var frameRgb = AI_hexToRgb(frameColHex);
            AI_ellipse(spLayer, spCx - ctSize / 2, heroFrameCenterY - ctSize / 2, ctSize, ctSize, frameRgb, AI_rgb(255, 255, 255), Math.max(4, Math.round(spW * 0.012)));
            heroCutoutRgb = frameRgb;
        } else if (heroFrameStyle === "rounded_box") {
            var rbSize = Math.round(heroBoxSize * 1.22);
            var rbRgb = AI_hexToRgb(frameColHex);
            AI_roundedRect(spLayer, spCx - rbSize / 2, heroFrameCenterY - rbSize / 2, rbSize, rbSize, Math.round(rbSize * 0.18), Math.round(rbSize * 0.18), rbRgb, null, 0);
            heroCutoutRgb = rbRgb;
        }

        if (heroIdx >= 1 && icons[heroIdx - 1] && icons[heroIdx - 1].path) {
            var heroInnerSize = (heroFrameStyle !== "none" || heroStyle === "white_badge")
                ? Math.round(heroBoxSize * 0.86)
                : heroBoxSize;
            var heroGrp = AI_importSVGToBox(
                icons[heroIdx - 1].path,
                spLayer,
                spCx - heroInnerSize / 2,
                heroFrameCenterY - heroInnerSize / 2,
                heroInnerSize,
                heroInnerSize,
                "Hero_Icon",
                doRemoveWhite
            );
            if (heroStyle === "monochrome_white" && heroFrameStyle !== "circle_white") {
                AI_recolorGroupSmart(heroGrp, AI_rgb(255, 255, 255), heroCutoutRgb);
            }
            try { heroGrp.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (ehz) {}
        }

        cursorY = heroTop + heroBoxSize + Math.round(spH * 0.045);

        // Optional Horizontal Divider Line
        if (showDivider) {
            var divW = Math.round(spW * 0.68);
            var divH = Math.max(6, Math.round(spH * 0.008));
            var divCol = sp.dividerColor ? AI_hexToRgb(sp.dividerColor) : accentRgb;
            AI_roundedRect(spLayer, spCx - divW / 2, cursorY, divW, divH, divH / 2, divH / 2, divCol, null, 0);
            cursorY += divH + Math.round(spH * 0.04);
        }

        // SEO Title Line 1 & Line 2
        var maxTextW = spW - spPad * 2;
        var t1Size = Math.round(Math.min(spW * 0.145, spH * 0.064));
        var t1Frame = AI_centeredText(spLayer, titleLine1.toUpperCase(), spCx, cursorY, t1Size, titleRgb, "Arial-BoldMT", "center", 1.08, maxTextW, doOutline);
        cursorY = (ab.top - t1Frame.visibleBounds[3]) + Math.round(spH * 0.015);

        if (titleLine2) {
            var t2Size = Math.round(t1Size * 0.90);
            var t2Frame = AI_centeredText(spLayer, titleLine2.toUpperCase(), spCx, cursorY, t2Size, subtitleRgb, "Arial-BoldMT", "center", 1.08, maxTextW, doOutline);
            cursorY = (ab.top - t2Frame.visibleBounds[3]) + Math.round(spH * 0.03);
        } else {
            cursorY += Math.round(spH * 0.025);
        }

        if (sp.seoSubtitle && !hasFooterBlock) {
            var subSize = Math.round(t1Size * 0.40);
            var subFrame = AI_centeredText(spLayer, String(sp.seoSubtitle), spCx, cursorY, subSize, featureRgb, "ArialMT", "center", 1.18, maxTextW, doOutline);
            cursorY = (ab.top - subFrame.visibleBounds[3]) + Math.round(spH * 0.025);
        }

        // Bottom Footer Block (e.g. badge_footer_card reference) OR Standard Bottom Feature Lines
        if (hasFooterBlock) {
            var footerH = Math.round(spH * 0.24);
            var footerY = spY + spH - footerH;
            var footerBgRgb = AI_hexToRgb(sp.footerBgColor || sp.accentColor || "#4A90D9");
            var footerTxtRgb = AI_hexToRgb(sp.footerTextColor || "#0F172A");
            var footerSide = (spPos === "left") ? "bottom_left" : "bottom_right";
            AI_drawSidePanelRect(spLayer, spX, footerY, spW, footerH, cornerR, footerSide, footerBgRgb, null, 0);

            var fLines = [];
            for (var fi0 = 0; fi0 < features.length; fi0++) {
                var ft0 = __trim(String(features[fi0] || "").replace(/\{COUNT\}/gi, String(count)));
                if (ft0) fLines.push(ft0.toUpperCase());
            }
            if (fLines.length === 0) {
                fLines = ["100% VECTOR", "FULLY EDITABLE"];
            }
            var fHeadSize = Math.round(Math.min(spW * 0.10, footerH * 0.24));
            var fSubSize = Math.round(fHeadSize * 0.72);
            var fCurY = footerY + Math.round(footerH * (fLines.length > 1 ? 0.22 : 0.36));
            for (var fli = 0; fli < Math.min(3, fLines.length); fli++) {
                var fSz = (fli === 0) ? fHeadSize : fSubSize;
                var fEl = AI_centeredText(spLayer, fLines[fli], spCx, fCurY, fSz, footerTxtRgb, "Arial-BoldMT", "center", 1.08, maxTextW, doOutline);
                fCurY = (ab.top - fEl.visibleBounds[3]) + Math.round(footerH * 0.09);
            }
        } else if (features.length > 0) {
            var featSize = Math.round(Math.max(24, Math.min(spW * 0.068, spH * 0.028)));
            var featGap = Math.round(featSize * 1.55);
            var maxFeatStart = spY + spH - spPad - (features.length * featGap);
            var featY = Math.max(cursorY + Math.round(spH * 0.015), Math.min(maxFeatStart, cursorY + Math.round(spH * 0.06)));
            for (var fi = 0; fi < features.length; fi++) {
                var fTxt = __trim(String(features[fi] || "").replace(/\{COUNT\}/gi, String(count)));
                if (!fTxt) continue;
                AI_centeredText(spLayer, fTxt.toUpperCase(), spCx, featY, featSize, featureRgb, "Arial-BoldMT", "center", 1.1, maxTextW, doOutline);
                featY += featGap;
            }
        }
    } else {
        // Top banner side panel layout
        var topHeroSize = Math.round(spH * 0.62);
        var topHeroX = spX + spPad;
        var topHeroY = spY + (spH - topHeroSize) / 2;
        if (heroIdx >= 1 && icons[heroIdx - 1] && icons[heroIdx - 1].path) {
            var hGrpTop = AI_importSVGToBox(icons[heroIdx - 1].path, spLayer, topHeroX, topHeroY, topHeroSize, topHeroSize, "Hero_Icon", doRemoveWhite);
            if (heroStyle === "monochrome_white") {
                AI_recolorGroupSmart(hGrpTop, AI_rgb(255, 255, 255), AI_hexToRgb(bg1Hex));
            }
            try { hGrpTop.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (ehtz) {}
        }
        var textLeftX = topHeroX + topHeroSize + spPad;
        var fullTitle = (titleLine1 + (titleLine2 ? (" " + titleLine2) : "")).toUpperCase();
        var topTSize = Math.round(spH * 0.24);
        AI_centeredText(spLayer, fullTitle, textLeftX, spY + spH * 0.24, topTSize, titleRgb, "Arial-BoldMT", "left", 1.1, spW - textLeftX - spPad, doOutline);
        if (features.length > 0) {
            var featJoined = features.join("  •  ").replace(/\{COUNT\}/gi, String(count)).toUpperCase();
            AI_centeredText(spLayer, featJoined, textLeftX, spY + spH * 0.62, Math.round(topTSize * 0.48), subtitleRgb, "Arial-BoldMT", "left", 1.1, spW - textLeftX - spPad, doOutline);
        }
    }

    // 3. Optional outer border on top of card (only when explicitly requested)
    if (bgLayer && wantsCardBorder && cardBorderRgb) {
        doc.activeLayer = bgLayer;
        AI_drawSidePanelRect(bgLayer, cardX, cardY, cardW, cardH, cornerR, "all", null, cardBorderRgb, Math.max(3, Math.round(Math.min(W, H) * 0.0018)));
    }

    // 4. Right Grid Placement + Relevant Icon Labels
    doc.activeLayer = gridLayer;
    var gPadX = Math.round(gridW * 0.045);
    var gPadY = Math.round(gridH * 0.06);
    var innerW = gridW - gPadX * 2;
    var innerH = gridH - gPadY * 2;
    var cellW = innerW / cols;
    var cellH = innerH / rows;

    var iconBoxRatio = 0.56;
    var labelSize = Math.round(Math.max(22, Math.min(cellW * 0.115, cellH * 0.115)));
    var showBoxes = !!gr.showCellBoxes;
    var cellBoxRgb = showBoxes ? AI_hexToRgb(gr.cellBoxColor || "#F1F5F9") : null;
    var useUpper = (gr.uppercaseLabels !== false);

    for (var idx = 0; idx < count; idx++) {
        var item = icons[idx];
        var colIdx = idx % cols;
        var rowIdx = Math.floor(idx / cols);

        var cX = gridX + gPadX + colIdx * cellW;
        var cY = gridY + gPadY + rowIdx * cellH;
        var cCx = cX + cellW / 2;

        if (showBoxes && cellBoxRgb) {
            var bxPad = Math.round(Math.min(cellW, cellH) * 0.06);
            AI_roundedRect(gridLayer, cX + bxPad, cY + bxPad, cellW - bxPad * 2, cellH - bxPad * 2, Math.round(Math.min(cellW, cellH) * 0.08), Math.round(Math.min(cellW, cellH) * 0.08), cellBoxRgb, null, 0);
        }

        var iconBoxW = cellW * iconBoxRatio;
        var iconBoxH = cellH * iconBoxRatio;
        var iconX = cCx - iconBoxW / 2;
        var iconY = cY + cellH * 0.08;

        var rawLabel = String((item && item.label) || ("Icon " + (idx + 1)));
        var cleanLabel = useUpper ? rawLabel.toUpperCase() : rawLabel;
        var wrappedLabel = AI_wrapLabelText(cleanLabel, 14);

        var grpName = String(idx + 1).replace(/^(\d)$/, "0$1") + "_" + __sanitizeFileName(cleanLabel);
        AI_importSVGToBox(item.path, gridLayer, iconX, iconY, iconBoxW, iconBoxH, grpName, doRemoveWhite);

        var labelY = iconY + iconBoxH + cellH * 0.065;
        var maxLblW = cellW * 0.88;
        AI_centeredText(gridLayer, wrappedLabel, cCx, labelY, labelSize, labelRgb, "Arial-BoldMT", "center", 1.12, maxLblW, doOutline);
    }

    // 5. Save & Export
    var exportFormats = (__isArray(cfg.formats) && cfg.formats.length > 0) ? cfg.formats : ["eps"];
    var saved = AI_saveAndExport(doc, cfg.outputDir, cfg.setName || "icon_set", exportFormats);

    if (cfg.closeAfterExport === true) {
        try { doc.close(SaveOptions.DONOTSAVECHANGES); } catch (ec) {}
    }

    return {
        ok: true,
        setName: cfg.setName || "icon_set",
        iconCount: count,
        audit: saved.audit,
        exportedFiles: saved.files
    };
}
