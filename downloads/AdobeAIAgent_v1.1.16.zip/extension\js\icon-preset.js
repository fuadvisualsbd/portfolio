(function (global) {
  'use strict';

  var NS = (global.AdobeAIAgent = global.AdobeAIAgent || {});

  var DEFAULT_DEMO_PROMPT = [
    'Create a commercial stock vector icon set matching the attached Side Panel reference image (structure, badge, hero frame, footer block, and colors).',
    'Side Panel Content:',
    '- SEO Title: Auto-generate a short, high-converting 2-3 word niche title based on the icons (e.g. "ACCOUNTING ICONS", "WEB & UI ICONS").',
    '- Feature Lines on Side Panel: "{COUNT} ICONS", "100% VECTOR", "FULLY EDITABLE". (Do NOT write file formats like AI/EPS/SVG).',
    '- Place 1 large representative hero icon from this set inside the Side Panel.',
    'Vector & Export Rules:',
    '- Place all icons in a clean balanced grid with short 1-3 word uppercase labels centered below each icon.',
    '- Convert all text to vector outlines and remove white background fills from traced SVG files.'
  ].join('\n');

  function IconPresetManager(deps) {
    this.api = deps.api;
    this.auth = deps.auth;
    this.storage = deps.storage;
    this.bridge = NS.CepBridge;
    this.stopRequested = false;
  }

  IconPresetManager.DEFAULT_DEMO_PROMPT = DEFAULT_DEMO_PROMPT;

  IconPresetManager.prototype.requestStop = function () {
    this.stopRequested = true;
    if (this.api && typeof this.api.requestStop === 'function') {
      this.api.requestStop();
    }
  };

  IconPresetManager.prototype._parseJsonSafe = function (rawText) {
    var txt = String(rawText || '').trim();
    if (!txt) return null;
    var fenced = txt.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
    if (fenced && fenced[1]) {
      try { return JSON.parse(fenced[1]); } catch (e1) {}
    }
    try { return JSON.parse(txt); } catch (e2) {}
    var fb = txt.indexOf('{');
    var lb = txt.lastIndexOf('}');
    if (fb >= 0 && lb > fb) {
      try { return JSON.parse(txt.slice(fb, lb + 1)); } catch (e3) {}
    }
    var ab1 = txt.indexOf('[');
    var ab2 = txt.lastIndexOf(']');
    if (ab1 >= 0 && ab2 > ab1) {
      try { return JSON.parse(txt.slice(ab1, ab2 + 1)); } catch (e4) {}
    }
    return null;
  };

  IconPresetManager.prototype._sanitizeSlug = function (str) {
    return String(str || 'icon_set')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 44) || 'icon_set';
  };

  IconPresetManager.prototype._pad2 = function (n) {
    var s = String(n);
    return s.length < 2 ? ('0' + s) : s;
  };

  IconPresetManager.prototype._readSvgAsDataUrl = function (svgPath) {
    var fs = this.bridge.fs;
    if (!fs || !svgPath) return '';
    try {
      var raw = fs.readFileSync(svgPath, 'utf8');
      var normalized = this._normalizeSvgMarkup(raw);
      var b64;
      if (typeof Buffer !== 'undefined' && typeof Buffer.from === 'function') {
        b64 = Buffer.from(normalized, 'utf8').toString('base64');
      } else {
        b64 = global.btoa(unescape(encodeURIComponent(normalized)));
      }
      return 'data:image/svg+xml;base64,' + b64;
    } catch (e) {
      return '';
    }
  };

  IconPresetManager.prototype._normalizeSvgMarkup = function (svgText) {
    var txt = String(svgText || '');
    var openMatch = txt.match(/<svg\b([^>]*)>/i);
    if (!openMatch) return txt;

    var attrs = openMatch[1] || '';
    var hasViewBox = /viewBox\s*=/i.test(attrs);
    var wMatch = attrs.match(/\bwidth\s*=\s*["']\s*([0-9.]+)(?:px|pt)?\s*["']/i);
    var hMatch = attrs.match(/\bheight\s*=\s*["']\s*([0-9.]+)(?:px|pt)?\s*["']/i);

    var cleanAttrs = attrs
      .replace(/\bwidth\s*=\s*["'][^"']*["']/gi, '')
      .replace(/\bheight\s*=\s*["'][^"']*["']/gi, '');

    if (!hasViewBox && wMatch && hMatch) {
      cleanAttrs += ' viewBox="0 0 ' + wMatch[1] + ' ' + hMatch[1] + '"';
    }
    if (!/preserveAspectRatio\s*=/i.test(cleanAttrs)) {
      cleanAttrs += ' preserveAspectRatio="xMidYMid meet"';
    }
    cleanAttrs += ' width="256" height="256"';

    return txt.replace(/<svg\b[^>]*>/i, '<svg' + cleanAttrs + '>');
  };

  IconPresetManager.prototype._loadImageElement = function (srcUrl) {
    return new Promise(function (resolve) {
      if (!srcUrl) {
        resolve(null);
        return;
      }
      var settled = false;
      var timer = setTimeout(function () {
        if (!settled) {
          settled = true;
          resolve(null);
        }
      }, 5000);
      var img = new Image();
      img.onload = function () {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(img);
        }
      };
      img.onerror = function () {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(null);
        }
      };
      img.src = srcUrl;
    });
  };

  /**
   * Renders an array of SVG file objects [{ name, path }] onto a numbered HTML5 <canvas>
   * contact sheet so multimodal Vision AI can visually recognize every icon by #number.
   */
  IconPresetManager.prototype.renderContactSheet = function (svgSlice, indexOffset) {
    var self = this;
    var offset = indexOffset || 0;
    var items = Array.isArray(svgSlice) ? svgSlice : [];
    if (items.length === 0) return Promise.resolve('');

    var cols = items.length <= 12 ? 4 : (items.length <= 20 ? 5 : 6);
    var rows = Math.ceil(items.length / cols);
    var cellW = 220;
    var cellH = 220;
    var pad = 18;

    var canvas = document.createElement('canvas');
    canvas.width = cols * cellW + (cols + 1) * pad;
    canvas.height = rows * cellH + (rows + 1) * pad;
    var ctx = canvas.getContext('2d');

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    var loadPromises = items.map(function (it) {
      var dataUrl = self._readSvgAsDataUrl(it.path);
      return self._loadImageElement(dataUrl);
    });

    return Promise.all(loadPromises).then(function (loadedImgs) {
      for (var i = 0; i < items.length; i++) {
        var col = i % cols;
        var row = Math.floor(i / cols);
        var x = pad + col * (cellW + pad);
        var y = pad + row * (cellH + pad);

        // Cell card
        ctx.fillStyle = '#F8FAFC';
        ctx.fillRect(x, y, cellW, cellH);
        ctx.strokeStyle = '#CBD5E1';
        ctx.lineWidth = 2;
        ctx.strokeRect(x, y, cellW, cellH);

        var img = loadedImgs[i];
        if (img && img.width > 0 && img.height > 0) {
          var availW = cellW - 44;
          var availH = cellH - 58;
          var scale = Math.min(availW / img.width, availH / img.height);
          var dw = Math.max(1, Math.round(img.width * scale));
          var dh = Math.max(1, Math.round(img.height * scale));
          var dx = x + Math.round((cellW - dw) / 2);
          var dy = y + 36 + Math.round((availH - dh) / 2);
          try {
            ctx.drawImage(img, dx, dy, dw, dh);
          } catch (eDraw) {}
        }

        // Bold index badge (#1, #2, ...)
        var labelNum = '#' + (offset + i + 1);
        ctx.fillStyle = '#0F172A';
        ctx.fillRect(x + 6, y + 6, 54, 24);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 15px Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(labelNum, x + 33, y + 19);
      }

      return canvas.toDataURL('image/jpeg', 0.88);
    });
  };

  IconPresetManager.prototype._renderContactSheetsChunked = function (svgItems, chunkSize) {
    var self = this;
    var size = chunkSize || 24;
    var chunks = [];
    for (var i = 0; i < svgItems.length; i += size) {
      chunks.push({ slice: svgItems.slice(i, i + size), offset: i });
    }
    var results = [];
    var seq = Promise.resolve();
    chunks.forEach(function (ch) {
      seq = seq.then(function () {
        return self.renderContactSheet(ch.slice, ch.offset).then(function (url) {
          if (url) results.push({ dataUrl: url, name: 'contact_sheet_' + (ch.offset + 1) + '.jpg' });
        });
      });
    });
    return seq.then(function () { return results; });
  };

  IconPresetManager.prototype._ensureTurnAuthIfNeeded = function (hostApp, hasPersonalKey, callsCounter) {
    var self = this;
    if (hasPersonalKey) return Promise.resolve();
    // Admin API turnTokens allow max 7 proxy calls and expire in 5m; refresh every 4 calls.
    if (callsCounter.count > 0 && (callsCounter.count % 4) !== 0 && this.api.currentTurnToken) {
      return Promise.resolve();
    }
    return this.auth.useCredit({ hostApp: hostApp, hasPersonalKey: false }).then(function (res) {
      if (!res || !res.success) {
        throw new Error((res && res.message) || 'Credits exhausted or authorization failed.');
      }
      self.api.setTurnToken(res.turnToken || '');
    });
  };

  IconPresetManager.prototype._analyzeSidePanelSpec = function (refImage, demoPrompt, iconsPerSet, hostApp, hasPersonalKey, callsCounter) {
    var self = this;
    var sys = [
      'You are an expert commercial vector icon-sheet art director.',
      'Carefully inspect the attached Side Panel reference image (if provided) and the user prompt.',
      'Reproduce the reference Side Panel\'s VISUAL LAYOUT STRUCTURE (not just its colors!):',
      '- Does the reference have a top count pill/badge like "32 ICONS" at the top? -> set topBadgeText="{COUNT} ICONS" + topBadgeBgColor + topBadgeTextColor.',
      '- Does the reference have a circle, arch, or tinted frame behind the hero icon? -> set heroFrameStyle ("none" | "circle_tint" | "circle_white" | "arch_curve" | "rounded_box") and heroFrameColor.',
      '- Does the reference have a horizontal divider line under the hero icon? -> set showDivider=true/false and dividerColor.',
      '- Does the reference have a distinct contrasting colored bottom footer band/block (e.g., light blue bottom block)? -> set footerBlock=true, footerBgColor, footerTextColor, and layoutStyle="badge_footer_card". Otherwise layoutStyle="classic_split".',
      'Rules:',
      '- All colors MUST be solid 6-digit hex codes (#RRGGBB). No rgba or opacity.',
      '- Keep the icon-grid background 100% transparent/isolated (NO solid white Background_Card rectangle or outer border unless explicitly requested). Set cardBgColor="none" and cardBorderColor="none".',
      '- Keep aspectRatio balanced for ' + iconsPerSet + ' icons plus the side panel (e.g. "2.2:1" or "16:9" or "3:2").',
      '- Extract featureLines from the user prompt (use "{COUNT}" placeholder, e.g. ["{COUNT} ICONS", "100% VECTOR", "FULLY EDITABLE"]). NEVER include file format lists like "AI • EPS • SVG" unless the user explicitly asks for them.',
      '- For heroStyle: use "white_badge" or "original" if the prompt/icons are 3D or multi-color gradient icons; use "monochrome_white" for flat glyph icons on dark panels.',
      'JSON SCHEMA:',
      '{',
      '  "aspectRatio": "16:9",',
      '  "sidePanel": {',
      '    "position": "left" | "right" | "top",',
      '    "layoutStyle": "classic_split" | "badge_footer_card" | "circle_hero",',
      '    "widthRatio": 0.24,',
      '    "heightRatio": 0.24,',
      '    "bgColor": "#183566",',
      '    "bgColor2": "",',
      '    "accentColor": "#29ABE2",',
      '    "titleColor": "#FFFFFF",',
      '    "subtitleColor": "#38BDF8",',
      '    "featureColor": "#CBD5E1",',
      '    "cardBgColor": "none",',
      '    "cardBorderColor": "none",',
      '    "topBadgeText": "",',
      '    "topBadgeBgColor": "#0F2447",',
      '    "topBadgeTextColor": "#FFFFFF",',
      '    "heroStyle": "monochrome_white" | "white_badge" | "original",',
      '    "heroFrameStyle": "none" | "circle_tint" | "circle_white" | "arch_curve" | "rounded_box",',
      '    "heroFrameColor": "#29ABE2",',
      '    "showDivider": true,',
      '    "dividerColor": "#FFFFFF",',
      '    "footerBlock": false,',
      '    "footerBgColor": "#4A90D9",',
      '    "footerTextColor": "#0F172A",',
      '    "featureLines": ["{COUNT} ICONS", "100% VECTOR", "FULLY EDITABLE"]',
      '  },',
      '  "grid": {',
      '    "cols": 0,',
      '    "rows": 0,',
      '    "labelColor": "#1E293B",',
      '    "uppercaseLabels": true,',
      '    "showCellBoxes": false,',
      '    "cellBoxColor": "#F1F5F9"',
      '  }',
      '}'
    ].join('\n');

    var userMsg = {
      role: 'user',
      content: 'Design the Side Panel style spec matching the reference layout & colors for an icon set of ' + iconsPerSet + ' icons.\n\nUser Demo Prompt:\n' + String(demoPrompt || DEFAULT_DEMO_PROMPT),
      images: (refImage && refImage.dataUrl) ? [{ name: refImage.name || 'side_panel_ref.jpg', dataUrl: refImage.dataUrl }] : []
    };

    return this._ensureTurnAuthIfNeeded(hostApp, hasPersonalKey, callsCounter).then(function () {
      callsCounter.count++;
      return self.api.sendAgentChat([userMsg], sys, 0, { expectJson: true, preferFastVision: true, timeoutMs: 45000 });
    }).then(function (raw) {
      var parsed = self._parseJsonSafe(raw && raw.text);
      return self._normalizeStyleSpec(parsed, iconsPerSet, demoPrompt);
    });
  };

  IconPresetManager.prototype._filterFeatureLines = function (lines, demoPrompt) {
    var askFormats = /\b(ai|eps|svg)\b.*\b(eps|svg)\b/i.test(String(demoPrompt || '').replace(/do not[^\n.]*/gi, ''));
    var out = [];
    if (Array.isArray(lines)) {
      for (var i = 0; i < lines.length; i++) {
        var s = String(lines[i] || '').trim();
        if (!s) continue;
        if (!askFormats && /(ai\s*[•\/,|]\s*eps|eps\s*[•\/,|]\s*svg)/i.test(s)) continue;
        out.push(s);
      }
    }
    return out.length > 0 ? out : ['{COUNT} ICONS', '100% VECTOR', 'FULLY EDITABLE'];
  };

  IconPresetManager.prototype._normalizeStyleSpec = function (parsed, iconsPerSet, demoPrompt) {
    var sp = (parsed && parsed.sidePanel) || {};
    var gr = (parsed && parsed.grid) || {};
    var asksCardFrame = /\b(card\s*border|outer\s*border|outer\s*frame|card\s*background|background\s*card)\b/i.test(String(demoPrompt || ''));
    return {
      aspectRatio: (parsed && parsed.aspectRatio) || '',
      sidePanel: {
        position: sp.position || 'left',
        layoutStyle: sp.layoutStyle || 'classic_split',
        widthRatio: typeof sp.widthRatio === 'number' ? sp.widthRatio : 0.24,
        heightRatio: typeof sp.heightRatio === 'number' ? sp.heightRatio : 0.24,
        bgColor: sp.bgColor || '#183566',
        bgColor2: sp.bgColor2 || '',
        accentColor: sp.accentColor || '#29ABE2',
        titleColor: sp.titleColor || '#FFFFFF',
        subtitleColor: sp.subtitleColor || sp.accentColor || '#38BDF8',
        featureColor: sp.featureColor || '#CBD5E1',
        cardBgColor: (asksCardFrame && sp.cardBgColor) ? sp.cardBgColor : 'none',
        cardBorderColor: (asksCardFrame && sp.cardBorderColor) ? sp.cardBorderColor : 'none',
        drawCardBg: asksCardFrame && !!(sp.cardBgColor && sp.cardBgColor !== 'none'),
        topBadgeText: sp.topBadgeText || '',
        topBadgeBgColor: sp.topBadgeBgColor || sp.accentColor || '#0F2447',
        topBadgeTextColor: sp.topBadgeTextColor || '#FFFFFF',
        heroStyle: sp.heroStyle || 'monochrome_white',
        heroFrameStyle: sp.heroFrameStyle || 'none',
        heroFrameColor: sp.heroFrameColor || sp.accentColor || '#29ABE2',
        showDivider: sp.showDivider !== false,
        dividerColor: sp.dividerColor || sp.accentColor || '#FFFFFF',
        footerBlock: !!sp.footerBlock,
        footerBgColor: sp.footerBgColor || sp.accentColor || '#4A90D9',
        footerTextColor: sp.footerTextColor || '#0F172A',
        featureLines: this._filterFeatureLines(sp.featureLines, demoPrompt)
      },
      grid: {
        cols: parseInt(gr.cols, 10) || 0,
        rows: parseInt(gr.rows, 10) || 0,
        labelColor: gr.labelColor || '#1E293B',
        uppercaseLabels: gr.uppercaseLabels !== false,
        showCellBoxes: !!gr.showCellBoxes,
        cellBoxColor: gr.cellBoxColor || '#F1F5F9'
      }
    };
  };

  /**
   * Labels a single set of icons (<= ~60, chunked into <= 24 per contact sheet) AND generates
   * the SEO Side Panel title + best hero icon index.
   */
  IconPresetManager.prototype.recognizeIconSet = function (svgSlice, demoPrompt, hostApp, hasPersonalKey, callsCounter) {
    var self = this;
    var count = svgSlice.length;
    return this._renderContactSheetsChunked(svgSlice, 24).then(function (sheetImgs) {
      var sys = [
        'You are a microstock SEO and vector icon recognition specialist.',
        'Look at the numbered contact sheet image(s) showing icons #1 through #' + count + '.',
        'For EACH numbered icon (#1..' + count + '), write a concise, accurate, relevant 1-3 word commercial label describing what the icon visually depicts.',
        'Also create a high-converting commercial SEO title for the whole icon set (split into line1 e.g. "ACCOUNTING" and line2 e.g. "ICONS" or "VECTOR SET"), pick the single most representative heroIconIndex (1..' + count + '), and provide short side-panel featureLines matching the user prompt (NEVER include file formats like AI/EPS/SVG unless explicitly requested).',
        'STRICT JSON ONLY:',
        '{',
        '  "seoTitleLine1": "ACCOUNTING",',
        '  "seoTitleLine2": "ICONS",',
        '  "seoSubtitle": "BUSINESS & FINANCE",',
        '  "heroIconIndex": 1,',
        '  "featureLines": ["' + count + ' ICONS", "100% VECTOR", "FULLY EDITABLE"],',
        '  "labels": [ { "index": 1, "label": "ACCOUNTING" } ]',
        '}'
      ].join('\n');

      var msg = {
        role: 'user',
        content: 'Identify all ' + count + ' numbered icons (#1 to #' + count + ') and generate the SEO Side Panel title.\nPrompt context:\n' + String(demoPrompt || DEFAULT_DEMO_PROMPT),
        images: sheetImgs
      };

      return self._ensureTurnAuthIfNeeded(hostApp, hasPersonalKey, callsCounter).then(function () {
        callsCounter.count++;
        return self.api.sendAgentChat([msg], sys, 0, { expectJson: true, preferFastVision: true, timeoutMs: 45000 });
      });
    }).then(function (raw) {
      var parsed = self._parseJsonSafe(raw && raw.text) || {};
      var labelMap = {};
      if (Array.isArray(parsed.labels)) {
        for (var i = 0; i < parsed.labels.length; i++) {
          var entry = parsed.labels[i];
          if (entry && entry.index != null && entry.label) {
            labelMap[parseInt(entry.index, 10)] = String(entry.label).trim();
          }
        }
      }
      var resolvedLabels = [];
      for (var k = 1; k <= count; k++) {
        resolvedLabels.push(labelMap[k] || ('ICON ' + k));
      }
      var heroIdx = parseInt(parsed.heroIconIndex, 10);
      if (isNaN(heroIdx) || heroIdx < 1 || heroIdx > count) heroIdx = 1;
      return {
        seoTitleLine1: String(parsed.seoTitleLine1 || 'VECTOR').trim(),
        seoTitleLine2: String(parsed.seoTitleLine2 || 'ICONS').trim(),
        seoSubtitle: String(parsed.seoSubtitle || '').trim(),
        heroIconIndex: heroIdx,
        featureLines: Array.isArray(parsed.featureLines) ? self._filterFeatureLines(parsed.featureLines, demoPrompt) : null,
        labels: resolvedLabels
      };
    });
  };

  /**
   * Smart Topic Grouping for large mixed folders (e.g. 500 icons -> 50 themed sets):
   * 1) Batch-recognizes all icons in chunks of 25 via numbered contact sheets.
   * 2) Clusters them into cohesive themed sets of `iconsPerSet`.
   */
  IconPresetManager.prototype._scanAndGroupByTopic = function (allSvgs, iconsPerSet, maxSets, demoPrompt, hostApp, hasPersonalKey, callsCounter, onProgress) {
    var self = this;
    var chunkSize = 25;
    var catalog = []; // { globalIdx, path, name, label, topic }
    var batches = [];
    for (var i = 0; i < allSvgs.length; i += chunkSize) {
      batches.push({ start: i, slice: allSvgs.slice(i, i + chunkSize) });
    }

    var seq = Promise.resolve();
    batches.forEach(function (b, bIdx) {
      seq = seq.then(function () {
        if (self.stopRequested) throw new Error('Stopped by user');
        onProgress('Scanning icons ' + (b.start + 1) + '–' + (b.start + b.slice.length) + ' of ' + allSvgs.length + '...');
        return self.renderContactSheet(b.slice, b.start).then(function (sheetUrl) {
          var sys = [
            'Identify every numbered icon in this contact sheet image.',
            'For each icon #' + (b.start + 1) + ' to #' + (b.start + b.slice.length) + ', return a short 1-3 word label and a broad 1-2 word category/topic (e.g. "Finance", "Security", "Medical", "E-Commerce", "Technology", "Education").',
            'STRICT JSON ONLY: { "items": [ { "index": ' + (b.start + 1) + ', "label": "SHIELD LOCK", "topic": "Security" } ] }'
          ].join('\n');
          var msg = {
            role: 'user',
            content: 'Label and categorize icons #' + (b.start + 1) + '..#' + (b.start + b.slice.length) + '.',
            images: [{ name: 'batch_' + (bIdx + 1) + '.jpg', dataUrl: sheetUrl }]
          };
          return self._ensureTurnAuthIfNeeded(hostApp, hasPersonalKey, callsCounter).then(function () {
            callsCounter.count++;
            return self.api.sendAgentChat([msg], sys, 0, { expectJson: true, preferFastVision: true, timeoutMs: 45000 });
          }).then(function (raw) {
            var parsed = self._parseJsonSafe(raw && raw.text) || {};
            var map = {};
            if (Array.isArray(parsed.items)) {
              for (var m = 0; m < parsed.items.length; m++) {
                var it = parsed.items[m];
                if (it && it.index != null) map[parseInt(it.index, 10)] = it;
              }
            }
            for (var k = 0; k < b.slice.length; k++) {
              var gIdx = b.start + k + 1;
              var found = map[gIdx] || {};
              catalog.push({
                globalIdx: gIdx,
                path: b.slice[k].path,
                name: b.slice[k].name,
                label: String(found.label || ('ICON ' + gIdx)).trim(),
                topic: String(found.topic || 'General').trim()
              });
            }
          });
        });
      });
    });

    return seq.then(function () {
      if (self.stopRequested) throw new Error('Stopped by user');
      onProgress('Grouping ' + catalog.length + ' icons by topic into sets...');

      // Group deterministically by normalized topic first, then slice into iconsPerSet chunks
      var byTopic = {};
      var topicOrder = [];
      for (var i = 0; i < catalog.length; i++) {
        var tKey = catalog[i].topic.toLowerCase();
        if (!byTopic[tKey]) {
          byTopic[tKey] = { title: catalog[i].topic, items: [] };
          topicOrder.push(tKey);
        }
        byTopic[tKey].items.push(catalog[i]);
      }

      // Sort topics largest first so main full sets come first, leftovers merge into "Mixed / General" sets
      topicOrder.sort(function (a, b) { return byTopic[b].items.length - byTopic[a].items.length; });

      var sets = [];
      var leftovers = [];
      for (var t = 0; t < topicOrder.length; t++) {
        var grp = byTopic[topicOrder[t]];
        var arr = grp.items;
        while (arr.length >= iconsPerSet) {
          sets.push({
            topicHint: grp.title,
            items: arr.splice(0, iconsPerSet)
          });
        }
        for (var r = 0; r < arr.length; r++) leftovers.push(arr[r]);
      }
      while (leftovers.length > 0) {
        var take = leftovers.splice(0, iconsPerSet);
        sets.push({
          topicHint: take[0] ? take[0].topic : 'General',
          items: take
        });
      }

      if (maxSets > 0 && sets.length > maxSets) {
        sets = sets.slice(0, maxSets);
      }

      // Ask AI (text-only, super fast) for clean SEO titles & hero index for each set
      var compactSets = sets.map(function (s, idx) {
        return {
          setIndex: idx + 1,
          topicHint: s.topicHint,
          labels: s.items.map(function (x, j) { return (j + 1) + ':' + x.label; })
        };
      });

      var titleSys = [
        'You are a microstock SEO specialist.',
        'For each icon set below, generate an SEO-friendly 2-line title (seoTitleLine1, seoTitleLine2 like "ICONS"), short seoSubtitle, and best heroIconIndex (1-based within that set).',
        'STRICT JSON ONLY: { "sets": [ { "setIndex": 1, "seoTitleLine1": "SECURITY", "seoTitleLine2": "ICONS", "seoSubtitle": "CYBER & NETWORK PROTECTION", "heroIconIndex": 1 } ] }'
      ].join('\n');

      var titleMsg = {
        role: 'user',
        content: 'Generate SEO Side Panel titles for these ' + compactSets.length + ' sets.\nPrompt context: ' + String(demoPrompt || '') + '\n\n' + JSON.stringify(compactSets)
      };

      return self._ensureTurnAuthIfNeeded(hostApp, hasPersonalKey, callsCounter).then(function () {
        callsCounter.count++;
        return self.api.sendAgentChat([titleMsg], titleSys, 0, { expectJson: true, preferFastVision: true, timeoutMs: 45000 });
      }).then(function (raw) {
        var parsed = self._parseJsonSafe(raw && raw.text) || {};
        var metaMap = {};
        if (Array.isArray(parsed.sets)) {
          for (var p = 0; p < parsed.sets.length; p++) {
            var sm = parsed.sets[p];
            if (sm && sm.setIndex != null) metaMap[parseInt(sm.setIndex, 10)] = sm;
          }
        }
        return sets.map(function (s, idx) {
          var m = metaMap[idx + 1] || {};
          return {
            seoTitleLine1: String(m.seoTitleLine1 || s.topicHint || 'VECTOR').toUpperCase(),
            seoTitleLine2: String(m.seoTitleLine2 || 'ICONS').toUpperCase(),
            seoSubtitle: String(m.seoSubtitle || '').trim(),
            heroIconIndex: parseInt(m.heroIconIndex, 10) || 1,
            icons: s.items.map(function (x) { return { path: x.path, name: x.name, label: x.label }; })
          };
        });
      });
    });
  };

  /**
   * Builds a single prepared set inside Adobe Illustrator via AI_buildIconSetSheet().
   */
  IconPresetManager.prototype.buildSingleSetInIllustrator = function (setPlan, styleSpec, options) {
    var opts = options || {};
    var spCopy = JSON.parse(JSON.stringify(styleSpec.sidePanel || {}));
    spCopy.seoTitleLine1 = setPlan.seoTitleLine1 || 'VECTOR';
    spCopy.seoTitleLine2 = setPlan.seoTitleLine2 || 'ICONS';
    spCopy.seoSubtitle = setPlan.seoSubtitle || '';
    spCopy.heroIconIndex = setPlan.heroIconIndex || 1;
    if (Array.isArray(setPlan.featureLines) && setPlan.featureLines.length > 0) {
      spCopy.featureLines = setPlan.featureLines;
    }

    var slugBase = this._sanitizeSlug((spCopy.seoTitleLine1 || '') + '_' + (spCopy.seoTitleLine2 || 'icons'));
    var setName = slugBase + '_set_' + this._pad2(opts.setNumber || 1);

      var cfg = {
      setName: setName,
      aspectRatio: styleSpec.aspectRatio || '',
      sidePanel: spCopy,
      grid: styleSpec.grid || {},
      icons: setPlan.icons.map(function (ic) {
        return { path: ic.path, label: ic.label };
      }),
      outputDir: opts.outputDir,
      formats: (Array.isArray(opts.formats) && opts.formats.length > 0) ? opts.formats : ['eps'],
      closeAfterExport: !!opts.closeAfterExport,
      outlineText: opts.outlineText !== false,
      removeWhiteBg: opts.removeWhiteBg !== false
    };

    var jsx = 'return AI_buildIconSetSheet(' + JSON.stringify(cfg) + ');';
    return this.bridge.evalScriptSafe(jsx);
  };

  IconPresetManager.prototype._shuffleDifferentOrder = function (allSvgs, takeCount, setIdx) {
    var pool = allSvgs.slice();
    // Deterministic seeded-like + rotated Fisher-Yates so every set has a genuinely different visual grid order
    var shift = ((setIdx * 7) + 3) % Math.max(1, pool.length);
    if (shift > 0 && pool.length > 1) {
      pool = pool.slice(shift).concat(pool.slice(0, shift));
    }
    for (var i = pool.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = pool[i];
      pool[i] = pool[j];
      pool[j] = tmp;
    }
    var out = [];
    while (out.length < takeCount) {
      for (var k = 0; k < pool.length && out.length < takeCount; k++) {
        out.push(pool[k]);
      }
    }
    return out;
  };

  IconPresetManager.prototype._pickUnusedHeroIndex = function (slice, preferredIdx, usedHeroPaths) {
    var pref = parseInt(preferredIdx, 10);
    if (!isNaN(pref) && pref >= 1 && pref <= slice.length) {
      var prefPath = slice[pref - 1] && slice[pref - 1].path;
      if (prefPath && !usedHeroPaths[prefPath]) {
        usedHeroPaths[prefPath] = true;
        return pref;
      }
    }
    for (var i = 0; i < slice.length; i++) {
      var p = slice[i] && slice[i].path;
      if (p && !usedHeroPaths[p]) {
        usedHeroPaths[p] = true;
        return i + 1;
      }
    }
    var fallback = ((Object.keys(usedHeroPaths).length) % slice.length) + 1;
    return fallback;
  };

  IconPresetManager.prototype._generateVariedTitleFromCache = function (labels, setNumber, usedTitles, demoPrompt, hostApp, hasPersonalKey, callsCounter) {
    var self = this;
    var sys = [
      'You are a microstock SEO icon-set naming specialist.',
      'Generate a FRESH, distinct 2-line SEO title (seoTitleLine1 + seoTitleLine2) for another icon set variation using these icons.',
      'Do NOT repeat any previously used title: ' + JSON.stringify(usedTitles || []),
      'STRICT JSON ONLY: { "seoTitleLine1": "DIGITAL UI", "seoTitleLine2": "ICONS", "seoSubtitle": "MODERN BUSINESS & INTERFACE" }'
    ].join('\n');
    var msg = {
      role: 'user',
      content: 'Set #' + setNumber + ' uses these icons in a new shuffled layout:\n' + labels.join(', ') + '\nPrompt context: ' + String(demoPrompt || '')
    };
    return this._ensureTurnAuthIfNeeded(hostApp, hasPersonalKey, callsCounter).then(function () {
      callsCounter.count++;
      return self.api.sendAgentChat([msg], sys, 0, { expectJson: true, preferFastVision: true, timeoutMs: 30000 });
    }).then(function (raw) {
      var p = self._parseJsonSafe(raw && raw.text) || {};
      return {
        seoTitleLine1: String(p.seoTitleLine1 || ('VECTOR SET ' + setNumber)).trim(),
        seoTitleLine2: String(p.seoTitleLine2 || 'ICONS').trim(),
        seoSubtitle: String(p.seoSubtitle || '').trim()
      };
    })['catch'](function () {
      return {
        seoTitleLine1: 'VECTOR PACK',
        seoTitleLine2: 'ICONS ' + setNumber,
        seoSubtitle: ''
      };
    });
  };

  /**
   * Prepares a preview plan for the first set (or sequential set #1) so user can review/edit labels.
   */
  IconPresetManager.prototype.previewFirstSet = function (params) {
    var self = this;
    this.stopRequested = false;
    var svgFiles = params.svgFiles || [];
    var iconsPerSet = Math.max(1, parseInt(params.iconsPerSet, 10) || 24);
    var slice = svgFiles.slice(0, iconsPerSet);
    var callsCounter = { count: 0 };
    var notify = typeof params.onProgress === 'function' ? params.onProgress : function () {};

    notify('Analyzing Side Panel style & rendering contact sheet...');
    return this._analyzeSidePanelSpec(params.refImage, params.demoPrompt, slice.length, params.hostApp, params.hasPersonalKey, callsCounter)
      .then(function (styleSpec) {
        if (self.stopRequested) throw new Error('Stopped by user');
        notify('Recognizing ' + slice.length + ' icons via Vision AI...');
        return self.recognizeIconSet(slice, params.demoPrompt, params.hostApp, params.hasPersonalKey, callsCounter)
          .then(function (rec) {
            return {
              styleSpec: styleSpec,
              setPlan: {
                seoTitleLine1: rec.seoTitleLine1,
                seoTitleLine2: rec.seoTitleLine2,
                seoSubtitle: rec.seoSubtitle,
                heroIconIndex: rec.heroIconIndex,
                featureLines: rec.featureLines || styleSpec.sidePanel.featureLines,
                icons: slice.map(function (f, i) {
                  return {
                    path: f.path,
                    name: f.name,
                    label: rec.labels[i] || ('ICON ' + (i + 1)),
                    thumbUrl: self._readSvgAsDataUrl(f.path)
                  };
                })
              }
            };
          });
      });
  };

  /**
   * Runs the full multi-set Icon Set Preset batch (supports 1 set of 30 icons OR 50 sets from 500 icons).
   */
  IconPresetManager.prototype.runBatch = function (params) {
    var self = this;
    this.stopRequested = false;

    var allSvgs = params.svgFiles || [];
    if (allSvgs.length === 0) {
      return Promise.reject(new Error('No SVG files found in the selected folder.'));
    }

    var iconsPerSet = Math.max(1, parseInt(params.iconsPerSet, 10) || 24);
    var requestedSets = parseInt(params.setCount, 10) || 0; // 0 = All possible
    var groupingMode = params.groupingMode === 'topic' ? 'topic' : 'sequential';
    var formats = Array.isArray(params.formats) && params.formats.length > 0 ? params.formats : ['eps'];
    var closeIntermediate = params.closeIntermediate !== false;
    var notify = typeof params.onProgress === 'function' ? params.onProgress : function () {};
    var callsCounter = { count: 0 };

    notify('Analyzing Side Panel reference & prompt...');

    return this._analyzeSidePanelSpec(params.refImage, params.demoPrompt, iconsPerSet, params.hostApp, params.hasPersonalKey, callsCounter)
      .then(function (styleSpec) {
        if (self.stopRequested) throw new Error('Stopped by user');

        if (groupingMode === 'topic' && allSvgs.length > iconsPerSet) {
          return self._scanAndGroupByTopic(
            allSvgs,
            iconsPerSet,
            requestedSets,
            params.demoPrompt,
            params.hostApp,
            params.hasPersonalKey,
            callsCounter,
            notify
          ).then(function (plannedSets) {
            return { styleSpec: styleSpec, mode: 'planned', sets: plannedSets };
          });
        }

        // Sequential chunks (plus shuffled variations when requestedSets * iconsPerSet > allSvgs.length!)
        var rawChunks = [];
        var naturalCount = Math.ceil(allSvgs.length / iconsPerSet);
        var targetCount = requestedSets > 0 ? requestedSets : naturalCount;

        for (var cIdx = 0; cIdx < targetCount; cIdx++) {
          var start = cIdx * iconsPerSet;
          var slice;
          if (start < allSvgs.length) {
            slice = allSvgs.slice(start, start + iconsPerSet);
            if (slice.length < iconsPerSet && allSvgs.length >= iconsPerSet) {
              var extraPool = self._shuffleDifferentOrder(allSvgs, allSvgs.length, cIdx + 1);
              for (var ep = 0; ep < extraPool.length && slice.length < iconsPerSet; ep++) {
                var exists = slice.some(function (x) { return x.path === extraPool[ep].path; });
                if (!exists) slice.push(extraPool[ep]);
              }
            }
          } else {
            // User asked for more sets than unique chunks (e.g. 24 SVGs -> 2 sets of 24): create a shuffled variation!
            slice = self._shuffleDifferentOrder(allSvgs, Math.min(iconsPerSet, allSvgs.length), cIdx);
          }
          rawChunks.push(slice);
        }
        return { styleSpec: styleSpec, mode: 'sequential', chunks: rawChunks };
      })
      .then(function (prep) {
        var styleSpec = prep.styleSpec;
        var totalSets = prep.mode === 'planned' ? prep.sets.length : prep.chunks.length;
        var builtSets = [];
        var errors = [];
        var recognizedCache = {}; // path -> label (avoids re-calling Vision on shuffled variations!)
        var usedHeroPaths = {};
        var usedTitles = [];

        var chain = Promise.resolve();
        for (var sIdx = 0; sIdx < totalSets; sIdx++) {
          (function (idx) {
            chain = chain.then(function () {
              if (self.stopRequested) throw new Error('Stopped by user');
              var isLast = (idx === totalSets - 1);
              var shouldClose = closeIntermediate && !isLast;

              var planPromise;
              if (prep.mode === 'planned') {
                planPromise = Promise.resolve(prep.sets[idx]);
              } else {
                var slice = prep.chunks[idx];
                var allCached = slice.every(function (f) { return !!recognizedCache[f.path]; });
                if (allCached) {
                  notify('Set ' + (idx + 1) + '/' + totalSets + ': Preparing shuffled variation & new SEO title...');
                  var cachedLabels = slice.map(function (f) { return recognizedCache[f.path]; });
                  planPromise = self._generateVariedTitleFromCache(
                    cachedLabels,
                    idx + 1,
                    usedTitles,
                    params.demoPrompt,
                    params.hostApp,
                    params.hasPersonalKey,
                    callsCounter
                  ).then(function (tMeta) {
                    var heroIdx = self._pickUnusedHeroIndex(slice, 1, usedHeroPaths);
                    return {
                      seoTitleLine1: tMeta.seoTitleLine1,
                      seoTitleLine2: tMeta.seoTitleLine2,
                      seoSubtitle: tMeta.seoSubtitle,
                      heroIconIndex: heroIdx,
                      featureLines: styleSpec.sidePanel.featureLines,
                      icons: slice.map(function (f, k) {
                        return { path: f.path, name: f.name, label: cachedLabels[k] || ('ICON ' + (k + 1)) };
                      })
                    };
                  });
                } else {
                  notify('Set ' + (idx + 1) + '/' + totalSets + ': Recognizing ' + slice.length + ' icons...');
                  planPromise = self.recognizeIconSet(slice, params.demoPrompt, params.hostApp, params.hasPersonalKey, callsCounter)
                    .then(function (rec) {
                      for (var rk = 0; rk < slice.length; rk++) {
                        if (slice[rk] && slice[rk].path && rec.labels[rk]) {
                          recognizedCache[slice[rk].path] = rec.labels[rk];
                        }
                      }
                      var heroIdx = self._pickUnusedHeroIndex(slice, rec.heroIconIndex, usedHeroPaths);
                      var filteredFeats = rec.featureLines ? self._filterFeatureLines(rec.featureLines, params.demoPrompt) : styleSpec.sidePanel.featureLines;
                      return {
                        seoTitleLine1: rec.seoTitleLine1,
                        seoTitleLine2: rec.seoTitleLine2,
                        seoSubtitle: rec.seoSubtitle,
                        heroIconIndex: heroIdx,
                        featureLines: filteredFeats,
                        icons: slice.map(function (f, k) {
                          return { path: f.path, name: f.name, label: rec.labels[k] || ('ICON ' + (k + 1)) };
                        })
                      };
                    });
                }
              }

              return planPromise.then(function (setPlan) {
                if (self.stopRequested) throw new Error('Stopped by user');
                var titleLabel = (setPlan.seoTitleLine1 + ' ' + (setPlan.seoTitleLine2 || '')).trim();
                usedTitles.push(titleLabel);
                notify('Set ' + (idx + 1) + '/' + totalSets + ': Building "' + titleLabel + '" in Illustrator...');

                return self.buildSingleSetInIllustrator(setPlan, styleSpec, {
                  setNumber: idx + 1,
                  outputDir: params.outputDir,
                  formats: formats,
                  closeAfterExport: shouldClose,
                  outlineText: params.outlineText !== false,
                  removeWhiteBg: params.removeWhiteBg !== false
                }).then(function (execRes) {
                  if (execRes && execRes.ok) {
                    var resData = execRes.result || execRes;
                    builtSets.push({
                      setNumber: idx + 1,
                      title: titleLabel,
                      iconCount: setPlan.icons.length,
                      exportedFiles: resData.exportedFiles || []
                    });
                  } else {
                    errors.push('Set #' + (idx + 1) + ': ' + ((execRes && execRes.error) || 'Failed'));
                  }
                });
              })['catch'](function (setErr) {
                if (self.stopRequested || (setErr && setErr.message === 'Stopped by user')) {
                  throw setErr;
                }
                errors.push('Set #' + (idx + 1) + ': ' + ((setErr && setErr.message) ? setErr.message : String(setErr)));
              });
            });
          })(sIdx);
        }

        return chain.then(function () {
          return {
            ok: builtSets.length > 0,
            totalPlanned: totalSets,
            builtSets: builtSets,
            errors: errors,
            outputDir: params.outputDir
          };
        });
      });
  };

  NS.IconPresetManager = IconPresetManager;
})(window);
